import { describe, it, expect } from 'vitest';
import * as fs from 'node:fs';
import * as os from 'node:os';
import * as path from 'node:path';
import JSZip from 'jszip';
import { makeCore, input } from './helpers';
import { exportDocument, existingFiles, previewHtml, sanitizeFileName, suggestFileName, PdfRenderer } from '../src/main/docs/export';
import { AppError } from '../src/shared/types';

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'arrumaai-exp-'));
const fakePdf: PdfRenderer = async (html) => Buffer.from(`%PDF-FAKE\n${html.length}`);
const xml = async (file: string) => (await JSZip.loadAsync(fs.readFileSync(file))).file('word/document.xml')!.async('string');
const code = async (p: Promise<unknown>) => { try { await p; } catch (e) { return (e as AppError).code; } return 'NAO-FALHOU'; };

describe('Exportação DOCX', () => {
  it('gera DOCX válido, preservando acentos, número e parágrafos', async () => {
    const c = await makeCore(); const dir = tmp();
    const rec = c.documents.issue(input(c, { body: 'Ação, coração, órgão, ç, ã, õ, ü.\n\nSegundo parágrafo — com travessão.' }));
    const r = await exportDocument(rec, c.assets, { dir, baseName: suggestFileName(rec), formats: ['docx'], overwrite: false }, fakePdf);
    expect(path.basename(r.docxPath!)).toBe('Ofício-001-2026.docx');
    const x = await xml(r.docxPath!);
    for (const t of ['Ação, coração, órgão, ç, ã, õ, ü.', 'Segundo parágrafo — com travessão.', 'Ofício nº 001/2026', 'Assunto: ']) expect(x).toContain(t);
    expect(fs.existsSync(path.join(dir, 'Ofício-001-2026.pdf'))).toBe(false);
  });

  it('suporta várias assinaturas (1 a 6)', async () => {
    const c = await makeCore(); const dir = tmp();
    const tpl = c.registry.listTemplates('demo')[0];
    for (const n of ['Ana Quatro Teste', 'Beto Quatro Teste', 'Cris Quatro Teste', 'Davi Quatro Teste']) c.signers.create({ serviceId: 'demo', fullName: n, roleTitle: 'Cargo (teste)' });
    const ids = c.signers.listSelectable('demo', tpl.id).map((s) => s.id);
    for (const slots of [1, 2, 3, 4, 5, 6]) {
      const rec = c.documents.issue(input(c, { signers: ids.slice(0, slots).map((signerId) => ({ signerId })) }));
      const r = await exportDocument(rec, c.assets, { dir, baseName: `ass-${slots}`, formats: ['docx'], overwrite: false }, fakePdf);
      const x = await xml(r.docxPath!);
      expect(rec.signers.length).toBe(slots);
      for (const s of rec.signers) expect(x).toContain(s.name);
    }
  });

  it('texto extenso gera várias páginas sem perder conteúdo', async () => {
    const c = await makeCore(); const dir = tmp();
    const body = Array.from({ length: 120 }, (_, i) => `Parágrafo ${i + 1}: ` + 'conteúdo de teste com acentuação. '.repeat(6)).join('\n\n');
    const rec = c.documents.issue(input(c, { body }));
    const r = await exportDocument(rec, c.assets, { dir, baseName: 'longo', formats: ['docx'], overwrite: false }, fakePdf);
    const x = await xml(r.docxPath!);
    expect(x).toContain('Parágrafo 1:'); expect(x).toContain('Parágrafo 120:');
    expect(fs.statSync(r.docxPath!).size).toBeGreaterThan(10_000);
  });

  it('o arquivo é gerado a partir dos dados gravados, não do cadastro atual', async () => {
    const c = await makeCore(); const dir = tmp();
    const rec = c.documents.issue(input(c));
    c.signers.update('demo', rec.signers[0].signerId, { fullName: 'Nome Alterado Depois' });
    const r = await exportDocument(c.documents.get('demo', rec.id), c.assets, { dir, baseName: 'hist', formats: ['docx'], overwrite: false }, fakePdf);
    const x = await xml(r.docxPath!);
    expect(x).toContain(rec.signers[0].name); expect(x).not.toContain('Nome Alterado Depois');
  });
});

describe('Exportação PDF e tratamento de erros', () => {
  it('chama o gerador de PDF com o HTML do documento e grava o arquivo', async () => {
    const c = await makeCore(); const dir = tmp(); let received = '';
    const rec = c.documents.issue(input(c));
    const r = await exportDocument(rec, c.assets, { dir, baseName: 'doc', formats: ['pdf', 'docx'], overwrite: false }, async (h) => { received = h; return Buffer.from('%PDF-1.4 teste'); });
    expect(received).toContain('Ofício nº 001/2026'); expect(received).toContain('Assunto de teste');
    expect(fs.readFileSync(r.pdfPath!, 'utf8')).toContain('%PDF'); expect(fs.existsSync(r.docxPath!)).toBe(true);
  });

  it('não sobrescreve sem confirmação e sobrescreve quando confirmado', async () => {
    const c = await makeCore(); const dir = tmp();
    const rec = c.documents.issue(input(c));
    const o = { dir, baseName: 'mesmo', formats: ['docx' as const], overwrite: false };
    await exportDocument(rec, c.assets, o, fakePdf);
    expect(existingFiles(o).length).toBe(1);
    expect(await code(exportDocument(rec, c.assets, o, fakePdf))).toBe('FILE_EXISTS');
    await exportDocument(rec, c.assets, { ...o, overwrite: true }, fakePdf);
  });

  it('erros: pasta inexistente, caminho relativo, formato vazio, rascunho, falha do PDF (nada fica pela metade)', async () => {
    const c = await makeCore(); const dir = tmp();
    const rec = c.documents.issue(input(c));
    const base = { baseName: 'x', formats: ['docx' as const], overwrite: false };
    expect(await code(exportDocument(rec, c.assets, { ...base, dir: path.join(dir, 'nao-existe') }, fakePdf))).toBe('EXPORT_FAILED');
    expect(await code(exportDocument(rec, c.assets, { ...base, dir: 'relativo' }, fakePdf))).toBe('VALIDATION');
    expect(await code(exportDocument(rec, c.assets, { ...base, dir, formats: [] }, fakePdf))).toBe('VALIDATION');
    expect(await code(exportDocument(c.documents.saveDraft(input(c)), c.assets, { ...base, dir }, fakePdf))).toBe('NOT_ISSUED');
    const quebrado: PdfRenderer = async () => { throw new Error('motor de PDF falhou'); };
    expect(await code(exportDocument(rec, c.assets, { ...base, dir, baseName: 'meia', formats: ['docx', 'pdf'] }, quebrado))).toBe('EXPORT_FAILED');
    expect(fs.readdirSync(dir)).toEqual([]);
  });

  it('nomes de arquivo são higienizados (sem caminhos nem nomes reservados do Windows)', () => {
    expect(sanitizeFileName('../../etc/passwd')).toBe('..-..-etc-passwd');
    expect(sanitizeFileName('Ofício 001/2026.docx')).toBe('Ofício 001-2026');
    expect(sanitizeFileName('CON')).toBe('CON_');
    expect(sanitizeFileName('a<b>c:d"e|f?g*h')).toBe('a-b-c-d-e-f-g-h');
    expect(sanitizeFileName('   ...  ')).toBe('');
    expect(sanitizeFileName('x'.repeat(300)).length).toBe(120);
  });

  it('prévia escapa HTML (texto digitado não vira código)', async () => {
    const c = await makeCore();
    const p = c.documents.preview(input(c, { body: '<script>alert(1)</script><img src=x onerror=alert(2)>', subject: '"><b>x' }));
    const html = previewHtml(p, c.assets);
    expect(html).not.toContain('<script>alert'); expect(html).not.toContain('<img src=x');
    expect(html).toContain('&lt;script&gt;'); expect(html).toContain('PRÉVIA');
  });
});

describe('Texto de abertura no DOCX', () => {
  it('aparece no arquivo Word antes do texto digitado', async () => {
    const c = await makeCore(); const dir = tmp();
    c.registry.updateTemplate('demo', 'demo:oficio', { openingText: 'O Órgão Exemplo, no exercício de suas atribuições, vem, por meio deste,' });
    const rec = c.documents.issue(input(c, { body: 'comunicar o que segue.' }));
    const r = await exportDocument(rec, c.assets, { dir, baseName: 'abertura', formats: ['docx'], overwrite: false }, fakePdf);
    expect(await xml(r.docxPath!)).toContain('O Órgão Exemplo, no exercício de suas atribuições, vem, por meio deste, comunicar o que segue.');
  });
});

describe('Tamanhos no DOCX', () => {
  it('título, nome do órgão e texto seguem os tamanhos em px (1 px = 0,75 pt)', async () => {
    const c = await makeCore(); const dir = tmp();
    c.registry.updateInstitution('demo', { titleSizePx: 40, orgSizePx: 28, serviceSizePx: 20, fontSizePx: 18 });
    const rec = c.documents.issue(input(c));
    const r = await exportDocument(rec, c.assets, { dir, baseName: 'tam', formats: ['docx'], overwrite: false }, fakePdf);
    const x = await xml(r.docxPath!);
    for (const half of [60, 42, 30]) expect(x).toContain(`<w:sz w:val="${half}"/>`); // 40px=30pt, 28px=21pt, 20px=15pt (em meios-pontos)
    const styles = await (await JSZip.loadAsync(fs.readFileSync(r.docxPath!))).file('word/styles.xml')!.async('string');
    expect(styles).toContain('<w:sz w:val="27"/>'); // texto: 18px = 13,5pt
  });
});

describe('Modelo Notificação (fiel ao documento do Conselho Tutelar)', () => {
  const notif = (c: Awaited<ReturnType<typeof makeCore>>, over: object = {}) => c.documents.issue(input(c, { templateId: 'demo:notificacao', ...over }));

  it('exige os campos próprios e valida data/horário', async () => {
    const c = await makeCore();
    const base = input(c, { templateId: 'demo:notificacao' });
    try { c.documents.issue({ ...base, extra: { ...base.extra, responsavelNome: '', menorNome: '' } }); throw new Error('não falhou'); }
    catch (e) { expect((e as AppError).fields!.map((f) => f.field)).toEqual(expect.arrayContaining(['extra.responsavelNome', 'extra.menorNome'])); }
    expect(await code(Promise.resolve().then(() => c.documents.issue({ ...base, extra: { ...base.extra, dataComparecimento: '31/12/2026' } })))).toBe('VALIDATION');
    expect(await code(Promise.resolve().then(() => c.documents.issue({ ...base, extra: { ...base.extra, horario: '25:99' } })))).toBe('VALIDATION');
    expect(c.documents.issue(base).numberLabel).toBeNull(); // sem número
  });

  it('DOCX: cabeçalho, título, NOME/ENDEREÇO/DATA/HORÁRIO, conselheiros com caixas, avisos em vermelho e rodapé', async () => {
    const c = await makeCore(); const dir = tmp();
    c.registry.updateInstitution('demo', { headerText: 'LINHA 1 DO CABEÇALHO\nLINHA 2 DO CABEÇALHO', address: 'Rua do Órgão, 100 – Bairro - CEP 00000-000', email: 'orgao@exemplo.invalid', phone: '82-90000-0000.' });
    c.signers.create({ serviceId: 'demo', fullName: 'Conselheiro Três Exemplo', roleTitle: 'Conselheiro (exemplo)' });
    const [a, b, d3] = c.signers.listSelectable('demo', 'demo:notificacao').sort((x, y) => x.id - y.id);
    const rec = notif(c, { signers: [{ signerId: a.id }, { signerId: d3.id }], extra: { responsavelTipo: 'Mãe', responsavelNome: 'Maria Exemplo', menorTipo: 'Filha', menorNome: 'Ana Exemplo', endereco: 'Rua Fictícia, 1', dataComparecimento: '2026-11-03', horario: '08:00' }, city: 'Cidade Exemplo/UF', issueDate: '2026-10-20' });
    const r = await exportDocument(rec, c.assets, { dir, baseName: 'notificacao', formats: ['docx'], overwrite: false }, fakePdf);
    const z = await JSZip.loadAsync(fs.readFileSync(r.docxPath!)); const x = await z.file('word/document.xml')!.async('string');
    const text = x.replace(/<[^>]+>/g, '');
    for (const t of ['NOTIFICAÇÃO', 'NOME:', 'MÃE: MARIA EXEMPLO | FILHA: ANA EXEMPLO', 'ENDEREÇO:', 'RUA FICTÍCIA, 1', 'Prezado Sr.(a),', 'DATA', '03/11/2026', 'HORÁRIO', '08h00', 'Cidade Exemplo/UF, 20 de outubro de 2026', 'CONSELHEIRO (S):', 'Aguardamos o seu comparecimento.', 'ATENÇÃO:', 'IMPORTANTE:', 'Art. 249', 'Art. 236', '(RG, CPF, COMPROVANTE DE RESIDÊNCIA)']) expect(text).toContain(t);
    expect((x.match(/<w14:checkbox>/g) ?? []).length).toBe(3); // três conselheiros
    expect((x.match(/<w14:checked w14:val="1"\/>/g) ?? []).length).toBe(2); // dois marcados
    expect(x).toContain('w:color w:val="FF0000"'); expect(x).toContain('<w:pgMar w:top="709" w:right="1134" w:bottom="709" w:left="1418"');
    const order = [a, b, d3].map((s) => s.fullName.toUpperCase()); expect(text.indexOf(order[0])).toBeLessThan(text.indexOf(order[1])); expect(text.indexOf(order[1])).toBeLessThan(text.indexOf(order[2]));
    const hdr = await z.file('word/header1.xml')!.async('string'); expect(hdr.replace(/<[^>]+>/g, '')).toContain('LINHA 2 DO CABEÇALHO');
    const ftr = await z.file('word/footer1.xml')!.async('string'); const ft = ftr.replace(/<[^>]+>/g, ''); expect(ft).toContain('Rua do Órgão, 100'); expect(ft).toContain('E-mail:'); expect(ft).toContain('orgao@exemplo.invalid'); expect(ft).toContain('Telefone: 82-90000-0000.');
  });

  it('textos fixos e lista de conselheiros ficam congelados no documento', async () => {
    const c = await makeCore();
    const rec = notif(c);
    c.auth.unlock('senha-admin-123');
    c.registry.updateTemplate('demo', 'demo:notificacao', { layoutTexts: { greeting: 'Texto novo.' } });
    c.signers.create({ serviceId: 'demo', fullName: 'Chegou Depois Exemplo', roleTitle: 'Cons.' });
    const again = c.documents.get('demo', rec.id);
    expect(again.extra._texts.greeting).toBe('Prezado Sr.(a),'); expect(again.extra._councilors.length).toBe(2);
    expect(notif(c).extra._texts.greeting).toBe('Texto novo.');
  });

  it('marcações dos textos fixos', async () => {
    const { parseMarkup } = await import('../src/main/docs/notificacao');
    expect(parseMarkup('a **b** __c__ !!d!! ^^e^^\nf\tg')).toEqual([
      { text: 'a ', bold: false, underline: false, red: false, big: false }, { text: 'b', bold: true, underline: false, red: false, big: false }, { text: ' ', bold: false, underline: false, red: false, big: false },
      { text: 'c', bold: false, underline: true, red: false, big: false }, { text: ' ', bold: false, underline: false, red: false, big: false }, { text: 'd', bold: true, underline: true, red: true, big: false },
      { text: ' ', bold: false, underline: false, red: false, big: false }, { text: 'e', bold: false, underline: false, red: false, big: true }, { br: true }, { text: 'f', bold: false, underline: false, red: false, big: false }, { tab: true }, { text: 'g', bold: false, underline: false, red: false, big: false }]);
  });

  it('a prévia mostra linhas pontilhadas de fim de folha e o topo do ofício é menor', async () => {
    const c = await makeCore();
    const p = previewHtml(c.documents.preview(input(c)), c.assets);
    expect(p).toContain('class="guide"'); expect(p).toContain('fim da folha 1'); expect(p).toContain('padding:12.5mm 20mm 26.7mm 30mm');
    const n = previewHtml(c.documents.preview(input(c, { templateId: 'demo:notificacao' })), c.assets);
    expect(n).toContain('class="guide"'); expect(n).toContain('NOTIFICAÇÃO');
  });
});
