import { describe, it, expect } from 'vitest';
import * as fs from 'node:fs';
import * as os from 'node:os';
import * as path from 'node:path';
import JSZip from 'jszip';
import { makeCore, input } from './helpers';
import { exportDocument, existingFiles, previewHtml, sanitizeFileName, suggestFileName, PdfRenderer } from '../src/main/docs/export';
import { AppError } from '../src/shared/types';

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'arrumaai-exp-'));
const fakePdf: PdfRenderer = async (html) => Buffer.from(`%PDF-FAKE\n${html.length}`);
const xml = async (file: string) => (await JSZip.loadAsync(fs.readFileSync(file))).file('word/document.xml')!.async('string');
const code = async (p: Promise<unknown>) => { try { await p; } catch (e) { return (e as AppError).code; } return 'NAO-FALHOU'; };

describe('Exportação DOCX', () => {
  it('gera DOCX válido, preservando acentos, número e parágrafos', async () => {
    const c = await makeCore(); const dir = tmp();
    const rec = c.documents.issue(input(c, { body: 'Ação, coração, órgão, ç, ã, õ, ü.\n\nSegundo parágrafo — com travessão.' }));
    const r = await exportDocument(rec, c.assets, { dir, baseName: suggestFileName(rec), formats: ['docx'], overwrite: false }, fakePdf);
    expect(path.basename(r.docxPath!)).toBe('Ofício-001-2026.docx');
    const x = await xml(r.docxPath!);
    for (const t of ['Ação, coração, órgão, ç, ã, õ, ü.', 'Segundo parágrafo — com travessão.', 'Ofício nº 001/2026', 'Assunto: ']) expect(x).toContain(t);
    expect(fs.existsSync(path.join(dir, 'Ofício-001-2026.pdf'))).toBe(false);
  });

  it('suporta de 1 a 4 assinaturas', async () => {
    const c = await makeCore(); const dir = tmp();
    const tpl = c.registry.listTemplates('demo')[0];
    for (const n of ['Ana Quatro Teste', 'Beto Quatro Teste']) c.signers.create({ serviceId: 'demo', fullName: n, roleTitle: 'Cargo (teste)' });
    const ids = c.signers.listSelectable('demo', tpl.id).map((s) => s.id);
    for (const slots of [1, 2, 3, 4]) {
      c.registry.updateTemplate('demo', tpl.id, { signatureSlots: slots });
      const rec = c.documents.issue(input(c, { signers: ids.slice(0, slots).map((signerId) => ({ signerId })) }));
      const r = await exportDocument(rec, c.assets, { dir, baseName: `ass-${slots}`, formats: ['docx'], overwrite: false }, fakePdf);
      const x = await xml(r.docxPath!);
      expect(rec.signers.length).toBe(slots);
      for (const s of rec.signers) expect(x).toContain(s.name);
    }
  });

  it('texto extenso gera várias páginas sem perder conteúdo', async () => {
    const c = await makeCore(); const dir = tmp();
    const body = Array.from({ length: 120 }, (_, i) => `Parágrafo ${i + 1}: ` + 'conteúdo de teste com acentuação. '.repeat(6)).join('\n\n');
    const rec = c.documents.issue(input(c, { body }));
    const r = await exportDocument(rec, c.assets, { dir, baseName: 'longo', formats: ['docx'], overwrite: false }, fakePdf);
    const x = await xml(r.docxPath!);
    expect(x).toContain('Parágrafo 1:'); expect(x).toContain('Parágrafo 120:');
    expect(fs.statSync(r.docxPath!).size).toBeGreaterThan(10_000);
  });

  it('o arquivo é gerado a partir dos dados gravados, não do cadastro atual', async () => {
    const c = await makeCore(); const dir = tmp();
    const rec = c.documents.issue(input(c));
    c.signers.update('demo', rec.signers[0].signerId, { fullName: 'Nome Alterado Depois' });
    const r = await exportDocument(c.documents.get('demo', rec.id), c.assets, { dir, baseName: 'hist', formats: ['docx'], overwrite: false }, fakePdf);
    const x = await xml(r.docxPath!);
    expect(x).toContain(rec.signers[0].name); expect(x).not.toContain('Nome Alterado Depois');
  });
});

describe('Exportação PDF e tratamento de erros', () => {
  it('chama o gerador de PDF com o HTML do documento e grava o arquivo', async () => {
    const c = await makeCore(); const dir = tmp(); let received = '';
    const rec = c.documents.issue(input(c));
    const r = await exportDocument(rec, c.assets, { dir, baseName: 'doc', formats: ['pdf', 'docx'], overwrite: false }, async (h) => { received = h; return Buffer.from('%PDF-1.4 teste'); });
    expect(received).toContain('Ofício nº 001/2026'); expect(received).toContain('Assunto de teste');
    expect(fs.readFileSync(r.pdfPath!, 'utf8')).toContain('%PDF'); expect(fs.existsSync(r.docxPath!)).toBe(true);
  });

  it('não sobrescreve sem confirmação e sobrescreve quando confirmado', async () => {
    const c = await makeCore(); const dir = tmp();
    const rec = c.documents.issue(input(c));
    const o = { dir, baseName: 'mesmo', formats: ['docx' as const], overwrite: false };
    await exportDocument(rec, c.assets, o, fakePdf);
    expect(existingFiles(o).length).toBe(1);
    expect(await code(exportDocument(rec, c.assets, o, fakePdf))).toBe('FILE_EXISTS');
    await exportDocument(rec, c.assets, { ...o, overwrite: true }, fakePdf);
  });

  it('erros: pasta inexistente, caminho relativo, formato vazio, rascunho, falha do PDF (nada fica pela metade)', async () => {
    const c = await makeCore(); const dir = tmp();
    const rec = c.documents.issue(input(c));
    const base = { baseName: 'x', formats: ['docx' as const], overwrite: false };
    expect(await code(exportDocument(rec, c.assets, { ...base, dir: path.join(dir, 'nao-existe') }, fakePdf))).toBe('EXPORT_FAILED');
    expect(await code(exportDocument(rec, c.assets, { ...base, dir: 'relativo' }, fakePdf))).toBe('VALIDATION');
    expect(await code(exportDocument(rec, c.assets, { ...base, dir, formats: [] }, fakePdf))).toBe('VALIDATION');
    expect(await code(exportDocument(c.documents.saveDraft(input(c)), c.assets, { ...base, dir }, fakePdf))).toBe('NOT_ISSUED');
    const quebrado: PdfRenderer = async () => { throw new Error('motor de PDF falhou'); };
    expect(await code(exportDocument(rec, c.assets, { ...base, dir, baseName: 'meia', formats: ['docx', 'pdf'] }, quebrado))).toBe('EXPORT_FAILED');
    expect(fs.readdirSync(dir)).toEqual([]);
  });

  it('nomes de arquivo são higienizados (sem caminhos nem nomes reservados do Windows)', () => {
    expect(sanitizeFileName('../../etc/passwd')).toBe('..-..-etc-passwd');
    expect(sanitizeFileName('Ofício 001/2026.docx')).toBe('Ofício 001-2026');
    expect(sanitizeFileName('CON')).toBe('CON_');
    expect(sanitizeFileName('a<b>c:d"e|f?g*h')).toBe('a-b-c-d-e-f-g-h');
    expect(sanitizeFileName('   ...  ')).toBe('');
    expect(sanitizeFileName('x'.repeat(300)).length).toBe(120);
  });

  it('prévia escapa HTML (texto digitado não vira código)', async () => {
    const c = await makeCore();
    const p = c.documents.preview(input(c, { body: '<script>alert(1)</script><img src=x onerror=alert(2)>', subject: '"><b>x' }));
    const html = previewHtml(p, c.assets);
    expect(html).not.toContain('<script>alert'); expect(html).not.toContain('<img src=x');
    expect(html).toContain('&lt;script&gt;'); expect(html).toContain('PRÉVIA');
  });
});

describe('Texto de abertura no DOCX', () => {
  it('aparece no arquivo Word antes do texto digitado', async () => {
    const c = await makeCore(); const dir = tmp();
    c.registry.updateTemplate('demo', 'demo:oficio', { openingText: 'O Órgão Exemplo, no exercício de suas atribuições, vem, por meio deste,' });
    const rec = c.documents.issue(input(c, { body: 'comunicar o que segue.' }));
    const r = await exportDocument(rec, c.assets, { dir, baseName: 'abertura', formats: ['docx'], overwrite: false }, fakePdf);
    expect(await xml(r.docxPath!)).toContain('O Órgão Exemplo, no exercício de suas atribuições, vem, por meio deste, comunicar o que segue.');
  });
});
