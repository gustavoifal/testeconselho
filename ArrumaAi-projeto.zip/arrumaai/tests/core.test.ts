import { describe, it, expect } from 'vitest';
import * as fs from 'node:fs';
import * as os from 'node:os';
import * as path from 'node:path';
import { makeCore, input } from './helpers';
import { AppCore } from '../src/main/context';
import { AppError } from '../src/shared/types';

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'arrumaai-'));
const expectCode = (fn: () => unknown, code: string) => {
  try { fn(); } catch (e) { expect(e).toBeInstanceOf(AppError); expect((e as AppError).code).toBe(code); return; }
  throw new Error(`Esperava erro ${code}, mas nada foi lançado`);
};

describe('Responsáveis e assinaturas', () => {
  it('cadastra e edita responsáveis (exige modo administrador)', async () => {
    const c = await makeCore();
    const s = c.signers.create({ serviceId: 'demo', fullName: 'Ana Teste Lima', roleTitle: 'Diretora (teste)' });
    expect(s.active).toBe(true);
    const e = c.signers.update('demo', s.id, { fullName: 'Ana Teste Lima Souza', roleTitle: 'Diretora Geral (teste)' });
    expect(e.fullName).toBe('Ana Teste Lima Souza');
    c.auth.lock();
    expectCode(() => c.signers.create({ serviceId: 'demo', fullName: 'Sem Permissão', roleTitle: 'X' }), 'ADMIN_REQUIRED');
    expectCode(() => c.signers.update('demo', s.id, { roleTitle: 'Outro' }), 'ADMIN_REQUIRED');
  });

  it('valida nome e cargo', async () => {
    const c = await makeCore();
    expectCode(() => c.signers.create({ serviceId: 'demo', fullName: 'Al', roleTitle: '' }), 'VALIDATION');
  });

  it('desativar/ocultar responsável preserva o histórico e o remove das opções', async () => {
    const c = await makeCore();
    const tpl = c.registry.listTemplates('demo')[0];
    const [a, b] = c.signers.listSelectable('demo', tpl.id);
    const doc = c.documents.issue(input(c, { signers: [{ signerId: a.id }] }));
    c.signers.setActive('demo', a.id, false);
    expect(c.signers.listSelectable('demo', tpl.id).map((x) => x.id)).toEqual([b.id]);
    c.signers.setActive('demo', a.id, true);
    c.signers.setHidden('demo', a.id, true);
    expect(c.signers.listSelectable('demo', tpl.id).map((x) => x.id)).toEqual([b.id]);
    expect(c.signers.list('demo', true).some((x) => x.id === a.id)).toBe(true);
    expect(c.documents.get('demo', doc.id).signers[0].name).toBe(a.fullName);
    expectCode(() => c.documents.issue(input(c, { signers: [{ signerId: a.id }] })), 'VALIDATION');
  });

  it('seleção dinâmica: só responsáveis ativos e autorizados para o modelo', async () => {
    const c = await makeCore();
    const tpl = c.registry.listTemplates('demo')[0];
    const novo = c.signers.create({ serviceId: 'demo', fullName: 'Carlos Novo Teste', roleTitle: 'Chefe (teste)', templateIds: [] });
    expect(c.signers.listSelectable('demo', tpl.id).some((s) => s.id === novo.id)).toBe(false);
    expectCode(() => c.documents.issue(input(c, { signers: [{ signerId: novo.id }] })), 'VALIDATION');
    c.signers.setAuthorizedTemplates('demo', novo.id, [tpl.id]);
    expect(c.signers.listSelectable('demo', tpl.id).some((s) => s.id === novo.id)).toBe(true);
    c.documents.issue(input(c, { signers: [{ signerId: novo.id }] }));
  });

  it('modelos com duas assinaturas exigem dois responsáveis distintos', async () => {
    const c = await makeCore();
    const tpl = c.registry.listTemplates('demo')[0];
    c.registry.updateTemplate('demo', tpl.id, { signatureSlots: 2 });
    const [a, b] = c.signers.listSelectable('demo', tpl.id);
    expectCode(() => c.documents.issue(input(c, { signers: [{ signerId: a.id }] })), 'VALIDATION');
    expectCode(() => c.documents.issue(input(c, { signers: [{ signerId: a.id }, { signerId: a.id }] })), 'VALIDATION');
    const d = c.documents.issue(input(c, { signers: [{ signerId: a.id }, { signerId: b.id }] }));
    expect(d.signers.map((s) => s.name)).toEqual([a.fullName, b.fullName]);
  });

  it('preserva dados históricos mesmo após alterar cadastro e instituição', async () => {
    const c = await makeCore();
    const tpl = c.registry.listTemplates('demo')[0];
    const [a] = c.signers.listSelectable('demo', tpl.id);
    const doc = c.documents.issue(input(c, { signers: [{ signerId: a.id }] }));
    c.signers.update('demo', a.id, { fullName: 'Nome Totalmente Novo', roleTitle: 'Cargo Novo' });
    c.registry.updateInstitution('demo', { orgName: 'Outro Órgão', footerText: 'Rodapé novo' });
    const again = c.documents.get('demo', doc.id);
    expect(again.signers[0]).toMatchObject({ name: a.fullName, role: a.roleTitle });
    expect(again.institution.orgName).toContain('Demonstração');
    expect(again.institution.footerText).not.toBe('Rodapé novo');
  });
});

describe('Numeração sequencial', () => {
  it('gera 001/2026, 002/2026, 003/2026', async () => {
    const c = await makeCore();
    const labels = [1, 2, 3].map(() => c.documents.issue(input(c)).numberLabel);
    expect(labels).toEqual(['001/2026', '002/2026', '003/2026']);
  });

  it('reinicia por ano quando configurado e não reinicia quando desativado', async () => {
    const c = await makeCore();
    c.documents.issue(input(c, { issueDate: '2026-12-31' }));
    expect(c.documents.issue(input(c, { issueDate: '2027-01-02' })).numberLabel).toBe('001/2027');
    c.registry.updateRule('demo', 'oficio', { resetYearly: false, labelFormat: '{N}' });
    const a = c.documents.issue(input(c, { issueDate: '2027-02-01' }));
    const b = c.documents.issue(input(c, { issueDate: '2028-02-01' }));
    expect([a.numberLabel, b.numberLabel]).toEqual(['001', '002']);
  });

  it('nunca produz números duplicados (muitas emissões seguidas e restrição no banco)', async () => {
    const c = await makeCore();
    const docs = Array.from({ length: 40 }, () => c.documents.issue(input(c)));
    expect(new Set(docs.map((d) => d.seqNumber)).size).toBe(40);
    expect(() => c.db.run(`INSERT INTO documents(service_id, template_id, template_name, category, seq_number, period, number_label, status, issue_date, created_at)
      VALUES ('demo','demo:oficio','Ofício','oficio',5,'2026','005/2026','emitido','2026-03-10','x')`)).toThrow();
  });

  it('abrir formulário, prévia ou rascunho não consome número', async () => {
    const c = await makeCore();
    c.documents.preview(input(c));
    c.documents.saveDraft(input(c));
    expect(c.numbering.peekNext('demo', 'oficio', '2026-03-10').seq).toBe(1);
    expect(c.documents.issue(input(c)).numberLabel).toBe('001/2026');
  });

  it('rascunho emitido recebe número só na emissão', async () => {
    const c = await makeCore();
    const dr = c.documents.saveDraft(input(c));
    expect(dr.status).toBe('rascunho'); expect(dr.numberLabel).toBeNull();
    const e = c.documents.issue(input(c, { subject: 'Assunto final' }), dr.id);
    expect(e).toMatchObject({ id: dr.id, status: 'emitido', numberLabel: '001/2026', subject: 'Assunto final' });
  });

  it('emissão inválida ou com falha não consome número', async () => {
    const c = await makeCore();
    expectCode(() => c.documents.issue(input(c, { subject: '' })), 'VALIDATION');
    expectCode(() => c.documents.issue(input(c, { signers: [{ signerId: 99999 }] })), 'VALIDATION');
    expect(c.documents.issue(input(c)).numberLabel).toBe('001/2026');
  });

  it('cancelamento mantém o registro e não reutiliza o número', async () => {
    const c = await makeCore();
    const d1 = c.documents.issue(input(c));
    const canc = c.documents.cancel('demo', d1.id, 'Emitido com destinatário errado');
    expect(canc.status).toBe('cancelado');
    expect(c.documents.issue(input(c)).numberLabel).toBe('002/2026');
    expect(c.numbering.sequence('demo', 'oficio', 2026).map((r) => [r.numberLabel, r.status])).toEqual([['001/2026', 'cancelado'], ['002/2026', 'emitido']]);
    expectCode(() => c.documents.cancel('demo', d1.id, 'Cancelando de novo'), 'INVALID_STATE');
    expectCode(() => c.documents.cancel('demo', d1.id, 'x'), 'VALIDATION');
  });

  it('documentos emitidos não podem ser alterados nem excluídos (nem por SQL direto)', async () => {
    const c = await makeCore();
    const d = c.documents.issue(input(c));
    expect(() => c.db.run('UPDATE documents SET number_label = ? WHERE id = ?', ['999/2026', d.id])).toThrow(/não pode ser alterado/);
    expect(() => c.db.run('UPDATE documents SET body = ? WHERE id = ?', ['adulterado', d.id])).toThrow();
    expect(() => c.db.run('UPDATE documents SET signers_snapshot = ? WHERE id = ?', ['[]', d.id])).toThrow();
    expect(() => c.db.run('DELETE FROM documents WHERE id = ?', [d.id])).toThrow(/excluídos/);
    expect(() => c.db.run('UPDATE numbering_counters SET last_number = 0')).toThrow(/retroceder/);
    expect(() => c.db.run('DELETE FROM audit_log')).toThrow();
    expect(c.documents.get('demo', d.id).body).toBe(d.body);
  });

  it('só é possível avançar o contador (nunca recuar) e a ação é auditada', async () => {
    const c = await makeCore();
    c.numbering.setNext('demo', 'oficio', 2026, 38);
    expect(c.documents.issue(input(c)).numberLabel).toBe('038/2026');
    expectCode(() => c.numbering.setNext('demo', 'oficio', 2026, 10), 'NUMBERING_BACKWARDS');
    c.auth.lock();
    expectCode(() => c.numbering.setNext('demo', 'oficio', 2026, 500), 'ADMIN_REQUIRED');
    expect(c.audit.list('demo').some((a) => a.action === 'numeracao.proximo_definido')).toBe(true);
  });
});

describe('Validação e histórico', () => {
  it('apresenta mensagens por campo para dados ausentes', async () => {
    const c = await makeCore();
    try { c.documents.issue(input(c, { recipient: '', subject: '  ', body: '' })); throw new Error('não falhou'); }
    catch (e) {
      const fields = (e as AppError).fields!.map((f) => f.field);
      expect(fields).toEqual(expect.arrayContaining(['recipient', 'subject', 'body']));
    }
  });

  it('campos obrigatórios são definidos por modelo', async () => {
    const c = await makeCore();
    const tpl = c.registry.listTemplates('demo')[0];
    c.registry.updateTemplate('demo', tpl.id, { requiredFields: ['subject', 'body'] });
    expect(c.documents.issue(input(c, { recipient: '', recipientRole: '' })).status).toBe('emitido');
    expectCode(() => c.registry.updateTemplate('demo', tpl.id, { requiredFields: ['recipient'] }), 'VALIDATION');
  });

  it('busca por número, destinatário, assunto, período, tipo e situação', async () => {
    const c = await makeCore();
    c.documents.issue(input(c, { recipient: 'Escola Alfa', subject: 'Matrícula', issueDate: '2026-01-15' }));
    const d2 = c.documents.issue(input(c, { recipient: 'Posto Beta', subject: 'Vacinação', issueDate: '2026-05-20' }));
    c.documents.cancel('demo', d2.id, 'Motivo de teste');
    const s = (f: object) => c.documents.search('demo', f).rows.map((r) => r.numberLabel);
    expect(s({ recipient: 'alfa' })).toEqual(['001/2026']);
    expect(s({ subject: 'vacina' })).toEqual(['002/2026']);
    expect(s({ number: '002' })).toEqual(['002/2026']);
    expect(s({ from: '2026-04-01', to: '2026-06-30' })).toEqual(['002/2026']);
    expect(s({ status: 'cancelado' })).toEqual(['002/2026']);
    expect(s({ templateId: 'demo:oficio' }).length).toBe(2);
    expect(s({ recipient: '%' })).toEqual([]);
  });
});

describe('Isolamento entre serviços', () => {
  it('serviços têm cadastros, numeração e documentos separados', async () => {
    const c = await makeCore();
    c.registry.createService({ id: 'outro', name: 'Outro Serviço de Teste', orgName: 'Órgão Teste B' });
    const s2 = c.signers.create({ serviceId: 'outro', fullName: 'Pessoa do Outro Serviço', roleTitle: 'Cargo B' });
    const t2 = c.registry.listTemplates('outro')[0];
    const dDemo = c.documents.issue(input(c));
    const dOutro = c.documents.issue({ ...input(c), serviceId: 'outro', templateId: t2.id, signers: [{ signerId: s2.id }] });
    expect([dDemo.numberLabel, dOutro.numberLabel]).toEqual(['001/2026', '001/2026']);
    expectCode(() => c.documents.get('outro', dDemo.id), 'NOT_FOUND');
    expectCode(() => c.signers.get('demo', s2.id), 'NOT_FOUND');
    expect(c.documents.search('outro').rows.length).toBe(1);
    expectCode(() => c.documents.issue({ ...input(c), serviceId: 'outro', templateId: 'demo:oficio', signers: [{ signerId: s2.id }] }), 'NOT_FOUND');
    expectCode(() => c.documents.issue({ ...input(c), serviceId: 'outro', templateId: t2.id }), 'VALIDATION'); // assinante do demo
    expectCode(() => c.documents.cancel('outro', dDemo.id, 'tentando cancelar de outro serviço'), 'NOT_FOUND');
  });
});

describe('Persistência', () => {
  it('mantém dados após reiniciar (reabrir o arquivo)', async () => {
    const dir = tmp(); const file = path.join(dir, 'arrumaai.db');
    const c1 = await makeCore({ dbFile: file });
    c1.signers.create({ serviceId: 'demo', fullName: 'Pessoa Persistente', roleTitle: 'Cargo' });
    const d = c1.documents.issue(input(c1));
    const c2 = await AppCore.create({ dbFile: file, now: () => new Date('2026-03-10T12:00:00Z') });
    expect(c2.documents.get('demo', d.id).numberLabel).toBe('001/2026');
    expect(c2.signers.list('demo').some((s) => s.fullName === 'Pessoa Persistente')).toBe(true);
    expect(c2.auth.hasPassword()).toBe(true);
    expect(c2.documents.issue(input(c2)).numberLabel).toBe('002/2026');
    expect(c2.registry.listServices().length).toBe(1); // demo não é duplicado
  });

  it('falha ao gravar no disco desfaz a emissão (consistência)', async () => {
    const dir = tmp(); const file = path.join(dir, 'x.db');
    let broken = false;
    const c = await makeCore({ dbFile: file, writeFile: (f, d) => { if (broken) throw new Error('disco cheio'); fs.writeFileSync(f, d); } });
    c.documents.issue(input(c));
    broken = true;
    expectCode(() => c.documents.issue(input(c)), 'DB_WRITE');
    broken = false;
    expect(c.documents.search('demo').total).toBe(1);
    expect(c.documents.issue(input(c)).numberLabel).toBe('002/2026');
  });
});

describe('Administração e auditoria', () => {
  it('configurações institucionais exigem administrador, são validadas e auditadas', async () => {
    const c = await makeCore();
    c.registry.updateInstitution('demo', { phone: '(11) 1111-1111', email: 'a@b.co' });
    expectCode(() => c.registry.updateInstitution('demo', { email: 'invalido' }), 'VALIDATION');
    c.auth.lock();
    expectCode(() => c.registry.updateInstitution('demo', { phone: '1' }), 'ADMIN_REQUIRED');
    expect(c.audit.list('demo').some((a) => a.action === 'instituicao.alterada')).toBe(true);
  });

  it('senha de administrador: não fica em texto puro, bloqueia após tentativas erradas', async () => {
    const c = await makeCore();
    const stored = c.db.get<{ value: string }>("SELECT value FROM app_prefs WHERE key='admin_hash'")!.value;
    expect(stored).not.toContain('senha-admin-123');
    c.auth.lock();
    for (let i = 0; i < 5; i++) expectCode(() => c.auth.unlock('errada-errada'), 'AUTH_FAILED');
    expectCode(() => c.auth.unlock('senha-admin-123'), 'AUTH_THROTTLED');
  });

  it('logomarca: aceita PNG/JPG e rejeita outros formatos e tamanhos excessivos', async () => {
    const c = await makeCore();
    const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(100)]);
    expect(c.registry.setLogoBytes('demo', png).logoHash).toBeTruthy();
    expectCode(() => c.registry.setLogoBytes('demo', Buffer.from('<svg onload=alert(1)></svg>')), 'IMAGE_INVALID');
    expectCode(() => c.registry.setLogoBytes('demo', Buffer.concat([png, Buffer.alloc(3 * 1024 * 1024)])), 'IMAGE_TOO_BIG');
  });
});

describe('Backup e restauração', () => {
  it('cria e restaura backup (sem senha e com senha), e rejeita senha errada/arquivo inválido', async () => {
    const dir = tmp();
    const c = await makeCore({ dbFile: path.join(dir, 'a.db') });
    c.documents.issue(input(c));
    const plain = c.backup.create(dir);
    const enc = c.backup.create(dir, 'senha-do-backup');
    expect(fs.readFileSync(enc).includes(Buffer.from('Maria Exemplo'))).toBe(false); // criptografado
    c.documents.issue(input(c)); // 2º documento, depois do backup
    expect(c.documents.search('demo').total).toBe(2);
    c.backup.restore(plain, path.join(dir, 'seg'));
    expect(c.documents.search('demo').total).toBe(1);
    expect(fs.readdirSync(path.join(dir, 'seg')).length).toBe(1);
    expectCode(() => c.backup.restore(enc, path.join(dir, 'seg'), 'errada-errada'), 'BACKUP_PASSWORD');
    expectCode(() => c.backup.restore(enc, path.join(dir, 'seg')), 'BACKUP_PASSWORD');
    c.backup.restore(enc, path.join(dir, 'seg'), 'senha-do-backup');
    const lixo = path.join(dir, 'lixo.arrumaai-bkp'); fs.writeFileSync(lixo, 'isso não é um backup');
    expectCode(() => c.backup.restore(lixo, path.join(dir, 'seg')), 'BACKUP_INVALID');
    expect(c.documents.issue(input(c)).numberLabel).toBe('002/2026'); // numeração restaurada coerente
    c.auth.lock();
    expectCode(() => c.backup.create(dir), 'ADMIN_REQUIRED');
  });

  it('backup automático diário mantém só os últimos arquivos', async () => {
    const dir = tmp(); let day = 1;
    const c = await makeCore({ dbFile: path.join(dir, 'a.db'), now: () => new Date(Date.UTC(2026, 2, day, 12)) });
    const auto = path.join(dir, 'auto');
    for (day = 1; day <= 5; day++) c.backup.auto(auto, 3);
    day = 5;
    expect(c.backup.auto(auto, 3)).toBeNull(); // mesmo dia
    expect(fs.readdirSync(auto).length).toBe(3);
  });
});

describe('Texto de abertura fixo e cabeçalho', () => {
  const OPEN = 'O Conselho Tutelar dos Direitos da Criança e do Adolescente de Cidade Exemplo/UF, no exercício de suas atribuições (texto fictício), vem, por meio deste,';

  it('só o administrador define o texto; é gravado no documento e não muda depois', async () => {
    const c = await makeCore();
    const tpl = c.registry.listTemplates('demo')[0];
    c.auth.lock();
    expectCode(() => c.registry.updateTemplate('demo', tpl.id, { openingText: OPEN }), 'ADMIN_REQUIRED');
    c.auth.unlock('senha-admin-123');
    expect(c.registry.updateTemplate('demo', tpl.id, { openingText: OPEN }).openingText).toBe(OPEN);
    const d = c.documents.issue(input(c));
    expect(d.openingText).toBe(OPEN);
    c.registry.updateTemplate('demo', tpl.id, { openingText: 'Texto novo.' });
    expect(c.documents.get('demo', d.id).openingText).toBe(OPEN);
    expect(() => c.db.run('UPDATE documents SET opening_text = ? WHERE id = ?', ['adulterado', d.id])).toThrow(/não pode ser alterado/);
  });

  it('o texto fixo abre o corpo, na mesma frase; o cabeçalho separa endereço e contatos', async () => {
    const { buildLayout } = await import('../src/main/docs/layout');
    const c = await makeCore();
    const tpl = c.registry.listTemplates('demo')[0];
    c.registry.updateTemplate('demo', tpl.id, { openingText: OPEN });
    const rec = c.documents.issue(input(c, { body: 'solicita informações sobre o caso.\n\nSegundo parágrafo.' }));
    const L = buildLayout(rec, c.assets);
    const paras = L.blocks.filter((b) => b.t === 'para').map((b: any) => b.text);
    expect(paras).toContain(`${OPEN} solicita informações sobre o caso.`);
    const header: any = L.blocks[0];
    const texts = header.lines.map((l: any) => l.text);
    const iAddr = texts.findIndex((t: string) => t.includes('Rua Exemplo'));
    expect(texts[iAddr]).not.toContain('(00) 0000-0000');
    expect(texts[iAddr + 1]).toBe('(00) 0000-0000 • contato@exemplo.invalid');
  });

  it('documentos anteriores (sem texto de abertura) continuam iguais', async () => {
    const c = await makeCore();
    expect(c.documents.issue(input(c)).openingText).toBe('');
  });
});

describe('Atualização de versão do banco', () => {
  it('um banco criado na versão 1 é atualizado sem perder documentos', async () => {
    const { Db } = await import('../src/main/db/database');
    const { MIGRATIONS, migrate } = await import('../src/main/db/migrations');
    const dir = tmp(); const file = path.join(dir, 'antigo.db');
    const old = await Db.open(file);
    old.exec('CREATE TABLE schema_migrations (version INTEGER PRIMARY KEY, name TEXT NOT NULL, applied_at TEXT NOT NULL)');
    old.transaction(() => { old.exec(MIGRATIONS[0].sql); old.run('INSERT INTO schema_migrations VALUES (1, ?, ?)', ['esquema-inicial', 'x']); });
    old.run("INSERT INTO services(id,name,org_name,is_demo,active,created_at) VALUES ('s','S','O',0,1,'x')");
    old.run("INSERT INTO templates(id,service_id,kind,category,name,required_fields,signature_slots) VALUES ('s:oficio','s','oficio','oficio','Ofício','[]',1)");
    old.run("INSERT INTO documents(service_id,template_id,template_name,category,seq_number,period,number_label,status,issue_date,created_at) VALUES ('s','s:oficio','Ofício','oficio',7,'2026','007/2026','emitido','2026-01-01','x')");
    old.close();
    const c = await AppCore.create({ dbFile: file, seedDemo: false });
    const doc = c.documents.get('s', 1);
    expect(doc.numberLabel).toBe('007/2026'); expect(doc.openingText).toBe('');
    expect(c.registry.getTemplate('s', 's:oficio').openingText).toBe('');
    expect(() => c.db.run('UPDATE documents SET body = ? WHERE id = 1', ['x'])).toThrow();
    expect(migrate).toBeTypeOf('function');
  });
});
