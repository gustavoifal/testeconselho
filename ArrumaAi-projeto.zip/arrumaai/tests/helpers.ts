import { AppCore } from '../src/main/context';
import { DocumentInput } from '../src/shared/types';

export async function makeCore(opts: { dbFile?: string | null; now?: () => Date; writeFile?: (f: string, d: Uint8Array) => void } = {}) {
  const core = await AppCore.create({ dbFile: opts.dbFile ?? null, now: opts.now ?? (() => new Date('2026-03-10T12:00:00Z')), writeFile: opts.writeFile });
  if (!core.auth.hasPassword()) core.auth.setPassword('senha-admin-123');
  return core;
}

export function input(core: AppCore, over: Partial<DocumentInput> = {}, serviceId = 'demo'): DocumentInput {
  const tpl = core.registry.listTemplates(serviceId)[0];
  const signer = core.signers.listSelectable(serviceId, tpl.id)[0];
  return {
    serviceId, templateId: tpl.id, recipient: 'Prezado Destinatário Exemplo', recipientRole: 'Cargo Exemplo',
    subject: 'Assunto de teste', body: 'Primeiro parágrafo com acentuação: ação, coração, órgão.\n\nSegundo parágrafo.',
    city: 'Cidade Exemplo/UF', issueDate: '2026-03-10', signers: [{ signerId: signer.id }], ...over,
  };
}
