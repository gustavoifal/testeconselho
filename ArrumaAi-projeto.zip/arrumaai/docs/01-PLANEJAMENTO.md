# ArrumaAí — Etapa 1: Planejamento

## Arquitetura
- **main (Electron)**: único processo com acesso a banco, arquivos e geração de documentos.
- **preload**: expõe `window.api` com funções fixas; cada uma valida entradas.
- **renderer (React)**: só interface; nunca toca em banco ou disco.
- **core (src/main/services)**: regras de negócio puras, testáveis sem Electron.

## Decisões técnicas
- Banco: `sql.js` (SQLite em WebAssembly, sem módulo nativo). Gravação atômica (arquivo temporário + renomear) após cada transação. Elimina erro de compilação no Windows.
- PDF: `printToPDF` do Electron (offline). DOCX: biblioteca `docx`.
- Instalador: GitHub Actions em máquina Windows + Electron Builder (NSIS).

## Riscos
1. Instalador e janela real não são testáveis no ambiente Linux → build no GitHub.
2. PDF depende do Electron; testado no app, a lógica de HTML é testada aqui.
3. Dados pessoais (Conselho Tutelar) → demo só com dados fictícios; limitações em docs/SEGURANCA.md.

## Numeração
- Rascunho NÃO consome número. Número é reservado na emissão, dentro de uma transação SQL, junto com a gravação do documento (reserva e confirmação atômicas).
- Cancelado nunca reutiliza número. Reinício anual configurável.

## Esquema do banco (resumo)
services, institution_settings, signers, templates, template_signers, numbering_rules, numbering_counters, documents (com snapshot JSON de assinantes), audit_log, app_prefs, schema_migrations.
