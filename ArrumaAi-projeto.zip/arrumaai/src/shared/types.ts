export class AppError extends Error {
  constructor(public code: string, message: string, public fields?: FieldError[]) {
    super(message);
    this.name = 'AppError';
  }
}
export interface FieldError { field: string; message: string }

export type OptionKind = 'orgao' | 'cargo';
export interface RecipientOption { id: number; kind: OptionKind; label: string }

export type DocStatus = 'rascunho' | 'emitido' | 'cancelado';

export interface ServiceInfo { id: string; name: string; orgName: string; isDemo: boolean; active: boolean }

export interface Institution {
  serviceId: string; orgName: string; serviceName: string; city: string;
  address: string; phone: string; email: string; headerText: string; footerText: string; extraInfo: string;
  logoHash: string | null; fontFamily: string; fontSizePx: number; titleSizePx: number; orgSizePx: number; serviceSizePx: number;
}
export type InstitutionPatch = Partial<Omit<Institution, 'serviceId' | 'logoHash'>>;

export interface TemplateInfo {
  id: string; serviceId: string; kind: string; category: string; name: string;
  requiredFields: string[]; signatureSlots: number; openingText: string; closingText: string; enabled: boolean;
  numbered: boolean; hasRecipient: boolean; hasIdentification: boolean; identificationFields: string[]; bodyLabel: string;
}

export interface NumberingRule { serviceId: string; category: string; labelFormat: string; padding: number; resetYearly: boolean }

export interface Signer {
  id: number; serviceId: string; fullName: string; roleTitle: string;
  active: boolean; hidden: boolean; hasSignatureImage: boolean; templateIds: string[];
}
export interface SignerInput { serviceId: string; fullName: string; roleTitle: string; templateIds?: string[] }

export interface SignerPick { signerId: number; useImage?: boolean }
export interface DocumentInput {
  serviceId: string; templateId: string; recipient: string; recipientRole: string;
  subject: string; body: string; city: string; issueDate: string; signers: SignerPick[]; identification: string[]; skipIdentification?: boolean;
}

export interface SignerSnapshot { signerId: number; name: string; role: string; imageHash: string | null }
export interface InstitutionSnapshot {
  orgName: string; serviceName: string; address: string; phone: string; email: string;
  headerText: string; footerText: string; extraInfo: string; logoHash: string | null;
  fontFamily: string; fontSizePt: number;
  /** Tamanhos em px (documentos antigos não têm estes campos e usam fontSizePt). */
  fontSizePx?: number; titleSizePx?: number; orgSizePx?: number; serviceSizePx?: number;
}

export interface DocumentRecord {
  id: number; serviceId: string; templateId: string; templateName: string; category: string;
  seqNumber: number | null; period: string | null; numberLabel: string | null; status: DocStatus;
  recipient: string; recipientRole: string; subject: string; body: string; city: string; issueDate: string;
  openingText: string; closingText: string; numbered: boolean; identification: { label: string; value: string }[];
  signers: SignerSnapshot[]; institution: InstitutionSnapshot;
  docxPath: string | null; pdfPath: string | null; createdAt: string; issuedAt: string | null;
  cancelledAt: string | null; cancelReason: string | null;
}

export interface SearchFilters {
  number?: string; recipient?: string; subject?: string; templateId?: string; status?: DocStatus;
  from?: string; to?: string; limit?: number; offset?: number;
}
export interface SequenceRow { seqNumber: number; numberLabel: string; status: DocStatus; documentId: number | null; issueDate: string | null }
export interface Stats { total: number; emitido: number; cancelado: number; rascunho: number; lastIssued: string | null }

export interface RecentIdentification { fields: { label: string; value: string }[]; lastUsed: string; count: number }
export interface StatsReport {
  from: string; to: string;
  totals: { emitido: number; cancelado: number; total: number };
  byType: { name: string; emitido: number; cancelado: number }[];
  typeNames: string[];
  months: { month: string; counts: Record<string, number>; emitido: number; cancelado: number }[];
  byRecipient: { name: string; count: number }[];
  bySigner: { name: string; count: number }[];
}

export const MONTHS_PT = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
