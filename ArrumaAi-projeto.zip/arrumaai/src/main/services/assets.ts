import * as crypto from 'node:crypto';
import * as fs from 'node:fs';
import { Db } from '../db/database';
import { AppError } from '../../shared/types';

export interface Asset { hash: string; mime: 'image/png' | 'image/jpeg'; data: Uint8Array }

export const LOGO_MAX_BYTES = 2 * 1024 * 1024;
export const SIGNATURE_MAX_BYTES = 1 * 1024 * 1024;

export function detectMime(b: Uint8Array): Asset['mime'] | null {
  if (b.length > 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return 'image/png';
  if (b.length > 4 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'image/jpeg';
  return null;
}

/** Imagens ficam dentro do banco (endereçadas pelo hash), então entram nos backups e não dependem de caminhos no disco. */
export class AssetStore {
  constructor(private db: Db, private now: () => Date) {}

  store(bytes: Uint8Array, maxBytes: number): string {
    if (bytes.length === 0) throw new AppError('IMAGE_INVALID', 'O arquivo de imagem está vazio.');
    if (bytes.length > maxBytes) throw new AppError('IMAGE_TOO_BIG', `A imagem é grande demais (máximo de ${Math.round(maxBytes / 1024 / 1024)} MB).`);
    const mime = detectMime(bytes);
    if (!mime) throw new AppError('IMAGE_INVALID', 'Formato de imagem não aceito. Use PNG ou JPG.');
    const hash = crypto.createHash('sha256').update(bytes).digest('hex');
    this.db.run('INSERT OR IGNORE INTO assets(hash, mime, data, created_at) VALUES (?,?,?,?)', [hash, mime, bytes, this.now().toISOString()]);
    return hash;
  }

  storeFromFile(file: string, maxBytes: number): string {
    let st: fs.Stats;
    try { st = fs.statSync(file); } catch { throw new AppError('IMAGE_INVALID', 'Não foi possível ler o arquivo selecionado.'); }
    if (!st.isFile()) throw new AppError('IMAGE_INVALID', 'O item selecionado não é um arquivo.');
    if (st.size > maxBytes) throw new AppError('IMAGE_TOO_BIG', `A imagem é grande demais (máximo de ${Math.round(maxBytes / 1024 / 1024)} MB).`);
    return this.store(fs.readFileSync(file), maxBytes);
  }

  get(hash: string | null): Asset | null {
    if (!hash) return null;
    const r = this.db.get<{ hash: string; mime: Asset['mime']; data: Uint8Array }>('SELECT hash, mime, data FROM assets WHERE hash = ?', [hash]);
    return r ? { hash: r.hash, mime: r.mime, data: r.data } : null;
  }
}
