import { Deps, Registry } from './registry';
import { NumberingService } from './numbering';
import { SignerService } from './signers';
import { clean, fail, isValidIsoDate, likeEscape } from './util';
import { AppError, DocumentInput, DocumentRecord, FieldError, SearchFilters, SignerSnapshot, Stats, TemplateInfo } from '../../shared/types';

const FIELD_LABEL: Record<string, string> = { recipient: 'Destinatário', recipientRole: 'Cargo do destinatário', subject: 'Assunto', body: 'Corpo do texto', city: 'Cidade' };

export class DocumentService {
  constructor(private d: Deps, private registry: Registry, private numbering: NumberingService, private signers: SignerService) {}

  private map(r: any): DocumentRecord {
    return {
      id: r.id, serviceId: r.service_id, templateId: r.template_id, templateName: r.template_name, category: r.category,
      seqNumber: r.seq_number, period: r.period, numberLabel: r.number_label, status: r.status, recipient: r.recipient,
      recipientRole: r.recipient_role, subject: r.subject, body: r.body, city: r.city, issueDate: r.issue_date, closingText: r.closing_text,
      signers: JSON.parse(r.signers_snapshot), institution: JSON.parse(r.institution_snapshot), docxPath: r.docx_path, pdfPath: r.pdf_path,
      createdAt: r.created_at, issuedAt: r.issued_at, cancelledAt: r.cancelled_at, cancelReason: r.cancel_reason,
    };
  }

  /** Limpa e limita os textos. Nunca preenche nada sozinho. */
  private normalize(i: DocumentInput): DocumentInput {
    if (!i || typeof i !== 'object') throw new AppError('VALIDATION', 'Dados do documento inválidos.');
    const picks = Array.isArray(i.signers) ? i.signers : [];
    return {
      serviceId: String(i.serviceId ?? ''), templateId: String(i.templateId ?? ''),
      recipient: clean(i.recipient, 200), recipientRole: clean(i.recipientRole, 200), subject: clean(i.subject, 300),
      body: clean(i.body, 50_000, true), city: clean(i.city, 80), issueDate: String(i.issueDate ?? ''),
      signers: picks.map((p) => ({ signerId: Number(p?.signerId), useImage: !!p?.useImage })),
    };
  }

  validate(input: DocumentInput, tpl: TemplateInfo, strict: boolean): FieldError[] {
    const errors: FieldError[] = [];
    if (!isValidIsoDate(input.issueDate)) errors.push({ field: 'issueDate', message: 'Data de emissão inválida.' });
    if (strict) {
      for (const f of tpl.requiredFields) {
        if (!(input as any)[f]) errors.push({ field: f, message: `${FIELD_LABEL[f] ?? f}: campo obrigatório.` });
      }
      if (input.signers.length !== tpl.signatureSlots) {
        errors.push({ field: 'signers', message: tpl.signatureSlots === 1 ? 'Selecione quem vai assinar.' : `Selecione os ${tpl.signatureSlots} responsáveis que vão assinar.` });
      }
    } else if (input.signers.length > tpl.signatureSlots) {
      errors.push({ field: 'signers', message: `Este modelo aceita no máximo ${tpl.signatureSlots} assinatura(s).` });
    }
    const ids = input.signers.map((s) => s.signerId);
    if (ids.some((x) => !Number.isInteger(x))) errors.push({ field: 'signers', message: 'Responsável inválido.' });
    if (new Set(ids).size !== ids.length) errors.push({ field: 'signers', message: 'O mesmo responsável não pode assinar duas vezes.' });
    return errors;
  }

  private resolveSigners(input: DocumentInput, tpl: TemplateInfo, strict: boolean): SignerSnapshot[] {
    const allowed = new Map(this.signers.listSelectable(input.serviceId, tpl.id).map((s) => [s.id, s]));
    const out: SignerSnapshot[] = [];
    for (const p of input.signers) {
      const s = allowed.get(p.signerId);
      if (!s) {
        if (strict) {
          const raw = this.d.db.get<{ full_name: string }>('SELECT full_name FROM signers WHERE id = ? AND service_id = ?', [p.signerId, input.serviceId]);
          fail([{ field: 'signers', message: raw ? `"${raw.full_name}" não está disponível para assinar este modelo.` : 'Responsável não encontrado neste serviço.' }]);
        }
        continue;
      }
      const row = this.d.db.get<{ signature_hash: string | null }>('SELECT signature_hash FROM signers WHERE id = ?', [s.id]);
      out.push({ signerId: s.id, name: s.fullName, role: s.roleTitle, imageHash: p.useImage && row?.signature_hash ? row.signature_hash : null });
    }
    return out;
  }

  private context(raw: DocumentInput, strict: boolean) {
    const input = this.normalize(raw);
    this.registry.requireService(input.serviceId);
    const tpl = this.registry.getTemplate(input.serviceId, input.templateId);
    const errors = this.validate(input, tpl, strict);
    if (errors.length) fail(errors);
    return { input, tpl };
  }

  /** Registro provisório para a prévia: não grava nada e não consome número. */
  preview(raw: DocumentInput): DocumentRecord {
    const { input, tpl } = this.context(raw, false);
    const next = this.numbering.peekNext(input.serviceId, tpl.category, input.issueDate);
    return {
      id: 0, serviceId: input.serviceId, templateId: tpl.id, templateName: tpl.name, category: tpl.category, seqNumber: null, period: null,
      numberLabel: next.label, status: 'rascunho', recipient: input.recipient, recipientRole: input.recipientRole, subject: input.subject,
      body: input.body, city: input.city, issueDate: input.issueDate, closingText: tpl.closingText,
      signers: this.resolveSigners(input, tpl, false), institution: this.registry.snapshot(input.serviceId),
      docxPath: null, pdfPath: null, createdAt: this.d.now().toISOString(), issuedAt: null, cancelledAt: null, cancelReason: null,
    };
  }

  saveDraft(raw: DocumentInput, draftId?: number): DocumentRecord {
    const { input, tpl } = this.context(raw, false);
    return this.d.db.transaction(() => {
      const signers = JSON.stringify(this.resolveSigners(input, tpl, false));
      const inst = JSON.stringify(this.registry.snapshot(input.serviceId));
      let id = draftId;
      if (id) {
        this.requireDraft(input.serviceId, id);
        this.d.db.run(`UPDATE documents SET template_id=?, template_name=?, category=?, recipient=?, recipient_role=?, subject=?, body=?, city=?, issue_date=?,
          closing_text=?, signers_snapshot=?, institution_snapshot=? WHERE id=? AND status='rascunho'`,
          [tpl.id, tpl.name, tpl.category, input.recipient, input.recipientRole, input.subject, input.body, input.city, input.issueDate, tpl.closingText, signers, inst, id]);
      } else {
        id = this.d.db.run(`INSERT INTO documents(service_id, template_id, template_name, category, status, recipient, recipient_role, subject, body, city, issue_date,
          closing_text, signers_snapshot, institution_snapshot, created_at) VALUES (?,?,?,?, 'rascunho', ?,?,?,?,?,?,?,?,?,?)`,
          [input.serviceId, tpl.id, tpl.name, tpl.category, input.recipient, input.recipientRole, input.subject, input.body, input.city, input.issueDate, tpl.closingText, signers, inst, this.d.now().toISOString()]).lastId;
        this.d.audit.log(input.serviceId, 'documento.rascunho_criado', 'document', id);
      }
      return this.get(input.serviceId, id);
    });
  }

  private requireDraft(serviceId: string, id: number) {
    const r = this.d.db.get('SELECT status FROM documents WHERE id = ? AND service_id = ?', [Number(id), serviceId]);
    if (!r) throw new AppError('NOT_FOUND', 'Documento não encontrado neste serviço.');
    if (r.status !== 'rascunho') throw new AppError('NOT_DRAFT', 'Este documento já foi emitido e não pode mais ser editado.');
  }

  deleteDraft(serviceId: string, id: number): void {
    this.d.db.transaction(() => {
      this.requireDraft(serviceId, id);
      this.d.db.run("DELETE FROM documents WHERE id = ? AND status = 'rascunho'", [id]);
      this.d.audit.log(serviceId, 'documento.rascunho_excluido', 'document', id);
    });
  }

  /**
   * EMISSÃO: valida, reserva o número e grava o documento (com cópia dos dados de assinatura e instituição)
   * na mesma transação. Se algo falhar, nada é gravado e nenhum número é consumido.
   */
  issue(raw: DocumentInput, draftId?: number): DocumentRecord {
    const { input, tpl } = this.context(raw, true);
    return this.d.db.transaction(() => {
      if (draftId) this.requireDraft(input.serviceId, draftId);
      const signers = JSON.stringify(this.resolveSigners(input, tpl, true));
      const inst = JSON.stringify(this.registry.snapshot(input.serviceId));
      const n = this.numbering.reserveNext(input.serviceId, tpl.category, input.issueDate);
      const ts = this.d.now().toISOString();
      let id: number;
      if (draftId) {
        const r = this.d.db.run(`UPDATE documents SET template_id=?, template_name=?, category=?, seq_number=?, period=?, number_label=?, status='emitido',
          recipient=?, recipient_role=?, subject=?, body=?, city=?, issue_date=?, closing_text=?, signers_snapshot=?, institution_snapshot=?, issued_at=?
          WHERE id=? AND status='rascunho'`,
          [tpl.id, tpl.name, tpl.category, n.seq, n.period, n.label, input.recipient, input.recipientRole, input.subject, input.body, input.city, input.issueDate, tpl.closingText, signers, inst, ts, draftId]);
        if (r.changes !== 1) throw new AppError('NOT_DRAFT', 'Não foi possível emitir o rascunho.');
        id = draftId;
      } else {
        id = this.d.db.run(`INSERT INTO documents(service_id, template_id, template_name, category, seq_number, period, number_label, status, recipient, recipient_role,
          subject, body, city, issue_date, closing_text, signers_snapshot, institution_snapshot, created_at, issued_at) VALUES (?,?,?,?,?,?,?, 'emitido', ?,?,?,?,?,?,?,?,?,?,?)`,
          [input.serviceId, tpl.id, tpl.name, tpl.category, n.seq, n.period, n.label, input.recipient, input.recipientRole, input.subject, input.body, input.city, input.issueDate, tpl.closingText, signers, inst, ts, ts]).lastId;
      }
      this.d.audit.log(input.serviceId, 'documento.emitido', 'document', id, { numero: n.label, modelo: tpl.name });
      return this.get(input.serviceId, id);
    });
  }

  /** Cancela sem apagar e sem reaproveitar o número. */
  cancel(serviceId: string, id: number, reason: string): DocumentRecord {
    const why = clean(reason, 500);
    if (why.length < 5) fail([{ field: 'reason', message: 'Informe o motivo do cancelamento (mínimo de 5 caracteres).' }]);
    return this.d.db.transaction(() => {
      const cur = this.get(serviceId, id);
      if (cur.status !== 'emitido') throw new AppError('INVALID_STATE', cur.status === 'cancelado' ? 'Este documento já está cancelado.' : 'Apenas documentos emitidos podem ser cancelados.');
      this.d.db.run("UPDATE documents SET status='cancelado', cancelled_at=?, cancel_reason=? WHERE id=? AND service_id=?", [this.d.now().toISOString(), why, id, serviceId]);
      this.d.audit.log(serviceId, 'documento.cancelado', 'document', id, { numero: cur.numberLabel, motivo: why });
      return this.get(serviceId, id);
    });
  }

  setExportPaths(serviceId: string, id: number, paths: { docxPath?: string; pdfPath?: string }): DocumentRecord {
    const cur = this.get(serviceId, id);
    this.d.db.transaction(() => {
      this.d.db.run('UPDATE documents SET docx_path = ?, pdf_path = ? WHERE id = ? AND service_id = ?', [paths.docxPath ?? cur.docxPath, paths.pdfPath ?? cur.pdfPath, id, serviceId]);
      this.d.audit.log(serviceId, 'documento.exportado', 'document', id, { docx: !!paths.docxPath, pdf: !!paths.pdfPath });
    });
    return this.get(serviceId, id);
  }

  get(serviceId: string, id: number): DocumentRecord {
    const r = this.d.db.get('SELECT * FROM documents WHERE id = ? AND service_id = ?', [Number(id), serviceId]);
    if (!r) throw new AppError('NOT_FOUND', 'Documento não encontrado neste serviço.');
    return this.map(r);
  }

  search(serviceId: string, f: SearchFilters = {}): { rows: DocumentRecord[]; total: number } {
    const where = ['service_id = ?']; const p: (string | number)[] = [serviceId];
    const like = (col: string, v?: string) => { const t = clean(v, 200); if (t) { where.push(`${col} LIKE ? ESCAPE '\\'`); p.push(`%${likeEscape(t)}%`); } };
    like('number_label', f.number); like('recipient', f.recipient); like('subject', f.subject);
    if (f.templateId) { where.push('template_id = ?'); p.push(f.templateId); }
    if (f.status) { where.push('status = ?'); p.push(f.status); }
    if (f.from && isValidIsoDate(f.from)) { where.push('issue_date >= ?'); p.push(f.from); }
    if (f.to && isValidIsoDate(f.to)) { where.push('issue_date <= ?'); p.push(f.to); }
    const w = where.join(' AND ');
    const total = this.d.db.get<{ c: number }>(`SELECT COUNT(*) AS c FROM documents WHERE ${w}`, p)!.c;
    const limit = Math.min(Math.max(Number(f.limit) || 50, 1), 200); const offset = Math.max(Number(f.offset) || 0, 0);
    const rows = this.d.db.all(`SELECT * FROM documents WHERE ${w} ORDER BY id DESC LIMIT ? OFFSET ?`, [...p, limit, offset]).map((r) => this.map(r));
    return { rows, total };
  }

  stats(serviceId: string): Stats {
    const r = this.d.db.all<{ status: string; c: number }>('SELECT status, COUNT(*) AS c FROM documents WHERE service_id = ? GROUP BY status', [serviceId]);
    const n = (s: string) => r.find((x) => x.status === s)?.c ?? 0;
    const last = this.d.db.get<{ m: string | null }>("SELECT MAX(issued_at) AS m FROM documents WHERE service_id = ? AND status <> 'rascunho'", [serviceId])?.m ?? null;
    return { total: n('emitido') + n('cancelado') + n('rascunho'), emitido: n('emitido'), cancelado: n('cancelado'), rascunho: n('rascunho'), lastIssued: last };
  }
}
