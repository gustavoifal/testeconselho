import { Deps, Registry } from './registry';
import { NumberingService } from './numbering';
import { SignerService } from './signers';
import { clean, fail, isValidIsoDate, likeEscape } from './util';
import { AppError, DocumentInput, DocumentRecord, FieldError, RecentIdentification, Revision, SearchFilters, SignerSnapshot, Stats, StatsReport, TemplateInfo } from '../../shared/types';

/** Trava de segurança contra abuso; na prática não limita o uso. */
export const MAX_SIGNATURES = 20;
const FIELD_LABEL: Record<string, string> = { recipient: 'Destinatário', recipientRole: 'Cargo do destinatário', subject: 'Assunto', body: 'Corpo do texto', city: 'Cidade' };

export class DocumentService {
  constructor(private d: Deps, private registry: Registry, private numbering: NumberingService, private signers: SignerService) {}

  private map(r: any): DocumentRecord {
    const tplRow = this.d.db.get<{ numbered: number; layout: string }>('SELECT numbered, layout FROM templates WHERE id = ?', [r.template_id]);
    return {
      id: r.id, serviceId: r.service_id, templateId: r.template_id, templateName: r.template_name, category: r.category,
      seqNumber: r.seq_number, period: r.period, numberLabel: r.number_label, status: r.status, recipient: r.recipient,
      recipientRole: r.recipient_role, subject: r.subject, body: r.body, city: r.city, issueDate: r.issue_date, openingText: r.opening_text, closingText: r.closing_text,
      signers: JSON.parse(r.signers_snapshot), institution: JSON.parse(r.institution_snapshot), docxPath: r.docx_path, pdfPath: r.pdf_path,
      numbered: !!tplRow?.numbered, layoutKind: tplRow?.layout ?? 'padrao', extra: JSON.parse(r.extra ?? '{}'),
      identification: JSON.parse(r.identification ?? '[]'), createdAt: r.created_at, issuedAt: r.issued_at, cancelledAt: r.cancelled_at, cancelReason: r.cancel_reason,
    };
  }

  /** Limpa e limita os textos. Nunca preenche nada sozinho. */
  private normalize(i: DocumentInput): DocumentInput {
    if (!i || typeof i !== 'object') throw new AppError('VALIDATION', 'Dados do documento inválidos.');
    const picks = Array.isArray(i.signers) ? i.signers : [];
    return {
      serviceId: String(i.serviceId ?? ''), templateId: String(i.templateId ?? ''),
      recipient: clean(i.recipient, 200), recipientRole: clean(i.recipientRole, 200), subject: clean(i.subject, 300),
      body: clean(i.body, 50_000, true), city: clean(i.city, 80), issueDate: String(i.issueDate ?? ''),
      signers: picks.map((p) => ({ signerId: Number(p?.signerId), useImage: !!p?.useImage })),
      identification: (Array.isArray(i.identification) ? i.identification : []).map((v) => clean(v, 300)),
      skipIdentification: !!i.skipIdentification,
      extra: Object.fromEntries(Object.entries(i.extra && typeof i.extra === 'object' ? i.extra : {}).filter(([k, v]) => /^[A-Za-z0-9]{1,40}$/.test(k) && typeof v === 'string').map(([k, v]) => [k, clean(v, 300)])),
    };
  }

  validate(input: DocumentInput, tpl: TemplateInfo, strict: boolean): FieldError[] {
    const errors: FieldError[] = [];
    if (!isValidIsoDate(input.issueDate)) errors.push({ field: 'issueDate', message: 'Data de emissão inválida.' });
    if (strict) {
      for (const f of tpl.requiredFields) {
        if (!(input as any)[f]) errors.push({ field: f, message: `${FIELD_LABEL[f] ?? f}: campo obrigatório.` });
      }
      if (input.signers.length < 1) errors.push({ field: 'signers', message: 'Selecione quem vai assinar.' });
      if (tpl.hasIdentification && !input.skipIdentification) tpl.identificationFields.forEach((label, i) => { if (!input.identification[i]) errors.push({ field: `identification.${i}`, message: `${label}: informe o dado ou clique em "Não informado".` }); });
    }
    if (input.signers.length > MAX_SIGNATURES) errors.push({ field: 'signers', message: `Limite técnico de ${MAX_SIGNATURES} assinaturas por documento.` });
    for (const f of tpl.extraFields) {
      const v = input.extra?.[f.key] ?? '';
      if (strict && f.required && !v) errors.push({ field: `extra.${f.key}`, message: `${f.label}: campo obrigatório.` });
      else if (v && f.type === 'date' && !isValidIsoDate(v)) errors.push({ field: `extra.${f.key}`, message: `${f.label}: data inválida.` });
      else if (v && f.type === 'time' && !/^([01]\d|2[0-3]):[0-5]\d$/.test(v)) errors.push({ field: `extra.${f.key}`, message: `${f.label}: horário inválido.` });
    }
    const ids = input.signers.map((s) => s.signerId);
    if (ids.some((x) => !Number.isInteger(x))) errors.push({ field: 'signers', message: 'Responsável inválido.' });
    if (new Set(ids).size !== ids.length) errors.push({ field: 'signers', message: 'O mesmo responsável não pode assinar duas vezes.' });
    return errors;
  }

  /** Campos próprios do modelo (ex.: Notificação) + dados congelados no documento (textos fixos e lista de conselheiros). */
  private buildExtra(input: DocumentInput, tpl: TemplateInfo): Record<string, any> {
    if (!tpl.extraFields.length && tpl.layout === 'padrao') return {};
    const out: Record<string, any> = {};
    for (const f of tpl.extraFields) out[f.key] = input.extra?.[f.key] ?? '';
    if (tpl.layout === 'notificacao') {
      const chosen = new Set(input.signers.map((s) => s.signerId));
      out._texts = tpl.layoutTexts;
      out._councilors = this.d.db.all<{ id: number; full_name: string }>(`SELECT s.id, s.full_name FROM signers s JOIN template_signers ts ON ts.signer_id = s.id
        WHERE s.service_id = ? AND ts.template_id = ? AND s.active = 1 AND s.hidden = 0 ORDER BY s.id`, [input.serviceId, tpl.id]).map((x) => ({ name: x.full_name, checked: chosen.has(x.id) }));
    }
    return out;
  }

  private buildIdentification(input: DocumentInput, tpl: TemplateInfo): { label: string; value: string }[] {
    return tpl.hasIdentification && !input.skipIdentification ? tpl.identificationFields.map((label, i) => ({ label, value: input.identification[i] ?? '' })) : [];
  }

  private resolveSigners(input: DocumentInput, tpl: TemplateInfo, strict: boolean, keep: SignerSnapshot[] = []): SignerSnapshot[] {
    const allowed = new Map(this.signers.listSelectable(input.serviceId, tpl.id).map((s) => [s.id, s]));
    const out: SignerSnapshot[] = [];
    for (const p of input.signers) {
      const s = allowed.get(p.signerId);
      if (!s) {
        const old = keep.find((k) => k.signerId === p.signerId); // numa correção, quem já assinou o original pode continuar
        if (old) { out.push({ ...old, imageHash: p.useImage ? old.imageHash : null }); continue; }
        if (strict) {
          const raw = this.d.db.get<{ full_name: string }>('SELECT full_name FROM signers WHERE id = ? AND service_id = ?', [p.signerId, input.serviceId]);
          fail([{ field: 'signers', message: raw ? `"${raw.full_name}" não está disponível para assinar este modelo.` : 'Responsável não encontrado neste serviço.' }]);
        }
        continue;
      }
      const row = this.d.db.get<{ signature_hash: string | null }>('SELECT signature_hash FROM signers WHERE id = ?', [s.id]);
      out.push({ signerId: s.id, name: s.fullName, role: s.roleTitle, imageHash: p.useImage && row?.signature_hash ? row.signature_hash : null });
    }
    return out;
  }

  private context(raw: DocumentInput, strict: boolean) {
    const input = this.normalize(raw);
    this.registry.requireService(input.serviceId);
    const tpl = this.registry.getTemplate(input.serviceId, input.templateId);
    const errors = this.validate(input, tpl, strict);
    if (errors.length) fail(errors);
    return { input, tpl };
  }

  /** Registro provisório para a prévia: não grava nada e não consome número. */
  preview(raw: DocumentInput): DocumentRecord {
    const { input, tpl } = this.context(raw, false);
    const next = this.numbering.peekNext(input.serviceId, tpl.category, input.issueDate, tpl.numbered);
    return {
      id: 0, serviceId: input.serviceId, templateId: tpl.id, templateName: tpl.name, category: tpl.category, seqNumber: null, period: null,
      numberLabel: next.label, status: 'rascunho', recipient: input.recipient, recipientRole: input.recipientRole, subject: input.subject,
      body: input.body, city: input.city, issueDate: input.issueDate, openingText: tpl.openingText, closingText: tpl.closingText, numbered: tpl.numbered, layoutKind: tpl.layout, extra: this.buildExtra({ ...input, signers: input.signers }, tpl), identification: this.buildIdentification(input, tpl),
      signers: this.resolveSigners(input, tpl, false), institution: this.registry.snapshot(input.serviceId),
      docxPath: null, pdfPath: null, createdAt: this.d.now().toISOString(), issuedAt: null, cancelledAt: null, cancelReason: null,
    };
  }

  saveDraft(raw: DocumentInput, draftId?: number): DocumentRecord {
    const { input, tpl } = this.context(raw, false);
    return this.d.db.transaction(() => {
      const signers = JSON.stringify(this.resolveSigners(input, tpl, false));
      const inst = JSON.stringify(this.registry.snapshot(input.serviceId));
      const ident = JSON.stringify(this.buildIdentification(input, tpl));
      const extra = JSON.stringify(this.buildExtra(input, tpl));
      let id = draftId;
      if (id) {
        this.requireDraft(input.serviceId, id);
        this.d.db.run(`UPDATE documents SET template_id=?, template_name=?, category=?, recipient=?, recipient_role=?, subject=?, body=?, city=?, issue_date=?,
          closing_text=?, opening_text=?, identification=?, extra=?, signers_snapshot=?, institution_snapshot=? WHERE id=? AND status='rascunho'`,
          [tpl.id, tpl.name, tpl.category, input.recipient, input.recipientRole, input.subject, input.body, input.city, input.issueDate, tpl.closingText, tpl.openingText, ident, extra, signers, inst, id]);
      } else {
        id = this.d.db.run(`INSERT INTO documents(service_id, template_id, template_name, category, status, recipient, recipient_role, subject, body, city, issue_date,
          closing_text, opening_text, identification, extra, signers_snapshot, institution_snapshot, created_at) VALUES (?,?,?,?, 'rascunho', ?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          [input.serviceId, tpl.id, tpl.name, tpl.category, input.recipient, input.recipientRole, input.subject, input.body, input.city, input.issueDate, tpl.closingText, tpl.openingText, ident, extra, signers, inst, this.d.now().toISOString()]).lastId;
        this.d.audit.log(input.serviceId, 'documento.rascunho_criado', 'document', id);
      }
      return this.get(input.serviceId, id);
    });
  }

  private requireDraft(serviceId: string, id: number) {
    const r = this.d.db.get('SELECT status FROM documents WHERE id = ? AND service_id = ?', [Number(id), serviceId]);
    if (!r) throw new AppError('NOT_FOUND', 'Documento não encontrado neste serviço.');
    if (r.status !== 'rascunho') throw new AppError('NOT_DRAFT', 'Este documento já foi emitido e não pode mais ser editado.');
  }

  deleteDraft(serviceId: string, id: number): void {
    this.d.db.transaction(() => {
      this.requireDraft(serviceId, id);
      this.d.db.run("DELETE FROM documents WHERE id = ? AND status = 'rascunho'", [id]);
      this.d.audit.log(serviceId, 'documento.rascunho_excluido', 'document', id);
    });
  }

  /**
   * EMISSÃO: valida, reserva o número e grava o documento (com cópia dos dados de assinatura e instituição)
   * na mesma transação. Se algo falhar, nada é gravado e nenhum número é consumido.
   */
  issue(raw: DocumentInput, draftId?: number): DocumentRecord {
    const { input, tpl } = this.context(raw, true);
    return this.d.db.transaction(() => {
      if (draftId) this.requireDraft(input.serviceId, draftId);
      const signers = JSON.stringify(this.resolveSigners(input, tpl, true));
      const inst = JSON.stringify(this.registry.snapshot(input.serviceId));
      const ident = JSON.stringify(this.buildIdentification(input, tpl));
      const extra = JSON.stringify(this.buildExtra(input, tpl));
      const n = this.numbering.reserveNext(input.serviceId, tpl.category, input.issueDate, tpl.numbered);
      const ts = this.d.now().toISOString();
      let id: number;
      if (draftId) {
        const r = this.d.db.run(`UPDATE documents SET template_id=?, template_name=?, category=?, seq_number=?, period=?, number_label=?, status='emitido',
          recipient=?, recipient_role=?, subject=?, body=?, city=?, issue_date=?, closing_text=?, opening_text=?, identification=?, extra=?, signers_snapshot=?, institution_snapshot=?, issued_at=?
          WHERE id=? AND status='rascunho'`,
          [tpl.id, tpl.name, tpl.category, n.seq, n.period, n.label, input.recipient, input.recipientRole, input.subject, input.body, input.city, input.issueDate, tpl.closingText, tpl.openingText, ident, extra, signers, inst, ts, draftId]);
        if (r.changes !== 1) throw new AppError('NOT_DRAFT', 'Não foi possível emitir o rascunho.');
        id = draftId;
      } else {
        id = this.d.db.run(`INSERT INTO documents(service_id, template_id, template_name, category, seq_number, period, number_label, status, recipient, recipient_role,
          subject, body, city, issue_date, closing_text, opening_text, identification, extra, signers_snapshot, institution_snapshot, created_at, issued_at) VALUES (?,?,?,?,?,?,?, 'emitido', ?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          [input.serviceId, tpl.id, tpl.name, tpl.category, n.seq, n.period, n.label, input.recipient, input.recipientRole, input.subject, input.body, input.city, input.issueDate, tpl.closingText, tpl.openingText, ident, extra, signers, inst, ts, ts]).lastId;
      }
      this.d.audit.log(input.serviceId, 'documento.emitido', 'document', id, { numero: n.label, modelo: tpl.name });
      return this.get(input.serviceId, id);
    });
  }

  /**
   * CORREÇÃO de documento já emitido (somente administrador, com motivo). O número, o tipo e a data de emissão (ano) não mudam;
   * o conteúdo anterior fica guardado no histórico de correções e a ação é auditada.
   */
  correct(raw: DocumentInput, id: number, reason: string): DocumentRecord {
    this.d.auth.requireAdmin();
    const why = clean(reason, 500);
    if (why.length < 5) fail([{ field: 'reason', message: 'Informe o motivo da correção (mínimo de 5 caracteres).' }]);
    const { input, tpl } = this.context(raw, true);
    return this.d.db.transaction(() => {
      const cur = this.get(input.serviceId, id);
      if (cur.status !== 'emitido') throw new AppError('INVALID_STATE', cur.status === 'cancelado' ? 'Documentos cancelados não podem ser corrigidos.' : 'Este documento ainda é um rascunho: edite-o normalmente.');
      if (cur.templateId !== tpl.id) throw new AppError('VALIDATION', 'Não é possível mudar o tipo de um documento já emitido.');
      if (input.issueDate.slice(0, 4) !== cur.issueDate.slice(0, 4)) fail([{ field: 'issueDate', message: 'A data não pode mudar de ano, pois o número já foi atribuído.' }]);
      const snaps = this.resolveSigners(input, tpl, true, cur.signers);
      const extra = this.buildExtra(input, tpl);
      if (tpl.layout === 'notificacao') { // mantém os textos e a lista de conselheiros congelados na emissão; só muda quem está marcado
        const names = new Set(snaps.map((s) => s.name));
        const list: { name: string; checked: boolean }[] = (cur.extra._councilors ?? []).map((c: { name: string }) => ({ name: c.name, checked: names.has(c.name) }));
        for (const n of names) if (!list.some((c) => c.name === n)) list.push({ name: n, checked: true });
        extra._councilors = list; extra._texts = cur.extra._texts ?? extra._texts;
      }
      const prev = { recipient: cur.recipient, recipientRole: cur.recipientRole, subject: cur.subject, body: cur.body, city: cur.city, issueDate: cur.issueDate, identification: cur.identification, extra: cur.extra, signers: cur.signers };
      this.d.db.run('INSERT INTO document_revisions(document_id, revised_at, actor, reason, previous) VALUES (?,?,?,?,?)', [id, this.d.now().toISOString(), 'administrador', why, JSON.stringify(prev)]);
      this.d.db.run('INSERT INTO edit_grants(document_id) VALUES (?)', [id]);
      this.d.db.run(`UPDATE documents SET recipient=?, recipient_role=?, subject=?, body=?, city=?, issue_date=?, identification=?, extra=?, signers_snapshot=?, docx_path=NULL, pdf_path=NULL
        WHERE id=? AND status='emitido'`, [input.recipient, input.recipientRole, input.subject, input.body, input.city, input.issueDate, JSON.stringify(this.buildIdentification(input, tpl)), JSON.stringify(extra), JSON.stringify(snaps), id]);
      this.d.db.run('DELETE FROM edit_grants WHERE document_id = ?', [id]);
      this.d.audit.log(input.serviceId, 'documento.corrigido', 'document', id, { numero: cur.numberLabel, motivo: why });
      return this.get(input.serviceId, id);
    });
  }

  revisions(serviceId: string, id: number): Revision[] {
    this.get(serviceId, id);
    return this.d.db.all('SELECT id, revised_at, actor, reason FROM document_revisions WHERE document_id = ? ORDER BY id DESC', [id]).map((r) => ({ id: r.id, revisedAt: r.revised_at, actor: r.actor, reason: r.reason }));
  }

  /** Cancela sem apagar e sem reaproveitar o número. */
  cancel(serviceId: string, id: number, reason: string): DocumentRecord {
    const why = clean(reason, 500);
    if (why.length < 5) fail([{ field: 'reason', message: 'Informe o motivo do cancelamento (mínimo de 5 caracteres).' }]);
    return this.d.db.transaction(() => {
      const cur = this.get(serviceId, id);
      if (cur.status !== 'emitido') throw new AppError('INVALID_STATE', cur.status === 'cancelado' ? 'Este documento já está cancelado.' : 'Apenas documentos emitidos podem ser cancelados.');
      this.d.db.run("UPDATE documents SET status='cancelado', cancelled_at=?, cancel_reason=? WHERE id=? AND service_id=?", [this.d.now().toISOString(), why, id, serviceId]);
      this.d.audit.log(serviceId, 'documento.cancelado', 'document', id, { numero: cur.numberLabel, motivo: why });
      return this.get(serviceId, id);
    });
  }

  setExportPaths(serviceId: string, id: number, paths: { docxPath?: string; pdfPath?: string }): DocumentRecord {
    const cur = this.get(serviceId, id);
    this.d.db.transaction(() => {
      this.d.db.run('UPDATE documents SET docx_path = ?, pdf_path = ? WHERE id = ? AND service_id = ?', [paths.docxPath ?? cur.docxPath, paths.pdfPath ?? cur.pdfPath, id, serviceId]);
      this.d.audit.log(serviceId, 'documento.exportado', 'document', id, { docx: !!paths.docxPath, pdf: !!paths.pdfPath });
    });
    return this.get(serviceId, id);
  }

  get(serviceId: string, id: number): DocumentRecord {
    const r = this.d.db.get('SELECT * FROM documents WHERE id = ? AND service_id = ?', [Number(id), serviceId]);
    if (!r) throw new AppError('NOT_FOUND', 'Documento não encontrado neste serviço.');
    return this.map(r);
  }

  search(serviceId: string, f: SearchFilters = {}): { rows: DocumentRecord[]; total: number } {
    const where = ['service_id = ?']; const p: (string | number)[] = [serviceId];
    const like = (col: string, v?: string) => { const t = clean(v, 200); if (t) { where.push(`${col} LIKE ? ESCAPE '\\'`); p.push(`%${likeEscape(t)}%`); } };
    like('number_label', f.number); like('recipient', f.recipient); like('subject', f.subject);
    if (f.templateId) { where.push('template_id = ?'); p.push(f.templateId); }
    if (f.status) { where.push('status = ?'); p.push(f.status); }
    if (f.from && isValidIsoDate(f.from)) { where.push('issue_date >= ?'); p.push(f.from); }
    if (f.to && isValidIsoDate(f.to)) { where.push('issue_date <= ?'); p.push(f.to); }
    const w = where.join(' AND ');
    const total = this.d.db.get<{ c: number }>(`SELECT COUNT(*) AS c FROM documents WHERE ${w}`, p)!.c;
    const limit = Math.min(Math.max(Number(f.limit) || 50, 1), 200); const offset = Math.max(Number(f.offset) || 0, 0);
    const rows = this.d.db.all(`SELECT * FROM documents WHERE ${w} ORDER BY id DESC LIMIT ? OFFSET ?`, [...p, limit, offset]).map((r) => this.map(r));
    return { rows, total };
  }

  /** Conjuntos de identificação usados antes (mais recentes primeiro, sem repetir), para reaproveitar em outro documento. */
  recentIdentifications(serviceId: string, limit = 15): RecentIdentification[] {
    const rows = this.d.db.all<{ identification: string; issue_date: string }>("SELECT identification, issue_date FROM documents WHERE service_id = ? AND identification <> '[]' AND status <> 'rascunho' ORDER BY id DESC LIMIT 300", [serviceId]);
    const seen = new Map<string, RecentIdentification>();
    for (const r of rows) {
      const fields = JSON.parse(r.identification) as { label: string; value: string }[];
      const real = fields.filter((f) => f.value && f.value.toLowerCase() !== 'não informado');
      if (!real.length) continue;
      const key = JSON.stringify(fields.map((f) => [f.label, f.value.toLowerCase()]));
      const cur = seen.get(key);
      if (cur) cur.count += 1; else seen.set(key, { fields, lastUsed: r.issue_date, count: 1 });
    }
    return [...seen.values()].slice(0, Math.min(Math.max(limit, 1), 50));
  }

  /** Estatísticas por período (data do documento). Rascunhos não entram; cancelados são contados à parte. */
  report(serviceId: string, from: string, to: string): StatsReport {
    if (!isValidIsoDate(from) || !isValidIsoDate(to) || from > to) throw new AppError('VALIDATION', 'Período inválido: confira as datas inicial e final.');
    const start = Number(from.slice(0, 4)) * 12 + Number(from.slice(5, 7)) - 1; const end = Number(to.slice(0, 4)) * 12 + Number(to.slice(5, 7)) - 1;
    if (end - start > 119) throw new AppError('VALIDATION', 'Escolha um período de no máximo 10 anos.');
    const rows = this.d.db.all<{ template_name: string; status: string; issue_date: string; recipient: string; signers_snapshot: string }>(
      "SELECT template_name, status, issue_date, recipient, signers_snapshot FROM documents WHERE service_id = ? AND status <> 'rascunho' AND issue_date BETWEEN ? AND ?", [serviceId, from, to]);
    const tplNames = this.registry.listTemplates(serviceId).map((t) => t.name);
    const byType = new Map<string, { emitido: number; cancelado: number }>(tplNames.map((n) => [n, { emitido: 0, cancelado: 0 }]));
    const months = new Map<string, { counts: Record<string, number>; emitido: number; cancelado: number }>();
    for (let m = start; m <= end; m++) months.set(`${Math.floor(m / 12)}-${String((m % 12) + 1).padStart(2, '0')}`, { counts: {}, emitido: 0, cancelado: 0 });
    const rec = new Map<string, { name: string; count: number }>(); const sig = new Map<string, number>();
    const totals = { emitido: 0, cancelado: 0, total: 0 };
    for (const r of rows) {
      const ok = r.status === 'emitido';
      const t = byType.get(r.template_name) ?? { emitido: 0, cancelado: 0 }; byType.set(r.template_name, t);
      const m = months.get(r.issue_date.slice(0, 7))!;
      if (ok) { t.emitido++; m.emitido++; m.counts[r.template_name] = (m.counts[r.template_name] ?? 0) + 1; totals.emitido++; }
      else { t.cancelado++; m.cancelado++; totals.cancelado++; }
      totals.total++;
      if (!ok) continue;
      const rn = r.recipient.trim();
      if (rn) { const k = rn.toLowerCase(); const e = rec.get(k) ?? { name: rn, count: 0 }; e.count++; rec.set(k, e); }
      for (const s of JSON.parse(r.signers_snapshot) as SignerSnapshot[]) sig.set(s.name, (sig.get(s.name) ?? 0) + 1);
    }
    const top = <T extends { count: number; name: string }>(a: T[]) => a.sort((x, y) => y.count - x.count || x.name.localeCompare(y.name, 'pt-BR')).slice(0, 10);
    return {
      from, to, totals,
      byType: [...byType.entries()].map(([name, v]) => ({ name, ...v })),
      typeNames: [...byType.entries()].filter(([, v]) => v.emitido > 0).map(([n]) => n),
      months: [...months.entries()].map(([month, v]) => ({ month, ...v })),
      byRecipient: top([...rec.values()]), bySigner: top([...sig.entries()].map(([name, count]) => ({ name, count }))),
    };
  }

  stats(serviceId: string): Stats {
    const r = this.d.db.all<{ status: string; c: number }>('SELECT status, COUNT(*) AS c FROM documents WHERE service_id = ? GROUP BY status', [serviceId]);
    const n = (s: string) => r.find((x) => x.status === s)?.c ?? 0;
    const last = this.d.db.get<{ m: string | null }>("SELECT MAX(issued_at) AS m FROM documents WHERE service_id = ? AND status <> 'rascunho'", [serviceId])?.m ?? null;
    return { total: n('emitido') + n('cancelado') + n('rascunho'), emitido: n('emitido'), cancelado: n('cancelado'), rascunho: n('rascunho'), lastIssued: last };
  }
}
