import { Deps, Registry } from './registry';
import { AppError, NumberingRule, SequenceRow } from '../../shared/types';

export function formatLabel(rule: NumberingRule, n: number, year: number): string {
  return rule.labelFormat.replace('{N}', String(n).padStart(rule.padding, '0')).replace('{YYYY}', String(year));
}

export class NumberingService {
  constructor(private d: Deps, private registry: Registry) {}

  private periodFor(rule: NumberingRule, year: number): string { return rule.resetYearly ? String(year) : '0'; }

  /**
   * RESERVA E CONFIRMA o número. Só deve ser chamada dentro da transação de emissão: se qualquer passo
   * seguinte falhar, o incremento é desfeito junto, então nenhum número é consumido em vão.
   */
  reserveNext(serviceId: string, category: string, issueDate: string): { seq: number; period: string; label: string } {
    const rule = this.registry.getRule(serviceId, category);
    const year = Number(issueDate.slice(0, 4));
    const period = this.periodFor(rule, year);
    return this.d.db.transaction(() => {
      this.d.db.run('INSERT OR IGNORE INTO numbering_counters(service_id, category, period, last_number) VALUES (?,?,?,0)', [serviceId, category, period]);
      this.d.db.run('UPDATE numbering_counters SET last_number = last_number + 1 WHERE service_id=? AND category=? AND period=?', [serviceId, category, period]);
      const seq = this.d.db.get<{ last_number: number }>('SELECT last_number FROM numbering_counters WHERE service_id=? AND category=? AND period=?', [serviceId, category, period])!.last_number;
      return { seq, period, label: formatLabel(rule, seq, year) };
    });
  }

  /** Apenas consulta o próximo número previsto (não consome nada). */
  peekNext(serviceId: string, category: string, issueDate: string): { seq: number; label: string } {
    const rule = this.registry.getRule(serviceId, category);
    const year = Number(issueDate.slice(0, 4));
    const r = this.d.db.get<{ last_number: number }>('SELECT last_number FROM numbering_counters WHERE service_id=? AND category=? AND period=?', [serviceId, category, this.periodFor(rule, year)]);
    const seq = (r?.last_number ?? 0) + 1;
    return { seq, label: formatLabel(rule, seq, year) };
  }

  /** Para órgãos que já usaram números antes: só permite AVANÇAR o contador, nunca recuar. */
  setNext(serviceId: string, category: string, year: number, nextNumber: number): void {
    this.d.auth.requireAdmin();
    const rule = this.registry.getRule(serviceId, category);
    if (!Number.isInteger(nextNumber) || nextNumber < 1 || nextNumber > 99_999_999) throw new AppError('VALIDATION', 'Número inicial inválido.');
    const period = this.periodFor(rule, year);
    this.d.db.transaction(() => {
      this.d.db.run('INSERT OR IGNORE INTO numbering_counters(service_id, category, period, last_number) VALUES (?,?,?,0)', [serviceId, category, period]);
      const last = this.d.db.get<{ last_number: number }>('SELECT last_number FROM numbering_counters WHERE service_id=? AND category=? AND period=?', [serviceId, category, period])!.last_number;
      if (nextNumber - 1 < last) throw new AppError('NUMBERING_BACKWARDS', `Não é permitido voltar a numeração: o último número usado foi ${last}.`);
      this.d.db.run('UPDATE numbering_counters SET last_number=? WHERE service_id=? AND category=? AND period=?', [nextNumber - 1, serviceId, category, period]);
      this.d.audit.log(serviceId, 'numeracao.proximo_definido', 'numbering', category, { ano: year, proximo: nextNumber });
    });
  }

  /** Consulta da sequência usada (inclui cancelados). */
  sequence(serviceId: string, category: string, year?: number): SequenceRow[] {
    const rule = this.registry.getRule(serviceId, category);
    const params: (string | number)[] = [serviceId, category];
    let where = 'service_id = ? AND category = ? AND seq_number IS NOT NULL';
    if (year !== undefined) { where += ' AND period = ?'; params.push(this.periodFor(rule, year)); }
    return this.d.db.all(`SELECT id, seq_number, number_label, status, issue_date FROM documents WHERE ${where} ORDER BY period, seq_number`, params)
      .map((r) => ({ seqNumber: r.seq_number, numberLabel: r.number_label, status: r.status, documentId: r.id, issueDate: r.issue_date }));
  }
}
