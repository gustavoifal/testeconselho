/** Listas iniciais (genéricas) para o campo "Destinatário" e "Cargo". O administrador ajusta em Configurações. */
export const DEFAULT_RECIPIENTS: string[] = [
  'Prefeitura Municipal',
  'Gabinete do Prefeito',
  'Secretaria Municipal de Assistência Social',
  'Secretaria Municipal de Educação',
  'Secretaria Municipal de Saúde',
  'Secretaria Municipal de Administração',
  'Secretaria Municipal de Finanças',
  'Secretaria Municipal de Planejamento',
  'Procuradoria Municipal',
  'CRAS – Centro de Referência de Assistência Social',
  'CREAS – Centro de Referência Especializado de Assistência Social',
  'Centro POP',
  'Setor do Cadastro Único / Programa Bolsa Família',
  'Serviço de Acolhimento Institucional (Casa de Acolhimento)',
  'Conselho Municipal dos Direitos da Criança e do Adolescente (CMDCA)',
  'Conselho Municipal de Assistência Social',
  'Coordenação da Atenção Básica',
  'Unidade Básica de Saúde (UBS)',
  'CAPS – Centro de Atenção Psicossocial',
  'CAPS AD – Álcool e Drogas',
  'CAPS i – Infantojuvenil',
  'UPA – Unidade de Pronto Atendimento',
  'Hospital',
  'Escola Municipal',
  'Escola Estadual',
  'Creche Municipal',
  'Ministério Público do Estado de Alagoas – Promotoria de Justiça',
  'Poder Judiciário – Vara da Infância e da Juventude',
  'Poder Judiciário – Vara Criminal',
  'Defensoria Pública',
  'Delegacia de Polícia Civil',
  'Polícia Militar',
  'Cartório de Registro Civil',
  'Conselho Tutelar',
];

export const DEFAULT_ROLES: string[] = [
  'Prefeito(a)',
  'Vice-Prefeito(a)',
  'Secretário(a) Municipal',
  'Secretário(a) Executivo(a)',
  'Coordenador(a)',
  'Coordenador(a) do CRAS',
  'Coordenador(a) do CREAS',
  'Diretor(a)',
  'Diretor(a) da Escola',
  'Gestor(a)',
  'Promotor(a) de Justiça',
  'Juiz(a) de Direito',
  'Defensor(a) Público(a)',
  'Delegado(a) de Polícia',
  'Comandante',
  'Assistente Social',
  'Psicólogo(a)',
  'Enfermeiro(a)',
  'Médico(a)',
  'Conselheiro(a) Tutelar',
  'Presidente',
  'Responsável',
];

/** Campos de identificação padrão (bloco logo após o assunto). Editáveis em Configurações. */
export const DEFAULT_IDENTIFICATION = ['Nome da vítima', 'Responsável', 'Endereço'];

import type { ExtraField } from '../../shared/types';

export interface TemplateDef { kind: string; name: string; numbered: boolean; hasRecipient: boolean; bodyLabel: string; closing: string; required: string[]; layout?: string; extraFields?: ExtraField[]; texts?: Record<string, string>; hasIdentification?: boolean }

/** Textos fixos da Notificação. Marcações: **negrito**  __sublinhado__  !!vermelho (negrito+sublinhado)!!  ^^tamanho 12^^  \n = quebra de linha  \t = tabulação. */
export const NOTIFICACAO_TEXTS: Record<string, string> = {
  greeting: 'Prezado Sr.(a),',
  intro: 'O Conselho Tutelar dos Direitos da Criança e do Adolescente de Palmeira dos Índios/AL, no uso de suas atribuições que lhe confere a Lei Federal 8.069/90 e no seu Art. 136, pela presente notificação solicita o seu comparecimento na Sede deste Órgão, situado na \n^^Rua Intendente Belarmino Teixeira Cavalcante^^, n° 100 – Paraíso (**Referência:** Próximo ao Emater e Adeal).',
  closing: '**Aguardamos o seu comparecimento.**',
  warning: '\t!!ATENÇÃO:!! O descumprimento de determinação de autoridade ou do Conselho Tutelar está sujeito à pena de multa equivalente a três salários de referência, sendo aplicada em dobro em caso de reincidência, conforme disposto no Art. 249 da Lei Federal nº 8.069/90.\t\n\tAlém disso, impedir ou dificultar a ação de autoridade, do Conselho Judicial, do Ministério Público ou de membro do Conselho Tutelar no exercício de suas funções implica em pena de detenção de seis meses a dois anos, conforme estabelecido no Art. 236 da Lei Federal nº 8.069/90.',
  important: '\t!!IMPORTANTE:!! É necessário que o responsável traga documento de identificação pessoal __(RG, CPF, COMPROVANTE DE RESIDÊNCIA)__, bem como documento de identificação da criança ou adolescente em questão, para fins de verificação e regularização da situação.',
};
export const NOTIFICACAO_FIELDS: ExtraField[] = [
  { key: 'responsavelTipo', label: 'Parentesco do responsável', type: 'combo', options: ['MÃE', 'PAI', 'AVÓ', 'AVÔ', 'TIA', 'TIO', 'IRMÃ', 'IRMÃO', 'RESPONSÁVEL LEGAL', 'GUARDIÃO(Ã)'], required: true },
  { key: 'responsavelNome', label: 'Nome do responsável', type: 'text', required: true },
  { key: 'menorTipo', label: 'Relação do(a) menor com o responsável', type: 'combo', options: ['FILHA', 'FILHO', 'NETA', 'NETO', 'SOBRINHA', 'SOBRINHO', 'IRMÃ', 'IRMÃO', 'TUTELADA', 'TUTELADO'], required: true },
  { key: 'menorNome', label: 'Nome do(a) menor', type: 'text', required: true },
  { key: 'endereco', label: 'Endereço', type: 'text', required: true },
  { key: 'dataComparecimento', label: 'Data de comparecimento', type: 'date', required: true },
  { key: 'horario', label: 'Horário', type: 'time', required: true },
];
/** Modelos que todo serviço novo recebe. Somente o Ofício é numerado; os demais exibem apenas o título. */
export const TEMPLATE_DEFS: TemplateDef[] = [
  { kind: 'oficio', name: 'Ofício', numbered: true, hasRecipient: true, bodyLabel: 'Corpo do texto', closing: 'Atenciosamente,', required: ['recipient', 'recipientRole', 'subject', 'body'] },
  { kind: 'relatorio-denuncia', name: 'Relatório de Denúncia', numbered: false, hasRecipient: false, bodyLabel: 'Relato da denúncia', closing: '', required: ['subject', 'body'] },
  { kind: 'relatorio-social', name: 'Relatório Social', numbered: false, hasRecipient: false, bodyLabel: 'Descrição da situação e parecer', closing: '', required: ['subject', 'body'] },
  { kind: 'relatorio-atendimento', name: 'Relatório de Atendimento', numbered: false, hasRecipient: false, bodyLabel: 'Descrição do atendimento', closing: '', required: ['subject', 'body'] },
  { kind: 'notificacao', name: 'Notificação', numbered: false, hasRecipient: false, bodyLabel: 'Corpo do texto', closing: '', required: [], layout: 'notificacao', extraFields: NOTIFICACAO_FIELDS, texts: NOTIFICACAO_TEXTS, hasIdentification: false },
  { kind: 'requisicao', name: 'Requisição de Serviço', numbered: false, hasRecipient: true, bodyLabel: 'Corpo do texto', closing: 'Atenciosamente,', required: ['recipient', 'recipientRole', 'subject', 'body'] },
  { kind: 'declaracao', name: 'Declaração', numbered: false, hasRecipient: false, bodyLabel: 'Texto da declaração', closing: '', required: ['subject', 'body'] },
];
