import * as crypto from 'node:crypto';
import { Db } from '../db/database';
import { AppError } from '../../shared/types';

const IDLE_MS = 15 * 60 * 1000;

/** Modo administrador protegido por senha (scrypt + sal). A senha nunca é guardada em texto puro. */
export class Auth {
  private unlockedUntil = 0;
  private fails = 0;
  private lockedUntil = 0;
  constructor(private db: Db, private now: () => Date = () => new Date()) {}

  hasPassword(): boolean {
    return !!this.db.get('SELECT value FROM app_prefs WHERE key = ?', ['admin_hash']);
  }

  private hash(pw: string, salt: Buffer): Buffer { return crypto.scryptSync(pw, salt, 64); }

  private verify(pw: string): boolean {
    const row = this.db.get<{ value: string }>('SELECT value FROM app_prefs WHERE key = ?', ['admin_hash']);
    if (!row) return false;
    const [, saltB64, hashB64] = row.value.split('$');
    const expected = Buffer.from(hashB64, 'base64');
    const actual = this.hash(pw, Buffer.from(saltB64, 'base64'));
    return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
  }

  setPassword(newPassword: string, currentPassword?: string): void {
    if (typeof newPassword !== 'string' || newPassword.length < 8 || newPassword.length > 128) {
      throw new AppError('VALIDATION', 'A senha de administrador deve ter de 8 a 128 caracteres.');
    }
    if (this.hasPassword() && !this.verify(currentPassword ?? '')) {
      throw new AppError('AUTH_FAILED', 'Senha atual incorreta.');
    }
    const salt = crypto.randomBytes(16);
    const value = `scrypt1$${salt.toString('base64')}$${this.hash(newPassword, salt).toString('base64')}`;
    this.db.run('INSERT INTO app_prefs(key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value', ['admin_hash', value]);
    this.unlockedUntil = this.now().getTime() + IDLE_MS;
  }

  unlock(password: string): void {
    const t = this.now().getTime();
    if (t < this.lockedUntil) throw new AppError('AUTH_THROTTLED', 'Muitas tentativas incorretas. Aguarde um minuto e tente novamente.');
    if (!this.verify(String(password ?? ''))) {
      this.fails += 1;
      if (this.fails >= 5) { this.lockedUntil = t + 60_000; this.fails = 0; }
      throw new AppError('AUTH_FAILED', 'Senha incorreta.');
    }
    this.fails = 0;
    this.unlockedUntil = t + IDLE_MS;
  }

  lock(): void { this.unlockedUntil = 0; }
  isAdmin(): boolean { return this.now().getTime() < this.unlockedUntil; }

  requireAdmin(): void {
    if (!this.isAdmin()) throw new AppError('ADMIN_REQUIRED', 'Esta ação exige o modo administrador. Informe a senha de administrador para continuar.');
    this.unlockedUntil = this.now().getTime() + IDLE_MS;
  }
}
