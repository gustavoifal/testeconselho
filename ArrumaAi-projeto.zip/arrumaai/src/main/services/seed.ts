import { Registry } from './registry';
import { Db } from '../db/database';

/** Cria o serviço de demonstração (somente dados fictícios) quando o banco está vazio. */
export function seedDemo(db: Db, registry: Registry, createSigner: (serviceId: string, name: string, role: string) => void): void {
  if (db.get('SELECT id FROM services LIMIT 1')) return;
  registry.createServiceInternal({ id: 'demo', name: 'Serviço de Demonstração', orgName: 'Órgão de Demonstração (EXEMPLO FICTÍCIO)', city: 'Cidade Exemplo/UF', isDemo: true });
  db.run(`UPDATE institution_settings SET address='Rua Exemplo, 123 — Centro (endereço fictício)', phone='(00) 0000-0000', email='contato@exemplo.invalid',
    header_text='Dados fictícios — somente demonstração', footer_text='Documento de exemplo gerado pelo ArrumaAí com dados fictícios.' WHERE service_id='demo'`);
  createSigner('demo', 'Maria Exemplo da Silva', 'Coordenadora (exemplo)');
  createSigner('demo', 'João Exemplo de Souza', 'Secretário (exemplo)');
}
