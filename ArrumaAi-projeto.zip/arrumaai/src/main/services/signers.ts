import { Deps } from './registry';
import { clean, fail } from './util';
import { SIGNATURE_MAX_BYTES } from './assets';
import { AppError, FieldError, Signer, SignerInput } from '../../shared/types';

export class SignerService {
  constructor(private d: Deps) {}

  private map(r: any): Signer {
    const t = this.d.db.all<{ template_id: string }>('SELECT template_id FROM template_signers WHERE signer_id = ?', [r.id]);
    return { id: r.id, serviceId: r.service_id, fullName: r.full_name, roleTitle: r.role_title, active: !!r.active, hidden: !!r.hidden,
      hasSignatureImage: !!r.signature_hash, templateIds: t.map((x) => x.template_id) };
  }

  private row(serviceId: string, id: number) {
    const r = this.d.db.get('SELECT * FROM signers WHERE id = ? AND service_id = ?', [Number(id), serviceId]);
    if (!r) throw new AppError('NOT_FOUND', 'Responsável não encontrado neste serviço.');
    return r;
  }

  get(serviceId: string, id: number): Signer { return this.map(this.row(serviceId, id)); }

  list(serviceId: string, includeHidden = false): Signer[] {
    const sql = `SELECT * FROM signers WHERE service_id = ? ${includeHidden ? '' : 'AND hidden = 0'} ORDER BY full_name COLLATE NOCASE`;
    return this.d.db.all(sql, [serviceId]).map((r) => this.map(r));
  }

  private validate(fullName: string, roleTitle: string) {
    const errors: FieldError[] = [];
    if (fullName.length < 3) errors.push({ field: 'fullName', message: 'Informe o nome completo.' });
    if (!roleTitle) errors.push({ field: 'roleTitle', message: 'Informe o cargo ou função.' });
    if (errors.length) fail(errors);
  }

  private authorize(serviceId: string, signerId: number, templateIds: string[]) {
    this.d.db.run('DELETE FROM template_signers WHERE signer_id = ?', [signerId]);
    for (const tid of new Set(templateIds)) {
      if (!this.d.db.get('SELECT id FROM templates WHERE id = ? AND service_id = ?', [tid, serviceId])) throw new AppError('NOT_FOUND', 'Modelo de documento não encontrado neste serviço.');
      this.d.db.run('INSERT INTO template_signers(template_id, signer_id) VALUES (?,?)', [tid, signerId]);
    }
  }

  create(input: SignerInput): Signer {
    this.d.auth.requireAdmin();
    const serviceId = String(input.serviceId);
    this.d.db.get('SELECT id FROM services WHERE id = ?', [serviceId]) ?? (() => { throw new AppError('NOT_FOUND', 'Serviço não encontrado.'); })();
    const fullName = clean(input.fullName, 120); const roleTitle = clean(input.roleTitle, 120);
    this.validate(fullName, roleTitle);
    return this.d.db.transaction(() => {
      const ts = this.d.now().toISOString();
      const { lastId } = this.d.db.run('INSERT INTO signers(service_id, full_name, role_title, created_at, updated_at) VALUES (?,?,?,?,?)', [serviceId, fullName, roleTitle, ts, ts]);
      const tids = input.templateIds ?? this.d.db.all<{ id: string }>('SELECT id FROM templates WHERE service_id = ?', [serviceId]).map((t) => t.id);
      this.authorize(serviceId, lastId, tids);
      this.d.audit.log(serviceId, 'responsavel.criado', 'signer', lastId, { fullName, roleTitle });
      return this.get(serviceId, lastId);
    });
  }

  update(serviceId: string, id: number, patch: { fullName?: string; roleTitle?: string }): Signer {
    this.d.auth.requireAdmin();
    const cur = this.row(serviceId, id);
    const fullName = patch.fullName !== undefined ? clean(patch.fullName, 120) : cur.full_name;
    const roleTitle = patch.roleTitle !== undefined ? clean(patch.roleTitle, 120) : cur.role_title;
    this.validate(fullName, roleTitle);
    this.d.db.transaction(() => {
      this.d.db.run('UPDATE signers SET full_name=?, role_title=?, updated_at=? WHERE id=?', [fullName, roleTitle, this.d.now().toISOString(), id]);
      this.d.audit.log(serviceId, 'responsavel.editado', 'signer', id, { de: { fullName: cur.full_name, roleTitle: cur.role_title }, para: { fullName, roleTitle } });
    });
    return this.get(serviceId, id);
  }

  setActive(serviceId: string, id: number, active: boolean): Signer {
    this.d.auth.requireAdmin(); this.row(serviceId, id);
    this.d.db.transaction(() => {
      this.d.db.run('UPDATE signers SET active=?, updated_at=? WHERE id=?', [active ? 1 : 0, this.d.now().toISOString(), id]);
      this.d.audit.log(serviceId, active ? 'responsavel.ativado' : 'responsavel.desativado', 'signer', id);
    });
    return this.get(serviceId, id);
  }

  /** "Remove" das listas de seleção sem apagar nada: documentos antigos continuam intactos. */
  setHidden(serviceId: string, id: number, hidden: boolean): Signer {
    this.d.auth.requireAdmin(); this.row(serviceId, id);
    this.d.db.transaction(() => {
      this.d.db.run('UPDATE signers SET hidden=?, updated_at=? WHERE id=?', [hidden ? 1 : 0, this.d.now().toISOString(), id]);
      this.d.audit.log(serviceId, hidden ? 'responsavel.removido_da_selecao' : 'responsavel.restaurado', 'signer', id);
    });
    return this.get(serviceId, id);
  }

  setAuthorizedTemplates(serviceId: string, id: number, templateIds: string[]): Signer {
    this.d.auth.requireAdmin(); this.row(serviceId, id);
    this.d.db.transaction(() => {
      this.authorize(serviceId, id, templateIds);
      this.d.audit.log(serviceId, 'responsavel.modelos_autorizados', 'signer', id, { templateIds });
    });
    return this.get(serviceId, id);
  }

  setSignatureImage(serviceId: string, id: number, loader: ((s: Deps['assets']) => string) | null): Signer {
    this.d.auth.requireAdmin(); this.row(serviceId, id);
    this.d.db.transaction(() => {
      const hash = loader ? loader(this.d.assets) : null;
      this.d.db.run('UPDATE signers SET signature_hash=?, updated_at=? WHERE id=?', [hash, this.d.now().toISOString(), id]);
      this.d.audit.log(serviceId, hash ? 'responsavel.imagem_assinatura_definida' : 'responsavel.imagem_assinatura_removida', 'signer', id);
    });
    return this.get(serviceId, id);
  }

  setSignatureImageBytes(serviceId: string, id: number, bytes: Uint8Array | null): Signer {
    return this.setSignatureImage(serviceId, id, bytes ? (s) => s.store(bytes, SIGNATURE_MAX_BYTES) : null);
  }

  /** Opções do campo "Quem vai assinar?": só ativos, visíveis e autorizados para aquele modelo. */
  listSelectable(serviceId: string, templateId: string): Signer[] {
    return this.d.db.all(`SELECT s.* FROM signers s JOIN template_signers ts ON ts.signer_id = s.id
      WHERE s.service_id = ? AND ts.template_id = ? AND s.active = 1 AND s.hidden = 0 ORDER BY s.full_name COLLATE NOCASE`, [serviceId, templateId]).map((r) => this.map(r));
  }
}
