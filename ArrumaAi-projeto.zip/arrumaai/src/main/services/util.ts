import { AppError, FieldError } from '../../shared/types';

/** Normaliza quebras de linha, remove caracteres de controle e limita o tamanho. */
export function clean(value: unknown, max: number, multiline = false): string {
  if (value === undefined || value === null) return '';
  if (typeof value !== 'string') throw new AppError('VALIDATION', 'Valor de texto inválido.');
  let s = value.normalize('NFC').replace(/\r\n?/g, '\n');
  // eslint-disable-next-line no-control-regex
  s = s.replace(multiline ? /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g : /[\u0000-\u001F\u007F]/g, '');
  s = multiline ? s.replace(/[ \t]+\n/g, '\n').trim() : s.replace(/\s+/g, ' ').trim();
  if (s.length > max) throw new AppError('VALIDATION', `Texto longo demais (máximo de ${max} caracteres).`);
  return s;
}

export function isValidIsoDate(s: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(`${s}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
}

export function likeEscape(s: string): string { return s.replace(/[\\%_]/g, (m) => `\\${m}`); }

export function fail(errors: FieldError[]): never {
  throw new AppError('VALIDATION', 'Corrija os campos destacados.', errors);
}
