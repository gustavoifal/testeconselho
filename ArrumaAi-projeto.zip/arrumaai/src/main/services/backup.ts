import * as crypto from 'node:crypto';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { Db, writeFileAtomic } from '../db/database';
import { migrate } from '../db/migrations';
import { Auth } from './auth';
import { Audit } from './audit';
import { AppError } from '../../shared/types';

const MAGIC = Buffer.from('ARRUMAAI-BKP1');
const stamp = (d: Date) => d.toISOString().replace(/[-:]/g, '').replace(/\..+/, '').replace('T', '-');

/** Formato: MAGIC + modo(0 = sem senha, 1 = criptografado AES-256-GCM) [+ sal16 + iv12 + tag16] + dados. */
export function packBackup(data: Uint8Array, password?: string): Buffer {
  if (!password) return Buffer.concat([MAGIC, Buffer.from([0]), data]);
  const salt = crypto.randomBytes(16); const iv = crypto.randomBytes(12);
  const key = crypto.scryptSync(password, salt, 32);
  const c = crypto.createCipheriv('aes-256-gcm', key, iv);
  const enc = Buffer.concat([c.update(data), c.final()]);
  return Buffer.concat([MAGIC, Buffer.from([1]), salt, iv, c.getAuthTag(), enc]);
}

export function unpackBackup(buf: Buffer, password?: string): Buffer {
  if (buf.length < MAGIC.length + 2 || !buf.subarray(0, MAGIC.length).equals(MAGIC)) throw new AppError('BACKUP_INVALID', 'Este arquivo não é um backup do ArrumaAí.');
  const mode = buf[MAGIC.length]; const rest = buf.subarray(MAGIC.length + 1);
  if (mode === 0) return rest;
  if (!password) throw new AppError('BACKUP_PASSWORD', 'Este backup é protegido por senha. Informe a senha do backup.');
  try {
    const key = crypto.scryptSync(password, rest.subarray(0, 16), 32);
    const d = crypto.createDecipheriv('aes-256-gcm', key, rest.subarray(16, 28));
    d.setAuthTag(rest.subarray(28, 44));
    return Buffer.concat([d.update(rest.subarray(44)), d.final()]);
  } catch { throw new AppError('BACKUP_PASSWORD', 'Senha do backup incorreta ou arquivo corrompido.'); }
}

export class BackupService {
  constructor(private db: Db, private auth: Auth, private audit: Audit, private now: () => Date) {}

  create(destDir: string, password?: string): string {
    this.auth.requireAdmin();
    if (password !== undefined && password !== '' && password.length < 8) throw new AppError('VALIDATION', 'A senha do backup deve ter pelo menos 8 caracteres.');
    let file = path.join(destDir, `ArrumaAi-backup-${stamp(this.now())}.arrumaai-bkp`);
    for (let i = 2; fs.existsSync(file); i++) file = path.join(destDir, `ArrumaAi-backup-${stamp(this.now())}-${i}.arrumaai-bkp`); // nunca sobrescreve backups
    try { writeFileAtomic(file, packBackup(this.db.exportBytes(), password || undefined)); }
    catch { throw new AppError('BACKUP_WRITE', 'Não foi possível gravar o backup na pasta escolhida.'); }
    this.audit.log(null, 'backup.criado', 'backup', path.basename(file), { protegido: !!password });
    return file;
  }

  /** Cópia automática local (no máximo uma por dia, mantém as últimas `keep`). */
  auto(dir: string, keep = 10): string | null {
    const day = this.now().toISOString().slice(0, 10).replace(/-/g, '');
    fs.mkdirSync(dir, { recursive: true });
    const files = fs.readdirSync(dir).filter((f) => f.startsWith('auto-') && f.endsWith('.arrumaai-bkp')).sort();
    if (files.some((f) => f.startsWith(`auto-${day}`))) return null;
    const file = path.join(dir, `auto-${stamp(this.now())}.arrumaai-bkp`);
    writeFileAtomic(file, packBackup(this.db.exportBytes()));
    for (const old of [...files, path.basename(file)].sort().slice(0, -keep)) fs.rmSync(path.join(dir, old), { force: true });
    return file;
  }

  /** Restaura (exige administrador). Antes de trocar, guarda uma cópia do estado atual. */
  restore(file: string, safetyDir: string, password?: string): void {
    this.auth.requireAdmin();
    let buf: Buffer;
    try { buf = fs.readFileSync(file); } catch { throw new AppError('BACKUP_INVALID', 'Não foi possível ler o arquivo de backup.'); }
    const data = unpackBackup(buf, password || undefined);
    fs.mkdirSync(safetyDir, { recursive: true });
    writeFileAtomic(path.join(safetyDir, `antes-da-restauracao-${stamp(this.now())}.arrumaai-bkp`), packBackup(this.db.exportBytes()));
    this.db.replaceWith(data);
    migrate(this.db);
    this.audit.log(null, 'backup.restaurado', 'backup', path.basename(file));
  }
}
