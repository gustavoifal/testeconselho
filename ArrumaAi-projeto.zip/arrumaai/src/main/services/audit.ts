import { Db } from '../db/database';
import { Auth } from './auth';

export interface AuditRow { id: number; ts: string; serviceId: string | null; actor: string; action: string; entity: string; entityId: string | null; details: Record<string, unknown> }

export class Audit {
  constructor(private db: Db, private auth: Auth, private now: () => Date) {}

  log(serviceId: string | null, action: string, entity: string, entityId: string | number | null, details: Record<string, unknown> = {}): void {
    this.db.run('INSERT INTO audit_log(ts, service_id, actor, action, entity, entity_id, details) VALUES (?,?,?,?,?,?,?)', [
      this.now().toISOString(), serviceId, this.auth.isAdmin() ? 'administrador' : 'usuário', action, entity,
      entityId === null ? null : String(entityId), JSON.stringify(details),
    ]);
  }

  list(serviceId: string | null, limit = 100): AuditRow[] {
    const rows = serviceId
      ? this.db.all('SELECT * FROM audit_log WHERE service_id = ? ORDER BY id DESC LIMIT ?', [serviceId, Math.min(limit, 500)])
      : this.db.all('SELECT * FROM audit_log ORDER BY id DESC LIMIT ?', [Math.min(limit, 500)]);
    return rows.map((r) => ({ id: r.id, ts: r.ts, serviceId: r.service_id, actor: r.actor, action: r.action, entity: r.entity, entityId: r.entity_id, details: JSON.parse(r.details) }));
  }
}
