import { Db } from '../db/database';
import { Auth } from './auth';
import { Audit } from './audit';
import { AssetStore, LOGO_MAX_BYTES } from './assets';
import { clean, fail } from './util';
import { AppError, FieldError, Institution, InstitutionPatch, InstitutionSnapshot, NumberingRule, ServiceInfo, TemplateInfo } from '../../shared/types';

export const FONTS = ['Times New Roman', 'Arial', 'Calibri', 'Cambria', 'Georgia', 'Verdana'];
export const TEMPLATE_FIELDS = ['recipient', 'recipientRole', 'subject', 'body', 'city'] as const;

export interface Deps { db: Db; auth: Auth; audit: Audit; assets: AssetStore; now: () => Date }

const mapInstitution = (r: any): Institution => ({
  serviceId: r.service_id, orgName: r.org_name, serviceName: r.service_name, city: r.city, address: r.address, phone: r.phone,
  email: r.email, headerText: r.header_text, footerText: r.footer_text, extraInfo: r.extra_info, logoHash: r.logo_hash,
  fontFamily: r.font_family, fontSizePt: r.font_size_pt,
});
const mapTemplate = (r: any): TemplateInfo => ({
  id: r.id, serviceId: r.service_id, kind: r.kind, category: r.category, name: r.name,
  requiredFields: JSON.parse(r.required_fields), signatureSlots: r.signature_slots, closingText: r.closing_text, enabled: !!r.enabled,
});

export class Registry {
  constructor(private d: Deps) {}

  listServices(): ServiceInfo[] {
    return this.d.db.all('SELECT * FROM services WHERE active = 1 ORDER BY is_demo, name').map((r) => ({
      id: r.id, name: r.name, orgName: r.org_name, isDemo: !!r.is_demo, active: !!r.active,
    }));
  }

  requireService(id: string): ServiceInfo {
    const r = this.d.db.get('SELECT * FROM services WHERE id = ? AND active = 1', [String(id)]);
    if (!r) throw new AppError('NOT_FOUND', 'Serviço não encontrado.');
    return { id: r.id, name: r.name, orgName: r.org_name, isDemo: !!r.is_demo, active: true };
  }

  /** Cria um serviço novo já com instituição, modelo de ofício e regra de numeração padrão. */
  createService(input: { id: string; name: string; orgName: string; city?: string; isDemo?: boolean }): ServiceInfo {
    this.d.auth.requireAdmin();
    return this.createServiceInternal(input);
  }

  createServiceInternal(input: { id: string; name: string; orgName: string; city?: string; isDemo?: boolean }): ServiceInfo {
    const id = String(input.id ?? '');
    const errors: FieldError[] = [];
    if (!/^[a-z0-9-]{2,40}$/.test(id)) errors.push({ field: 'id', message: 'Identificador: 2 a 40 letras minúsculas, números ou hífen.' });
    const name = clean(input.name, 120); const orgName = clean(input.orgName, 160);
    if (!name) errors.push({ field: 'name', message: 'Informe o nome do serviço.' });
    if (!orgName) errors.push({ field: 'orgName', message: 'Informe o nome do órgão.' });
    if (errors.length) fail(errors);
    if (this.d.db.get('SELECT id FROM services WHERE id = ?', [id])) throw new AppError('DUPLICATE', 'Já existe um serviço com esse identificador.');
    const ts = this.d.now().toISOString();
    this.d.db.transaction(() => {
      this.d.db.run('INSERT INTO services(id, name, org_name, is_demo, active, created_at) VALUES (?,?,?,?,1,?)', [id, name, orgName, input.isDemo ? 1 : 0, ts]);
      this.d.db.run('INSERT INTO institution_settings(service_id, org_name, service_name, city) VALUES (?,?,?,?)', [id, orgName, name, clean(input.city, 80)]);
      this.d.db.run('INSERT INTO templates(id, service_id, kind, category, name, required_fields, signature_slots, closing_text) VALUES (?,?,?,?,?,?,?,?)',
        [`${id}:oficio`, id, 'oficio', 'oficio', 'Ofício', JSON.stringify(['recipient', 'recipientRole', 'subject', 'body']), 1, 'Atenciosamente,']);
      this.d.db.run('INSERT INTO numbering_rules(service_id, category) VALUES (?, ?)', [id, 'oficio']);
      this.d.audit.log(id, 'servico.criado', 'service', id, { name, orgName });
    });
    return this.requireService(id);
  }

  getInstitution(serviceId: string): Institution {
    const r = this.d.db.get('SELECT * FROM institution_settings WHERE service_id = ?', [serviceId]);
    if (!r) throw new AppError('NOT_FOUND', 'Configuração institucional não encontrada.');
    return mapInstitution(r);
  }

  snapshot(serviceId: string): InstitutionSnapshot {
    const i = this.getInstitution(serviceId);
    return { orgName: i.orgName, serviceName: i.serviceName, address: i.address, phone: i.phone, email: i.email, headerText: i.headerText,
      footerText: i.footerText, extraInfo: i.extraInfo, logoHash: i.logoHash, fontFamily: i.fontFamily, fontSizePt: i.fontSizePt };
  }

  updateInstitution(serviceId: string, patch: InstitutionPatch): Institution {
    this.d.auth.requireAdmin();
    const cur = this.getInstitution(serviceId);
    const errors: FieldError[] = [];
    const lim: Record<string, [number, boolean]> = {
      orgName: [160, false], serviceName: [120, false], city: [80, false], address: [200, false], phone: [40, false],
      email: [120, false], headerText: [300, true], footerText: [300, true], extraInfo: [300, true],
    };
    const next: Record<string, any> = { ...cur };
    for (const [k, [max, multi]] of Object.entries(lim)) {
      if ((patch as any)[k] === undefined) continue;
      try { next[k] = clean((patch as any)[k], max, multi); } catch (e: any) { errors.push({ field: k, message: e.message }); }
    }
    if (!next.orgName) errors.push({ field: 'orgName', message: 'Informe o nome do órgão.' });
    if (!next.serviceName) errors.push({ field: 'serviceName', message: 'Informe o nome do serviço.' });
    if (next.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(next.email)) errors.push({ field: 'email', message: 'E-mail inválido.' });
    if (patch.fontFamily !== undefined) {
      if (!FONTS.includes(patch.fontFamily)) errors.push({ field: 'fontFamily', message: 'Fonte não disponível.' }); else next.fontFamily = patch.fontFamily;
    }
    if (patch.fontSizePt !== undefined) {
      if (!Number.isInteger(patch.fontSizePt) || patch.fontSizePt < 10 || patch.fontSizePt > 14) errors.push({ field: 'fontSizePt', message: 'Tamanho da fonte: de 10 a 14.' }); else next.fontSizePt = patch.fontSizePt;
    }
    if (errors.length) fail(errors);
    this.d.db.transaction(() => {
      this.d.db.run(`UPDATE institution_settings SET org_name=?, service_name=?, city=?, address=?, phone=?, email=?, header_text=?, footer_text=?, extra_info=?, font_family=?, font_size_pt=? WHERE service_id=?`,
        [next.orgName, next.serviceName, next.city, next.address, next.phone, next.email, next.headerText, next.footerText, next.extraInfo, next.fontFamily, next.fontSizePt, serviceId]);
      this.d.db.run('UPDATE services SET name=?, org_name=? WHERE id=?', [next.serviceName, next.orgName, serviceId]);
      const changed = Object.keys(patch).filter((k) => (cur as any)[k] !== next[k]);
      this.d.audit.log(serviceId, 'instituicao.alterada', 'institution', serviceId, { campos: changed });
    });
    return this.getInstitution(serviceId);
  }

  setLogo(serviceId: string, loader: (store: AssetStore) => string | null): Institution {
    this.d.auth.requireAdmin();
    this.getInstitution(serviceId);
    this.d.db.transaction(() => {
      const hash = loader(this.d.assets);
      this.d.db.run('UPDATE institution_settings SET logo_hash = ? WHERE service_id = ?', [hash, serviceId]);
      this.d.audit.log(serviceId, hash ? 'logo.alterada' : 'logo.removida', 'institution', serviceId);
    });
    return this.getInstitution(serviceId);
  }

  setLogoBytes(serviceId: string, bytes: Uint8Array | null): Institution {
    return this.setLogo(serviceId, (s) => (bytes ? s.store(bytes, LOGO_MAX_BYTES) : null));
  }

  listTemplates(serviceId: string): TemplateInfo[] {
    return this.d.db.all('SELECT * FROM templates WHERE service_id = ? AND enabled = 1 ORDER BY name', [serviceId]).map(mapTemplate);
  }

  getTemplate(serviceId: string, templateId: string): TemplateInfo {
    const r = this.d.db.get('SELECT * FROM templates WHERE id = ? AND service_id = ?', [String(templateId), serviceId]);
    if (!r) throw new AppError('NOT_FOUND', 'Modelo de documento não encontrado neste serviço.');
    return mapTemplate(r);
  }

  updateTemplate(serviceId: string, templateId: string, patch: { signatureSlots?: number; requiredFields?: string[]; closingText?: string }): TemplateInfo {
    this.d.auth.requireAdmin();
    const t = this.getTemplate(serviceId, templateId);
    const errors: FieldError[] = [];
    let slots = t.signatureSlots; let fields = t.requiredFields; let closing = t.closingText;
    if (patch.signatureSlots !== undefined) {
      if (!Number.isInteger(patch.signatureSlots) || patch.signatureSlots < 1 || patch.signatureSlots > 4) errors.push({ field: 'signatureSlots', message: 'Quantidade de assinaturas: de 1 a 4.' }); else slots = patch.signatureSlots;
    }
    if (patch.requiredFields !== undefined) {
      const f = [...new Set(patch.requiredFields)];
      if (f.some((x) => !(TEMPLATE_FIELDS as readonly string[]).includes(x)) || !f.includes('subject') || !f.includes('body')) errors.push({ field: 'requiredFields', message: 'Assunto e corpo do texto são sempre obrigatórios.' }); else fields = f;
    }
    if (patch.closingText !== undefined) { try { closing = clean(patch.closingText, 120); } catch (e: any) { errors.push({ field: 'closingText', message: e.message }); } }
    if (errors.length) fail(errors);
    this.d.db.transaction(() => {
      this.d.db.run('UPDATE templates SET signature_slots=?, required_fields=?, closing_text=? WHERE id=?', [slots, JSON.stringify(fields), closing, templateId]);
      this.d.audit.log(serviceId, 'modelo.alterado', 'template', templateId, { slots, fields, closing });
    });
    return this.getTemplate(serviceId, templateId);
  }

  getRule(serviceId: string, category: string): NumberingRule {
    const r = this.d.db.get('SELECT * FROM numbering_rules WHERE service_id = ? AND category = ?', [serviceId, category]);
    if (!r) throw new AppError('NOT_FOUND', 'Regra de numeração não encontrada.');
    return { serviceId, category, labelFormat: r.label_format, padding: r.padding, resetYearly: !!r.reset_yearly };
  }

  updateRule(serviceId: string, category: string, patch: Partial<Pick<NumberingRule, 'labelFormat' | 'padding' | 'resetYearly'>>): NumberingRule {
    this.d.auth.requireAdmin();
    const cur = this.getRule(serviceId, category);
    const errors: FieldError[] = [];
    const fmt = patch.labelFormat ?? cur.labelFormat;
    if (!/^[\w\s./-]*\{N\}[\w\s{}./-]*$/.test(fmt) || fmt.length > 40 || fmt.replace(/\{N\}|\{YYYY\}/g, '').includes('{')) errors.push({ field: 'labelFormat', message: 'Formato inválido. Use {N} para o número e, opcionalmente, {YYYY} para o ano. Ex.: {N}/{YYYY}.' });
    const padding = patch.padding ?? cur.padding;
    if (!Number.isInteger(padding) || padding < 1 || padding > 8) errors.push({ field: 'padding', message: 'Dígitos: de 1 a 8.' });
    if (errors.length) fail(errors);
    const resetYearly = patch.resetYearly ?? cur.resetYearly;
    this.d.db.transaction(() => {
      this.d.db.run('UPDATE numbering_rules SET label_format=?, padding=?, reset_yearly=? WHERE service_id=? AND category=?', [fmt, padding, resetYearly ? 1 : 0, serviceId, category]);
      this.d.audit.log(serviceId, 'numeracao.regra_alterada', 'numbering_rule', category, { fmt, padding, resetYearly });
    });
    return this.getRule(serviceId, category);
  }
}
