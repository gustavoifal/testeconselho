import { Db } from './database';
import { AppError } from '../../shared/types';
import { DEFAULT_IDENTIFICATION, DEFAULT_RECIPIENTS, DEFAULT_ROLES, TEMPLATE_DEFS } from '../services/defaults';

const q = (t: string) => t.replace(/'/g, "''");
const seedSql = (kind: string, list: string[]) => list.map((l, i) => `INSERT INTO recipient_options(service_id, kind, label, position) SELECT id, '${kind}', '${q(l)}', ${i} FROM services;`).join('\n');

export const MIGRATIONS: { version: number; name: string; sql: string }[] = [
  {
    version: 1,
    name: 'esquema-inicial',
    sql: `
CREATE TABLE services (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, org_name TEXT NOT NULL,
  is_demo INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
);
CREATE TABLE assets (
  hash TEXT PRIMARY KEY, mime TEXT NOT NULL, data BLOB NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE institution_settings (
  service_id TEXT PRIMARY KEY REFERENCES services(id),
  org_name TEXT NOT NULL, service_name TEXT NOT NULL, city TEXT NOT NULL DEFAULT '',
  address TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '',
  header_text TEXT NOT NULL DEFAULT '', footer_text TEXT NOT NULL DEFAULT '', extra_info TEXT NOT NULL DEFAULT '',
  logo_hash TEXT REFERENCES assets(hash), font_family TEXT NOT NULL DEFAULT 'Times New Roman',
  font_size_pt INTEGER NOT NULL DEFAULT 12
);
CREATE TABLE templates (
  id TEXT PRIMARY KEY, service_id TEXT NOT NULL REFERENCES services(id),
  kind TEXT NOT NULL, category TEXT NOT NULL, name TEXT NOT NULL,
  required_fields TEXT NOT NULL, signature_slots INTEGER NOT NULL CHECK (signature_slots BETWEEN 1 AND 4),
  closing_text TEXT NOT NULL DEFAULT 'Atenciosamente,', enabled INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE signers (
  id INTEGER PRIMARY KEY AUTOINCREMENT, service_id TEXT NOT NULL REFERENCES services(id),
  full_name TEXT NOT NULL, role_title TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1, hidden INTEGER NOT NULL DEFAULT 0,
  signature_hash TEXT REFERENCES assets(hash), created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX ix_signers_service ON signers(service_id);
CREATE TABLE template_signers (
  template_id TEXT NOT NULL REFERENCES templates(id), signer_id INTEGER NOT NULL REFERENCES signers(id),
  PRIMARY KEY (template_id, signer_id)
);
CREATE TABLE numbering_rules (
  service_id TEXT NOT NULL REFERENCES services(id), category TEXT NOT NULL,
  label_format TEXT NOT NULL DEFAULT '{N}/{YYYY}', padding INTEGER NOT NULL DEFAULT 3 CHECK (padding BETWEEN 1 AND 8),
  reset_yearly INTEGER NOT NULL DEFAULT 1, PRIMARY KEY (service_id, category)
);
CREATE TABLE numbering_counters (
  service_id TEXT NOT NULL, category TEXT NOT NULL, period TEXT NOT NULL, last_number INTEGER NOT NULL,
  PRIMARY KEY (service_id, category, period)
);
CREATE TRIGGER counters_never_decrease BEFORE UPDATE ON numbering_counters
WHEN NEW.last_number < OLD.last_number
BEGIN SELECT RAISE(ABORT, 'A numeração nunca pode retroceder.'); END;
CREATE TABLE documents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  service_id TEXT NOT NULL REFERENCES services(id), template_id TEXT NOT NULL REFERENCES templates(id),
  template_name TEXT NOT NULL, category TEXT NOT NULL,
  seq_number INTEGER, period TEXT, number_label TEXT,
  status TEXT NOT NULL CHECK (status IN ('rascunho','emitido','cancelado')),
  recipient TEXT NOT NULL DEFAULT '', recipient_role TEXT NOT NULL DEFAULT '',
  subject TEXT NOT NULL DEFAULT '', body TEXT NOT NULL DEFAULT '', city TEXT NOT NULL DEFAULT '',
  issue_date TEXT NOT NULL, closing_text TEXT NOT NULL DEFAULT '',
  signers_snapshot TEXT NOT NULL DEFAULT '[]', institution_snapshot TEXT NOT NULL DEFAULT '{}',
  docx_path TEXT, pdf_path TEXT, created_at TEXT NOT NULL, issued_at TEXT,
  cancelled_at TEXT, cancel_reason TEXT,
  CHECK ((status = 'rascunho' AND seq_number IS NULL) OR (status <> 'rascunho' AND seq_number IS NOT NULL))
);
CREATE UNIQUE INDEX ux_documents_number ON documents(service_id, category, period, seq_number) WHERE seq_number IS NOT NULL;
CREATE INDEX ix_documents_service_status ON documents(service_id, status, issue_date);
CREATE INDEX ix_documents_label ON documents(service_id, number_label);
CREATE TRIGGER documents_no_delete BEFORE DELETE ON documents
WHEN OLD.status <> 'rascunho'
BEGIN SELECT RAISE(ABORT, 'Documentos emitidos ou cancelados não podem ser excluídos.'); END;
CREATE TRIGGER documents_immutable BEFORE UPDATE ON documents
WHEN OLD.status <> 'rascunho' AND (
  NEW.service_id IS NOT OLD.service_id OR NEW.template_id IS NOT OLD.template_id OR NEW.category IS NOT OLD.category OR
  NEW.seq_number IS NOT OLD.seq_number OR NEW.period IS NOT OLD.period OR NEW.number_label IS NOT OLD.number_label OR
  NEW.recipient IS NOT OLD.recipient OR NEW.recipient_role IS NOT OLD.recipient_role OR NEW.subject IS NOT OLD.subject OR
  NEW.body IS NOT OLD.body OR NEW.city IS NOT OLD.city OR NEW.issue_date IS NOT OLD.issue_date OR
  NEW.closing_text IS NOT OLD.closing_text OR NEW.template_name IS NOT OLD.template_name OR
  NEW.signers_snapshot IS NOT OLD.signers_snapshot OR NEW.institution_snapshot IS NOT OLD.institution_snapshot OR
  NEW.issued_at IS NOT OLD.issued_at OR NEW.status = 'rascunho' OR
  (OLD.status = 'cancelado' AND (NEW.status <> 'cancelado' OR NEW.cancel_reason IS NOT OLD.cancel_reason OR NEW.cancelled_at IS NOT OLD.cancelled_at))
)
BEGIN SELECT RAISE(ABORT, 'Documento emitido não pode ser alterado.'); END;
CREATE TABLE audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, service_id TEXT, actor TEXT NOT NULL,
  action TEXT NOT NULL, entity TEXT NOT NULL, entity_id TEXT, details TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX ix_audit_service ON audit_log(service_id, ts);
CREATE TRIGGER audit_no_update BEFORE UPDATE ON audit_log BEGIN SELECT RAISE(ABORT, 'O registro de auditoria não pode ser alterado.'); END;
CREATE TRIGGER audit_no_delete BEFORE DELETE ON audit_log BEGIN SELECT RAISE(ABORT, 'O registro de auditoria não pode ser excluído.'); END;
CREATE TABLE app_prefs (key TEXT PRIMARY KEY, value TEXT NOT NULL);
`,
  },
  {
    version: 2,
    name: 'texto-de-abertura-fixo',
    sql: `
ALTER TABLE templates ADD COLUMN opening_text TEXT NOT NULL DEFAULT '';
ALTER TABLE documents ADD COLUMN opening_text TEXT NOT NULL DEFAULT '';
DROP TRIGGER documents_immutable;
CREATE TRIGGER documents_immutable BEFORE UPDATE ON documents
WHEN OLD.status <> 'rascunho' AND (
  NEW.service_id IS NOT OLD.service_id OR NEW.template_id IS NOT OLD.template_id OR NEW.category IS NOT OLD.category OR
  NEW.seq_number IS NOT OLD.seq_number OR NEW.period IS NOT OLD.period OR NEW.number_label IS NOT OLD.number_label OR
  NEW.recipient IS NOT OLD.recipient OR NEW.recipient_role IS NOT OLD.recipient_role OR NEW.subject IS NOT OLD.subject OR
  NEW.body IS NOT OLD.body OR NEW.city IS NOT OLD.city OR NEW.issue_date IS NOT OLD.issue_date OR
  NEW.closing_text IS NOT OLD.closing_text OR NEW.opening_text IS NOT OLD.opening_text OR NEW.template_name IS NOT OLD.template_name OR
  NEW.signers_snapshot IS NOT OLD.signers_snapshot OR NEW.institution_snapshot IS NOT OLD.institution_snapshot OR
  NEW.issued_at IS NOT OLD.issued_at OR NEW.status = 'rascunho' OR
  (OLD.status = 'cancelado' AND (NEW.status <> 'cancelado' OR NEW.cancel_reason IS NOT OLD.cancel_reason OR NEW.cancelled_at IS NOT OLD.cancelled_at))
)
BEGIN SELECT RAISE(ABORT, 'Documento emitido não pode ser alterado.'); END;
`,
  },
  {
    version: 3,
    name: 'listas-de-destinatarios-e-cargos',
    sql: `
CREATE TABLE recipient_options (
  id INTEGER PRIMARY KEY AUTOINCREMENT, service_id TEXT NOT NULL REFERENCES services(id),
  kind TEXT NOT NULL CHECK (kind IN ('orgao','cargo')), label TEXT NOT NULL, position INTEGER NOT NULL DEFAULT 0,
  UNIQUE (service_id, kind, label)
);
${seedSql('orgao', DEFAULT_RECIPIENTS)}
${seedSql('cargo', DEFAULT_ROLES)}
`,
  },
  {
    version: 4,
    name: 'tipos-de-documento-e-identificacao',
    sql: `
ALTER TABLE templates ADD COLUMN numbered INTEGER NOT NULL DEFAULT 1;
ALTER TABLE templates ADD COLUMN has_recipient INTEGER NOT NULL DEFAULT 1;
ALTER TABLE templates ADD COLUMN has_identification INTEGER NOT NULL DEFAULT 1;
ALTER TABLE templates ADD COLUMN identification_fields TEXT NOT NULL DEFAULT '${q(JSON.stringify(DEFAULT_IDENTIFICATION))}';
ALTER TABLE templates ADD COLUMN body_label TEXT NOT NULL DEFAULT 'Corpo do texto';
ALTER TABLE documents ADD COLUMN identification TEXT NOT NULL DEFAULT '[]';
${TEMPLATE_DEFS.filter((d) => d.kind !== 'oficio').map((d) => `INSERT INTO templates(id, service_id, kind, category, name, required_fields, signature_slots, closing_text, numbered, has_recipient, body_label)
SELECT id || ':${d.kind}', id, '${d.kind}', '${d.kind}', '${q(d.name)}', '${q(JSON.stringify(d.required))}', 1, '${q(d.closing)}', ${d.numbered ? 1 : 0}, ${d.hasRecipient ? 1 : 0}, '${q(d.bodyLabel)}' FROM services;
${d.numbered ? `INSERT INTO numbering_rules(service_id, category) SELECT id, '${d.kind}' FROM services;` : ''}`).join('\n')}
INSERT OR IGNORE INTO template_signers(template_id, signer_id) SELECT t.id, sg.id FROM templates t JOIN signers sg ON sg.service_id = t.service_id;
DROP TRIGGER documents_immutable;
CREATE TRIGGER documents_immutable BEFORE UPDATE ON documents
WHEN OLD.status <> 'rascunho' AND (
  NEW.service_id IS NOT OLD.service_id OR NEW.template_id IS NOT OLD.template_id OR NEW.category IS NOT OLD.category OR
  NEW.seq_number IS NOT OLD.seq_number OR NEW.period IS NOT OLD.period OR NEW.number_label IS NOT OLD.number_label OR
  NEW.recipient IS NOT OLD.recipient OR NEW.recipient_role IS NOT OLD.recipient_role OR NEW.subject IS NOT OLD.subject OR
  NEW.body IS NOT OLD.body OR NEW.city IS NOT OLD.city OR NEW.issue_date IS NOT OLD.issue_date OR
  NEW.closing_text IS NOT OLD.closing_text OR NEW.opening_text IS NOT OLD.opening_text OR NEW.identification IS NOT OLD.identification OR
  NEW.template_name IS NOT OLD.template_name OR
  NEW.signers_snapshot IS NOT OLD.signers_snapshot OR NEW.institution_snapshot IS NOT OLD.institution_snapshot OR
  NEW.issued_at IS NOT OLD.issued_at OR NEW.status = 'rascunho' OR
  (OLD.status = 'cancelado' AND (NEW.status <> 'cancelado' OR NEW.cancel_reason IS NOT OLD.cancel_reason OR NEW.cancelled_at IS NOT OLD.cancelled_at))
)
BEGIN SELECT RAISE(ABORT, 'Documento emitido não pode ser alterado.'); END;
`,
  },
  {
    version: 5,
    name: 'somente-oficio-numerado',
    sql: `
UPDATE templates SET numbered = 0 WHERE kind <> 'oficio';
`,
  },
];

export function currentSchemaVersion(): number { return MIGRATIONS[MIGRATIONS.length - 1].version; }

export function migrate(db: Db): void {
  db.exec('CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, name TEXT NOT NULL, applied_at TEXT NOT NULL)');
  const applied = db.get<{ v: number | null }>('SELECT MAX(version) AS v FROM schema_migrations')?.v ?? 0;
  if (applied > currentSchemaVersion()) {
    throw new AppError('DB_NEWER', 'Os dados foram criados por uma versão mais nova do ArrumaAí. Atualize o aplicativo.');
  }
  for (const m of MIGRATIONS.filter((x) => x.version > applied)) {
    db.transaction(() => {
      db.exec(m.sql);
      db.run('INSERT INTO schema_migrations(version, name, applied_at) VALUES (?,?,?)', [m.version, m.name, new Date().toISOString()]);
    });
  }
  db.persist();
}
