import initSqlJs from 'sql.js';
import type { Database as SqlDatabase, SqlJsStatic } from 'sql.js';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { AppError } from '../../shared/types';

export type Param = string | number | null | Uint8Array;
export interface DbOptions { writeFile?: (file: string, data: Uint8Array) => void }

let sqlPromise: Promise<SqlJsStatic> | null = null;
const getSql = () => (sqlPromise ??= initSqlJs());

export function writeFileAtomic(file: string, data: Uint8Array): void {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = `${file}.tmp`;
  const fd = fs.openSync(tmp, 'w');
  try { fs.writeSync(fd, data); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
  fs.renameSync(tmp, file);
}

export class Db {
  private depth = 0;
  private constructor(private sql: SqlJsStatic, private db: SqlDatabase, readonly file: string | null, private opts: DbOptions) {}

  static async open(file: string | null, opts: DbOptions = {}): Promise<Db> {
    const sql = await getSql();
    const data = file && fs.existsSync(file) ? fs.readFileSync(file) : undefined;
    const d = new Db(sql, new sql.Database(data), file, opts);
    d.db.run('PRAGMA foreign_keys = ON');
    return d;
  }

  exec(sqlText: string): void { this.db.run(sqlText); this.autoPersist(); }

  run(sqlText: string, params: Param[] = []): { changes: number; lastId: number } {
    this.db.run(sqlText, params);
    const changes = this.db.getRowsModified();
    const lastId = Number(this.db.exec('SELECT last_insert_rowid()')[0]?.values[0]?.[0] ?? 0);
    this.autoPersist();
    return { changes, lastId };
  }

  all<T = Record<string, any>>(sqlText: string, params: Param[] = []): T[] {
    const stmt = this.db.prepare(sqlText);
    try {
      stmt.bind(params);
      const rows: T[] = [];
      while (stmt.step()) rows.push(stmt.getAsObject() as T);
      return rows;
    } finally { stmt.free(); }
  }

  get<T = Record<string, any>>(sqlText: string, params: Param[] = []): T | undefined {
    return this.all<T>(sqlText, params)[0];
  }

  /** Tudo-ou-nada. Só grava no disco depois do COMMIT; se a gravação falhar, volta ao último estado salvo. */
  transaction<T>(fn: () => T): T {
    if (this.depth > 0) return fn();
    this.db.run('BEGIN IMMEDIATE');
    this.depth = 1;
    let result: T;
    try {
      result = fn();
      this.db.run('COMMIT');
    } catch (e) {
      try { this.db.run('ROLLBACK'); } catch { /* já encerrada */ }
      this.depth = 0;
      throw e;
    }
    this.depth = 0;
    this.persist();
    return result;
  }

  private autoPersist() { if (this.depth === 0) this.persist(); }

  persist(): void {
    if (!this.file) return;
    const data = this.db.export(); // export() reinicia os PRAGMAs
    this.db.run('PRAGMA foreign_keys = ON');
    try {
      (this.opts.writeFile ?? writeFileAtomic)(this.file, data);
    } catch {
      this.reloadFromDisk();
      throw new AppError('DB_WRITE', 'Não foi possível gravar os dados no disco. A operação foi desfeita; verifique o espaço e as permissões da pasta de dados.');
    }
  }

  private reloadFromDisk() {
    const data = this.file && fs.existsSync(this.file) ? fs.readFileSync(this.file) : undefined;
    try { this.db.close(); } catch { /* ignore */ }
    this.db = new this.sql.Database(data);
    this.db.run('PRAGMA foreign_keys = ON');
  }

  exportBytes(): Uint8Array {
    const data = this.db.export();
    this.db.run('PRAGMA foreign_keys = ON');
    return data;
  }

  /** Valida e troca todo o conteúdo (restauração de backup). */
  replaceWith(bytes: Uint8Array): void {
    let candidate: SqlDatabase;
    try { candidate = new this.sql.Database(bytes); } catch { throw new AppError('BACKUP_INVALID', 'O arquivo de backup não é um banco de dados válido.'); }
    try {
      const check = candidate.exec('PRAGMA integrity_check')[0]?.values[0]?.[0];
      const hasMig = candidate.exec("SELECT name FROM sqlite_master WHERE name='schema_migrations'").length > 0;
      if (check !== 'ok' || !hasMig) throw new AppError('BACKUP_INVALID', 'O arquivo de backup está corrompido ou não pertence ao ArrumaAí.');
    } catch (e) {
      candidate.close();
      if (e instanceof AppError) throw e;
      throw new AppError('BACKUP_INVALID', 'O arquivo de backup não é um banco de dados válido.');
    }
    try { this.db.close(); } catch { /* ignore */ }
    this.db = candidate;
    this.db.run('PRAGMA foreign_keys = ON');
    this.persist();
  }

  close() { try { this.db.close(); } catch { /* ignore */ } }
}
