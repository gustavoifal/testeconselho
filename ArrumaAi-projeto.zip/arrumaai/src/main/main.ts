import { app, BrowserWindow, shell } from 'electron';
import * as path from 'node:path';
import { pathToFileURL } from 'node:url';
import { AppCore } from './context';
import { registerIpc } from './ipc/handlers';

const DEV_URL = process.env.ARRUMAAI_DEV_URL; // só usado no desenvolvimento
const rendererIndex = path.join(__dirname, '..', 'renderer', 'index.html');
const appUrl = pathToFileURL(rendererIndex).href;
let win: BrowserWindow | null = null;

if (!app.requestSingleInstanceLock()) { app.quit(); }

const trusted = (url: string) => url.startsWith(appUrl) || (!!DEV_URL && url.startsWith(DEV_URL));

async function start() {
  // Os dados ficam na pasta do usuário (AppData), separados do programa: atualizar/reinstalar não apaga nada.
  const dataDir = path.join(app.getPath('userData'), 'dados');
  const core = await AppCore.create({ dbFile: path.join(dataDir, 'arrumaai.db') });
  try { core.backup.auto(path.join(dataDir, 'backups-automaticos'), 10); } catch (e) { console.error('Backup automático falhou', e); }
  registerIpc(core, () => win, { backupAuto: path.join(dataDir, 'backups-automaticos'), backupSafety: path.join(dataDir, 'backups-seguranca') }, trusted);

  win = new BrowserWindow({
    width: 1280, height: 820, minWidth: 980, minHeight: 640, title: 'ArrumaAí', backgroundColor: '#f4f6f8', show: false,
    webPreferences: { preload: path.join(__dirname, '..', 'preload', 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, webSecurity: true, spellcheck: true },
  });
  win.setMenuBarVisibility(false);
  win.once('ready-to-show', () => win?.show());
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e, url) => { if (!trusted(url)) e.preventDefault(); });
  if (DEV_URL) await win.loadURL(DEV_URL); else await win.loadFile(rendererIndex);
}

app.whenReady().then(start).catch((e) => { console.error(e); app.quit(); });
app.on('window-all-closed', () => app.quit());
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
void shell;
