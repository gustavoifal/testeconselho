import { DocumentRecord, MONTHS_PT } from '../../shared/types';
import { AssetStore } from '../services/assets';

export interface Img { mime: 'image/png' | 'image/jpeg'; bytes: Uint8Array; w: number; h: number }
export interface TextLine { text: string; bold?: boolean; italic?: boolean; size?: number }
export type Block =
  | { t: 'header'; logo: Img | null; lines: TextLine[] }
  | { t: 'rule' }
  | { t: 'title'; text: string; center?: boolean }
  | { t: 'right'; text: string }
  | { t: 'para'; text: string; label?: string; bold?: boolean; indent?: boolean; justify?: boolean; after?: number }
  | { t: 'spacer'; pt: number }
  | { t: 'closing'; text: string }
  | { t: 'signatures'; items: { name: string; role: string; image: Img | null }[] };

export interface Layout { blocks: Block[]; footerLines: string[]; fontFamily: string; fontPx: number; titlePx: number; columns: number }

export function longDate(iso: string): string {
  const [y, m, d] = iso.split('-').map(Number);
  return `${d} de ${MONTHS_PT[m - 1]} de ${y}`;
}

export function imageSize(b: Uint8Array): { w: number; h: number } {
  const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
  if (b[0] === 0x89 && b[1] === 0x50) return { w: dv.getUint32(16), h: dv.getUint32(20) };
  let i = 2;
  while (i + 9 < b.length) {
    if (b[i] !== 0xff) { i++; continue; }
    const marker = b[i + 1];
    if (marker >= 0xc0 && marker <= 0xcf && marker !== 0xc4 && marker !== 0xc8 && marker !== 0xcc) return { h: dv.getUint16(i + 5), w: dv.getUint16(i + 7) };
    i += 2 + dv.getUint16(i + 2);
  }
  return { w: 200, h: 80 };
}

function fit(b: { mime: Img['mime']; data: Uint8Array }, maxW: number, maxH: number): Img {
  const s = imageSize(b.data);
  const k = Math.min(maxW / (s.w || maxW), maxH / (s.h || maxH), 1);
  return { mime: b.mime, bytes: b.data, w: Math.max(1, Math.round((s.w || maxW) * k)), h: Math.max(1, Math.round((s.h || maxH) * k)) };
}

/**
 * Modelo "Ofício" (v1): define a ESTRUTURA do documento. Interface, DOCX e PDF apenas desenham estes blocos.
 * Usa somente os dados gravados no próprio registro (cópia de instituição e assinantes), nunca o cadastro atual.
 */
export function buildLayout(rec: DocumentRecord, assets: AssetStore): Layout {
  const inst = rec.institution;
  const logoAsset = assets.get(inst.logoHash);
  // Tamanhos em px; documentos emitidos antes desta configuração existir usam os valores antigos (em pt) convertidos.
  const fontPx = inst.fontSizePx ?? Math.round(inst.fontSizePt / 0.75);
  const numbered = rec.numbered || !!rec.numberLabel;
  const titlePx = inst.titleSizePx ?? Math.round((inst.fontSizePt + (numbered ? 4 : 6)) / 0.75);
  const headerLines: TextLine[] = [{ text: inst.orgName, bold: true, size: inst.orgSizePx ?? 19 }];
  if (inst.serviceName && inst.serviceName !== inst.orgName) headerLines.push({ text: inst.serviceName, bold: true, size: inst.serviceSizePx ?? fontPx });
  for (const l of inst.headerText.split('\n').filter(Boolean)) headerLines.push({ text: l });
  // endereço em uma linha e telefone/e-mail na linha de baixo (evita corte por falta de espaço)
  if (inst.address) headerLines.push({ text: inst.address, size: 12 });
  const contact = [inst.phone, inst.email].filter(Boolean).join(' • ');
  if (contact) headerLines.push({ text: contact, size: 12 });

  const blocks: Block[] = [
    { t: 'header', logo: logoAsset ? fit(logoAsset, 280, 90) : null, lines: headerLines },
    { t: 'rule' },
    numbered ? { t: 'title', text: `${rec.templateName} nº ${rec.numberLabel ?? '____'}` } : { t: 'title', text: rec.templateName, center: true },
  ];
  const place = [rec.city, longDate(rec.issueDate)].filter(Boolean).join(', ');
  blocks.push({ t: 'right', text: place });
  if (rec.recipient) blocks.push({ t: 'para', text: rec.recipient, bold: true, after: 0 });
  if (rec.recipientRole) blocks.push({ t: 'para', text: rec.recipientRole, after: 0 });
  blocks.push({ t: 'spacer', pt: 8 });
  if (rec.subject) blocks.push({ t: 'para', label: 'Assunto: ', text: rec.subject, after: 10 });
  if (rec.identification.length) {
    blocks.push({ t: 'para', text: 'Identificação', bold: true, after: 3 });
    for (const f of rec.identification) blocks.push({ t: 'para', label: `${f.label}: `, text: f.value, after: 2 });
    blocks.push({ t: 'spacer', pt: 10 });
  }
  // Texto de abertura FIXO do modelo: vem antes do texto digitado e continua na mesma frase/parágrafo.
  const lines = rec.body.split('\n');
  if (rec.openingText) {
    if (lines[0].trim() !== '') lines[0] = `${rec.openingText} ${lines[0].trim()}`;
    else lines.unshift(rec.openingText);
  }
  for (const line of lines) {
    blocks.push(line.trim() === '' ? { t: 'spacer', pt: 6 } : { t: 'para', text: line, indent: true, justify: true, after: 6 });
  }
  if (rec.closingText) blocks.push({ t: 'closing', text: rec.closingText });
  if (rec.signers.length) {
    blocks.push({ t: 'signatures', items: rec.signers.map((s) => {
      const a = assets.get(s.imageHash);
      return { name: s.name, role: s.role, image: a ? fit(a, 180, 70) : null };
    }) });
  }
  const footerLines = [inst.footerText, inst.extraInfo].flatMap((t) => t.split('\n')).filter(Boolean);
  return { blocks, footerLines, fontFamily: inst.fontFamily, fontPx, titlePx, columns: Math.min(2, Math.max(1, rec.signers.length)) };
}
