import JSZip from 'jszip';
import { AlignmentType, CheckBox, LineRuleType, Document, ExternalHyperlink, Footer, Header, ImageRun, Packer, Paragraph, Tab, TextRun } from 'docx';
import { DocumentRecord } from '../../shared/types';
import { AssetStore } from '../services/assets';
import { NOTIFICACAO_TEXTS } from '../services/defaults';
import { Img, imageSize, longDate } from './layout';
import { esc } from './html';
import { GUIDE_CSS, NOTIF_PAGE, guidesHtml, mmToTwips } from './page';

export interface Seg { text?: string; bold?: boolean; underline?: boolean; red?: boolean; big?: boolean; br?: boolean; tab?: boolean; box?: boolean; checked?: boolean; small?: boolean }
export interface NPara { segs: Seg[]; align: 'left' | 'center' | 'right' | 'justify'; firstLine?: number; left?: number; line: number; after: number; sizePt?: number }
export interface NModel { banner: Img | null; headerLines: string[]; address: string; email: string; phone: string; paras: NPara[] }

const PDF_PAD_MM = 2.5;
const FONT = 'Calibri Light';
const SERIF = 'Times New Roman';

/** Marcações dos textos fixos: **negrito**  __sublinhado__  !!vermelho!!  ^^tamanho 12^^  \n quebra  \t tabulação. */
export function parseMarkup(src: string): Seg[] {
  const out: Seg[] = []; let bold = false, ul = false, red = false, big = false, buf = '';
  const flush = () => { if (buf) { out.push({ text: buf, bold: bold || red, underline: ul || red, red, big }); buf = ''; } };
  for (let i = 0; i < src.length; i++) {
    const two = src.slice(i, i + 2);
    if (two === '**') { flush(); bold = !bold; i++; } else if (two === '__') { flush(); ul = !ul; i++; } else if (two === '!!') { flush(); red = !red; i++; } else if (two === '^^') { flush(); big = !big; i++; }
    else if (src[i] === '\n') { flush(); out.push({ br: true }); } else if (src[i] === '\t') { flush(); out.push({ tab: true }); } else buf += src[i];
  }
  flush(); return out;
}

const up = (s: string) => s.toLocaleUpperCase('pt-BR');
const blank = (s: unknown) => (typeof s === 'string' && s.trim() ? s.trim() : '__________');
const brDate = (iso: string) => (/^\d{4}-\d{2}-\d{2}$/.test(iso) ? iso.split('-').reverse().join('/') : '__/__/____');
const hhmm = (t: string) => (/^\d{2}:\d{2}$/.test(t) ? t.replace(':', 'h') : '__h__');

function fitBanner(a: { mime: Img['mime']; data: Uint8Array } | null): Img | null {
  if (!a) return null;
  const s = imageSize(a.data); const k = Math.min(335 / (s.w || 335), 61 / (s.h || 61));
  return { mime: a.mime, bytes: a.data, w: Math.round((s.w || 335) * k), h: Math.round((s.h || 61) * k) };
}

/** Modelo "Notificação" do Conselho Tutelar (estrutura, tamanhos, espaçamentos e textos iguais ao documento original). */
export function buildNotificacaoModel(rec: DocumentRecord, assets: AssetStore): NModel {
  const x = rec.extra as Record<string, any>; const T = { ...NOTIFICACAO_TEXTS, ...(x._texts ?? {}) } as Record<string, string>;
  const inst = rec.institution;
  const nome: Seg[] = [{ text: 'NOME:', bold: true }, { text: ` ${up(blank(x.responsavelTipo))}: ${up(blank(x.responsavelNome))} | ${up(blank(x.menorTipo))}: ${up(blank(x.menorNome))}` }];
  const councilors: { name: string; checked: boolean }[] = Array.isArray(x._councilors) ? x._councilors : rec.signers.map((s) => ({ name: s.name, checked: true }));
  const cSegs: Seg[] = [];
  councilors.forEach((c, i) => { cSegs.push({ text: '  ' }, { box: true, checked: c.checked }, { text: ' ' }, { text: up(c.name), bold: true }); if (i < councilors.length - 1) cSegs.push({ br: true }); });
  const place = [rec.city, longDate(rec.issueDate)].filter(Boolean).join(', ');
  const paras: NPara[] = [
    { segs: [{ text: 'NOTIFICAÇÃO', bold: true }], align: 'center', line: 259, after: 160, sizePt: 16 },
    { segs: nome, align: 'left', line: 240, after: 160 },
    { segs: [{ text: '  ENDEREÇO:', bold: true }, { text: ` ${up(blank(x.endereco))}` }], align: 'justify', left: -142, line: 240, after: 0 },
    { segs: [], align: 'justify', left: -142, line: 240, after: 0 },
    { segs: parseMarkup(T.greeting), align: 'justify', firstLine: 709, line: 360, after: 160 },
    { segs: parseMarkup(T.intro), align: 'justify', firstLine: 709, line: 360, after: 160 },
    { segs: [{ text: 'DATA', bold: true, underline: true }, { text: `: ${brDate(x.dataComparecimento)} `, underline: true }, { text: 'HORÁRIO', bold: true, underline: true }, { text: `: ${hhmm(x.horario)}`, underline: true }], align: 'justify', line: 360, after: 160 },
    { segs: [], align: 'justify', line: 259, after: 160, sizePt: 14 },
    { segs: [{ text: place }], align: 'right', line: 259, after: 160 },
    { segs: [{ text: 'CONSELHEIRO (S):', bold: true }], align: 'left', line: 259, after: 160 },
    { segs: cSegs, align: 'left', line: 259, after: 160, sizePt: 10 },
    { segs: [{ tab: true }], align: 'left', line: 259, after: 160 },
    { segs: [{ tab: true }, ...parseMarkup(T.closing)], align: 'left', line: 259, after: 160 },
    { segs: parseMarkup(T.warning), align: 'justify', line: 259, after: 160 },
    { segs: parseMarkup(T.important), align: 'justify', line: 259, after: 160 },
  ];
  return { banner: fitBanner(assets.get(inst.logoHash)), headerLines: inst.headerText.split('\n').map((l) => l.trim()).filter(Boolean), address: inst.address, email: inst.email, phone: inst.phone, paras };
}

/* ---------------- DOCX ---------------- */
const segRuns = (segs: Seg[], sizePt?: number): (TextRun | CheckBox)[] => segs.map((s) => {
  const size = Math.round((s.big ? 12 : sizePt ?? 11) * 2);
  if (s.br) return new TextRun({ break: 1, font: FONT, size });
  if (s.tab) return new TextRun({ children: [new Tab()], font: FONT, size });
  if (s.box) return new CheckBox({ checked: !!s.checked, checkedState: { value: '2612', font: 'MS Gothic' }, uncheckedState: { value: '2610', font: 'MS Gothic' } });
  return new TextRun({ text: s.text ?? '', font: FONT, size, bold: s.bold, underline: s.underline ? {} : undefined, color: s.red ? 'FF0000' : undefined });
});
const AL = { left: AlignmentType.LEFT, center: AlignmentType.CENTER, right: AlignmentType.RIGHT, justify: AlignmentType.BOTH } as const;

export async function buildNotificacaoDocx(m: NModel): Promise<Buffer> {
  const hdr: Paragraph[] = [];
  const sp = { after: 0, line: 240, lineRule: LineRuleType.AUTO };
  if (m.banner) hdr.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: sp, children: [new ImageRun({ type: m.banner.mime === 'image/png' ? 'png' : 'jpg', data: Buffer.from(m.banner.bytes), transformation: { width: m.banner.w, height: m.banner.h } })] }));
  for (const l of m.headerLines) hdr.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: sp, children: [new TextRun({ text: l, bold: true, font: SERIF, size: 15 })] }));
  hdr.push(new Paragraph({ spacing: sp, children: [] }));
  const ft = (t: string, bold = true) => new TextRun({ text: t, bold, font: SERIF, size: 16 });
  const foot = [
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: sp, children: [ft(m.address)] }),
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: sp, children: [ft('E-mail: '), ...(m.email ? [new ExternalHyperlink({ link: `mailto:${m.email}`, children: [new TextRun({ text: m.email, font: SERIF, size: 16, color: '0563C1', underline: {} })] })] : []), ft(`     Telefone: ${m.phone}`)] }),
    new Paragraph({ spacing: sp, children: [] }),
  ];
  const body = m.paras.map((p) => new Paragraph({
    alignment: AL[p.align], spacing: { after: p.after, line: p.line, lineRule: LineRuleType.AUTO }, indent: p.firstLine || p.left ? { firstLine: p.firstLine, left: p.left } : undefined,
    run: p.segs.length === 0 && p.sizePt ? { size: p.sizePt * 2 } : undefined, children: segRuns(p.segs.map((s) => (p.sizePt && p === m.paras[0] ? { ...s } : s)), p.sizePt),
  }));
  const doc = new Document({
    creator: 'ArrumaAí', title: 'Notificação',
    styles: { default: { document: { run: { font: FONT, size: 22 }, paragraph: { spacing: { after: 160, line: 259, lineRule: LineRuleType.AUTO } } } } },
    sections: [{ properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 709, right: 1134, bottom: 709, left: 1418, header: 426, footer: 0 } } },
      headers: { default: new Header({ children: hdr }) }, footers: { default: new Footer({ children: foot }) }, children: body }],
  });
  return fixCheckboxes(await Packer.toBuffer(doc));
}

/** Caixas de seleção idênticas às do Word: controle de conteúdo com símbolo ☒/☐ em MS Gothic, negrito, 14 pt (a biblioteca gera um símbolo diferente). */
async function fixCheckboxes(buf: Buffer): Promise<Buffer> {
  const zip = await JSZip.loadAsync(buf);
  let xml = await zip.file('word/document.xml')!.async('string');
  const rpr = '<w:rFonts w:ascii="MS Gothic" w:eastAsia="MS Gothic" w:hAnsi="MS Gothic" w:hint="eastAsia"/><w:b/><w:sz w:val="28"/><w:szCs w:val="28"/>';
  xml = xml.replace(/<w:sdt>(<w:sdtPr>)(.*?<w14:checked w14:val="(\d)"\/>.*?)<\/w:sdtPr><w:sdtContent>.*?<\/w:sdtContent><\/w:sdt>/gs,
    (_m, open, mid, on) => `<w:sdt>${open}<w:rPr><w:b/><w:sz w:val="28"/><w:szCs w:val="28"/></w:rPr>${mid}</w:sdtPr><w:sdtContent><w:r><w:rPr>${rpr}</w:rPr><w:t>${on === '1' ? '☒' : '☐'}</w:t></w:r></w:sdtContent></w:sdt>`);
  zip.file('word/document.xml', xml);
  return zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
}

/* ---------------- HTML (prévia e PDF) ---------------- */
const uri = (i: { mime: string; bytes: Uint8Array }) => `data:${i.mime};base64,${Buffer.from(i.bytes).toString('base64')}`;
const segHtml = (s: Seg): string => {
  if (s.br) return '<br>'; if (s.tab) return '<span class="tab"></span>';
  if (s.box) return `<span class="box">${s.checked ? '☒' : '☐'}</span>`;
  const st = [s.bold ? 'font-weight:700' : '', s.underline ? 'text-decoration:underline' : '', s.red ? 'color:#f00' : '', s.big ? 'font-size:12pt' : ''].filter(Boolean).join(';');
  return `<span${st ? ` style="${st}"` : ''}>${esc(s.text ?? '')}</span>`;
};

export function notificacaoFooterHtml(m: NModel): string {
  const mail = m.email ? `<span style="color:#0563C1;text-decoration:underline;font-weight:400">${esc(m.email)}</span>` : '';
  return `<div style="width:100%;text-align:center;font-family:'${SERIF}',serif;font-size:10.7px;line-height:1.2;font-weight:700;padding:0 0 0 0">${esc(m.address)}<br>E-mail: ${mail}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Telefone: ${esc(m.phone)}</div>`;
}

export function buildNotificacaoHtml(m: NModel, opts: { screen?: boolean; banner?: string } = {}): string {
  // No PDF o texto não pode sair da área de impressão: a margem esquerda diminui 2,5 mm e o corpo ganha esse recuo (o recuo negativo do ENDEREÇO usa essa folga).
  const padPdf = opts.screen ? '' : `body{padding-left:${PDF_PAD_MM}mm}.neg{margin-left:-${PDF_PAD_MM}mm!important}`;
  const paras = m.paras.map((p) => {
    const st = [`text-align:${p.align}`, `line-height:${(1.22 * p.line / 240).toFixed(3)}`, `margin:0 0 ${p.after / 20}pt ${p.left && opts.screen ? p.left / 20 + 'pt' : '0'}`, p.firstLine ? `text-indent:${p.firstLine / 20}pt` : '', p.sizePt ? `font-size:${p.sizePt}pt` : ''].filter(Boolean).join(';');
    const bold = p === m.paras[0] ? 'font-weight:700;' : '';
    return `<p${p.left && !opts.screen ? ' class="neg"' : ''} style="${st};${bold}">${p.segs.length ? p.segs.map(segHtml).join('') : '&nbsp;'}</p>`;
  }).join('\n');
  const head = `<div class="hd">${m.banner ? `<img src="${uri(m.banner)}" width="${m.banner.w}" height="${m.banner.h}" alt="">` : ''}${m.headerLines.map((l) => `<div>${esc(l)}</div>`).join('')}<div>&nbsp;</div></div>`;
  const mail = m.email ? `<span class="lk">${esc(m.email)}</span>` : '';
  const foot = `<div class="ft"><b>${esc(m.address)}</b><br><b>E-mail: </b>${mail}<b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Telefone: ${esc(m.phone)}</b></div>`;
  const P = NOTIF_PAGE;
  return `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src data:; style-src 'unsafe-inline'">
<style>*{box-sizing:border-box}html,body{margin:0;padding:0}${padPdf}
body{font-family:'${FONT}','Calibri','Carlito',sans-serif;font-size:11pt;color:#000;overflow-wrap:anywhere}
.hd{text-align:center;font-family:'${SERIF}',serif;font-weight:700;font-size:7.5pt;line-height:1.15}.hd img{display:block;margin:0 auto}
p{white-space:pre-wrap}.tab{display:inline-block;width:36pt}.box{font-family:'MS Gothic','Segoe UI Symbol','DejaVu Sans',sans-serif;font-size:14pt;font-weight:700}
.ft{text-align:center;font-family:'${SERIF}',serif;font-size:8pt;line-height:1.15}.lk{color:#0563C1;text-decoration:underline}
${opts.screen ? `${GUIDE_CSS}body{background:#e6e8ec;padding:20px}.banner{max-width:210mm;margin:0 auto 12px;background:#fff7e0;border:1px solid #e3c46a;color:#5b4500;padding:8px 12px;font:13px system-ui,sans-serif;border-radius:6px}
.paper{background:#fff;max-width:210mm;min-height:297mm;margin:0 auto;padding:${P.top}mm ${P.right}mm ${P.bottom}mm ${P.left}mm;box-shadow:0 2px 12px rgba(0,0,0,.18)}@media (max-width:900px){.paper{padding:6mm!important}}
.ft{position:absolute;left:0;right:0;bottom:5mm}` : ''}</style></head><body>
${opts.screen && opts.banner ? `<div class="banner">${esc(opts.banner)}</div>` : ''}${opts.screen ? '<div class="paper">' : ''}${head}${paras}${opts.screen ? foot + guidesHtml(P.top, P.bottom) + '</div>' : ''}
</body></html>`;
}
export const notificacaoPdfMargins = { top: NOTIF_PAGE.top / 25.4, bottom: NOTIF_PAGE.bottom / 25.4, left: (NOTIF_PAGE.left - PDF_PAD_MM) / 25.4, right: NOTIF_PAGE.right / 25.4 };
void mmToTwips;
