import { InstitutionSnapshot, MONTHS_PT, StatsReport } from '../../shared/types';
import { esc } from './html';

const monthLabel = (m: string) => `${MONTHS_PT[Number(m.slice(5, 7)) - 1].slice(0, 3)}/${m.slice(0, 4)}`;
const brDate = (iso: string) => iso.split('-').reverse().join('/');

/** Célula de CSV segura: aspas escapadas e proteção contra fórmulas (=, +, -, @) ao abrir no Excel. */
export function csvCell(v: string | number): string {
  let s = String(v);
  if (/^[=+\-@\t\r]/.test(s) && !/^-?\d+([.,]\d+)?$/.test(s)) s = `'${s}`;
  return /[";\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

/** Planilha única (separador ";", com BOM) que abre direto no Excel em português. */
export function buildStatsCsv(r: StatsReport, orgName: string): string {
  const L: (string | number)[][] = [
    ['Relatório estatístico', orgName], ['Período', `${brDate(r.from)} a ${brDate(r.to)}`], [],
    ['RESUMO'], ['Emitidos', r.totals.emitido], ['Cancelados', r.totals.cancelado], ['Total registrado', r.totals.total], [],
    ['POR TIPO DE DOCUMENTO', 'Emitidos', 'Cancelados'], ...r.byType.map((t) => [t.name, t.emitido, t.cancelado]), [],
    ['POR MÊS (emitidos)', ...r.typeNames, 'Total emitidos', 'Cancelados'], ...r.months.map((m) => [monthLabel(m.month), ...r.typeNames.map((n) => m.counts[n] ?? 0), m.emitido, m.cancelado]), [],
    ['DESTINATÁRIOS MAIS FREQUENTES', 'Documentos'], ...r.byRecipient.map((x) => [x.name, x.count]), [],
    ['QUEM MAIS ASSINOU', 'Documentos'], ...r.bySigner.map((x) => [x.name, x.count]),
  ];
  return '\uFEFF' + L.map((row) => row.map(csvCell).join(';')).join('\r\n') + '\r\n';
}

export function buildStatsHtml(r: StatsReport, inst: InstitutionSnapshot): string {
  const table = (head: string[], rows: (string | number)[][], right = true) =>
    `<table><thead><tr>${head.map((h, i) => `<th${i && right ? ' class="n"' : ''}>${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.map((row) => `<tr>${row.map((c, i) => `<td${i && right ? ' class="n"' : ''}>${esc(String(c))}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${head.length}">Sem registros no período.</td></tr>`}</tbody></table>`;
  const max = Math.max(1, ...r.months.map((m) => m.emitido));
  const bars = r.months.map((m) => `<div class="b"><span class="l">${esc(monthLabel(m.month))}</span><span class="bar" style="width:${Math.round((m.emitido / max) * 100)}%"></span><span class="v">${m.emitido}</span></div>`).join('');
  const font = inst.fontFamily.replace(/['"<>]/g, '');
  return `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'">
<style>body{font-family:'${font}','Times New Roman',serif;font-size:11pt;color:#000}h1{font-size:18pt;text-align:center;margin:8pt 0 2pt}h2{font-size:12.5pt;margin:16pt 0 5pt;border-bottom:1pt solid #444;padding-bottom:2pt}
.hd{text-align:center;line-height:1.3}.sub{text-align:center;margin-bottom:8pt}table{width:100%;border-collapse:collapse;margin-top:4pt}th,td{border:0.6pt solid #888;padding:3pt 5pt;text-align:left;font-size:10pt}th{background:#e8ecf0}.n{text-align:right}
.cards{display:flex;gap:10pt;margin-top:6pt}.card{flex:1;border:0.8pt solid #444;padding:6pt;text-align:center}.card b{display:block;font-size:18pt}
.b{display:flex;align-items:center;gap:6pt;margin:2pt 0;font-size:9.5pt}.l{width:52pt}.bar{display:inline-block;height:9pt;background:#1d6fb8}.v{font-weight:700}tr{break-inside:avoid}h2{break-after:avoid}</style></head><body>
<div class="hd"><b>${esc(inst.orgName)}</b>${inst.serviceName && inst.serviceName !== inst.orgName ? `<br>${esc(inst.serviceName)}` : ''}</div>
<h1>Relatório Estatístico</h1><div class="sub">Período: ${brDate(r.from)} a ${brDate(r.to)}</div>
<div class="cards"><div class="card"><b>${r.totals.emitido}</b>Emitidos</div><div class="card"><b>${r.totals.cancelado}</b>Cancelados</div><div class="card"><b>${r.totals.total}</b>Total registrado</div></div>
<h2>Por tipo de documento</h2>${table(['Tipo', 'Emitidos', 'Cancelados'], r.byType.map((t) => [t.name, t.emitido, t.cancelado]))}
<h2>Por mês (documentos emitidos)</h2>${bars}
${table(['Mês', ...r.typeNames, 'Total', 'Cancelados'], r.months.map((m) => [monthLabel(m.month), ...r.typeNames.map((n) => m.counts[n] ?? 0), m.emitido, m.cancelado]))}
<h2>Destinatários mais frequentes</h2>${table(['Destinatário', 'Documentos'], r.byRecipient.map((x) => [x.name, x.count]))}
<h2>Quem mais assinou</h2>${table(['Responsável', 'Documentos'], r.bySigner.map((x) => [x.name, x.count]))}
<p style="font-size:9pt;margin-top:14pt">Cancelados são contados à parte e não entram nos totais por tipo, mês, destinatário e responsável. Rascunhos não são contados.</p>
</body></html>`;
}
