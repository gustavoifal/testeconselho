import { AlignmentType, BorderStyle, Document, Footer, ImageRun, PageNumber, Packer, Paragraph, Table, TableCell, TableRow, TextRun, WidthType } from 'docx';
import { Block, Img, Layout } from './layout';

const NONE = { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' };
const pt = (n: number) => Math.round(n * 20); // pontos -> twips
const image = (i: Img) => new ImageRun({ type: i.mime === 'image/png' ? 'png' : 'jpg', data: Buffer.from(i.bytes), transformation: { width: i.w, height: i.h } });

function blockToDocx(b: Block, L: Layout): (Paragraph | Table)[] {
  const size = (n?: number) => (n ?? L.fontSizePt) * 2;
  switch (b.t) {
    case 'header': {
      const out: Paragraph[] = [];
      if (b.logo) out.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 80 }, children: [image(b.logo)] }));
      for (const l of b.lines) out.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 20 }, children: [new TextRun({ text: l.text, bold: l.bold, italics: l.italic, size: size(l.size) })] }));
      return out;
    }
    case 'rule':
      return [new Paragraph({ spacing: { after: 200 }, border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: '444444', space: 4 } }, children: [] })];
    case 'title':
      return [new Paragraph({ alignment: b.center ? AlignmentType.CENTER : AlignmentType.LEFT, spacing: { before: 120, after: 200 }, children: [new TextRun({ text: b.text, bold: true, size: b.center ? size(L.fontSizePt + 2) : undefined })] })];
    case 'right':
      return [new Paragraph({ alignment: AlignmentType.RIGHT, spacing: { after: 240 }, children: [new TextRun(b.text)] })];
    case 'para': {
      const runs: TextRun[] = [];
      if (b.label) runs.push(new TextRun({ text: b.label, bold: true }));
      runs.push(new TextRun({ text: b.text, bold: b.bold }));
      return [new Paragraph({ alignment: b.justify ? AlignmentType.JUSTIFIED : AlignmentType.LEFT, indent: b.indent ? { firstLine: 709 } : undefined, spacing: { after: pt(b.after ?? 6), line: 300 }, children: runs })];
    }
    case 'spacer':
      return [new Paragraph({ spacing: { after: pt(b.pt) }, children: [] })];
    case 'closing':
      return [new Paragraph({ keepNext: true, keepLines: true, spacing: { before: 240, after: 360 }, indent: { firstLine: 709 }, children: [new TextRun(b.text)] })];
    case 'signatures': {
      const cols = L.columns;
      const rows: TableRow[] = [];
      for (let i = 0; i < b.items.length; i += cols) {
        const slice = b.items.slice(i, i + cols);
        const cells = slice.map((s) => new TableCell({
          width: { size: Math.floor(100 / cols), type: WidthType.PERCENTAGE },
          borders: { top: NONE, bottom: NONE, left: NONE, right: NONE },
          margins: { top: 120, bottom: 240, left: 120, right: 120 },
          children: [
            new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true, children: s.image ? [image(s.image)] : [new TextRun('')], spacing: { before: s.image ? 0 : 480 } }),
            new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true, children: [new TextRun('______________________________')] }),
            new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true, children: [new TextRun({ text: s.name, bold: true })] }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: s.role, size: size(L.fontSizePt - 1) })] }),
          ],
        }));
        while (cells.length < cols) cells.push(new TableCell({ borders: { top: NONE, bottom: NONE, left: NONE, right: NONE }, children: [new Paragraph('')] }));
        rows.push(new TableRow({ cantSplit: true, children: cells }));
      }
      return [new Table({ width: { size: 100, type: WidthType.PERCENTAGE }, borders: { top: NONE, bottom: NONE, left: NONE, right: NONE, insideHorizontal: NONE, insideVertical: NONE }, rows })];
    }
  }
}

export async function buildDocx(L: Layout): Promise<Buffer> {
  const footerParas = [
    ...L.footerLines.map((t) => new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 0 }, children: [new TextRun({ text: t, size: 16 })] })),
    new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ size: 16, children: ['Página ', PageNumber.CURRENT, ' de ', PageNumber.TOTAL_PAGES] })] }),
  ];
  const doc = new Document({
    creator: 'ArrumaAí', title: 'Documento ArrumaAí',
    styles: { default: { document: { run: { font: L.fontFamily, size: L.fontSizePt * 2 } } } },
    sections: [{
      properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1417, bottom: 1417, left: 1701, right: 1134, footer: 567 } } },
      footers: { default: new Footer({ children: footerParas }) },
      children: L.blocks.flatMap((b) => blockToDocx(b, L)),
    }],
  });
  return Packer.toBuffer(doc);
}
