/** Medidas da página A4 (mm). Margem superior reduzida (logo mais perto do topo). */
export const A4_H = 297;
export const PAGE = { top: 12.5, bottom: 26.7, left: 30, right: 20 };
export const NOTIF_PAGE = { top: 7.5, bottom: 20, left: 25, right: 20 };
export const mmToIn = (mm: number) => mm / 25.4;
export const mmToTwips = (mm: number) => Math.round((mm / 25.4) * 1440);

/** Linhas pontilhadas na prévia mostrando onde cada folha termina (aproximado: o Word/PDF podem quebrar linhas de forma ligeiramente diferente). */
export function guidesHtml(topMm: number, bottomMm: number, pages = 15): string {
  const content = A4_H - topMm - bottomMm;
  return Array.from({ length: pages }, (_, k) => `<div class="guide" style="top:${(topMm + (k + 1) * content).toFixed(1)}mm"><span>fim da folha ${k + 1}</span></div>`).join('');
}
export const GUIDE_CSS = `.paper{position:relative;overflow:hidden}.guide{position:absolute;left:0;right:0;height:0;border-top:2px dotted #c0392b;pointer-events:none}.guide span{position:absolute;right:6px;top:2px;font:10px system-ui,sans-serif;color:#c0392b;background:#fff}`;
