import { Layout } from './layout';

export const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
const uri = (i: { mime: string; bytes: Uint8Array }) => `data:${i.mime};base64,${Buffer.from(i.bytes).toString('base64')}`;

/** HTML do documento. `screen` = folha de papel para a prévia; sem `screen` = conteúdo para o PDF (margens vêm do printToPDF). */
export function buildHtml(L: Layout, opts: { screen?: boolean; banner?: string } = {}): string {
  const body = L.blocks.map((b) => {
    switch (b.t) {
      case 'header':
        return `<div class="hd">${b.logo ? `<img src="${uri(b.logo)}" width="${b.logo.w}" height="${b.logo.h}" alt="">` : ''}${b.lines.map((l) =>
          `<div style="${l.bold ? 'font-weight:700;' : ''}${l.italic ? 'font-style:italic;' : ''}${l.size ? `font-size:${l.size}pt;` : ''}">${esc(l.text)}</div>`).join('')}</div>`;
      case 'rule': return '<hr>';
      case 'title': return `<div class="title">${esc(b.text)}</div>`;
      case 'right': return `<div class="right">${esc(b.text)}</div>`;
      case 'para': return `<p class="${b.indent ? 'ind ' : ''}${b.justify ? 'jus' : ''}" style="margin-bottom:${b.after ?? 6}pt;${b.bold ? 'font-weight:700' : ''}">${b.label ? `<b>${esc(b.label)}</b>` : ''}${esc(b.text)}</p>`;
      case 'spacer': return `<div style="height:${b.pt}pt"></div>`;
      case 'closing': return `<p class="closing">${esc(b.text)}</p>`;
      case 'signatures':
        return `<div class="sigs" style="grid-template-columns:repeat(${L.columns},1fr)">${b.items.map((s) => `<div class="sig">${s.image ? `<img src="${uri(s.image)}" width="${s.image.w}" height="${s.image.h}" alt="">` : '<div style="height:36pt"></div>'}<div class="ln"></div><div><b>${esc(s.name)}</b></div><div class="rl">${esc(s.role)}</div></div>`).join('')}</div>`;
    }
  }).join('\n');
  const font = L.fontFamily.replace(/['"<>]/g, '');
  return `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src data:; style-src 'unsafe-inline'">
<style>
*{box-sizing:border-box} html,body{margin:0;padding:0}
body{font-family:'${font}','Times New Roman',serif;font-size:${L.fontSizePt}pt;line-height:1.35;color:#000;overflow-wrap:anywhere;word-break:break-word}
.hd{text-align:center;margin-bottom:4pt}.hd img{display:block;margin:0 auto 4pt;max-width:100%}
hr{border:0;border-top:1.2pt solid #444;margin:8pt 0 10pt}
.title{font-weight:700;margin:6pt 0 10pt}.right{text-align:right;margin-bottom:12pt}
p{margin:0}.ind{text-indent:1.25cm}.jus{text-align:justify}
.closing{margin:12pt 0 18pt;text-indent:1.25cm;break-after:avoid;page-break-after:avoid}
.sigs{display:grid;gap:18pt 24pt;margin-top:6pt}
.sig{text-align:center;break-inside:avoid;page-break-inside:avoid}.sig img{display:block;margin:0 auto}
.ln{border-top:0;height:0;margin:0 auto 2pt;width:80%;border-bottom:0.8pt solid #000}.rl{font-size:${L.fontSizePt - 1}pt}
${opts.screen ? `@media (max-width:900px){.paper{padding:12mm!important}}body{background:#e6e8ec;padding:20px}.banner{max-width:210mm;margin:0 auto 12px;background:#fff7e0;border:1px solid #e3c46a;color:#5b4500;padding:8px 12px;font:13px system-ui,sans-serif;border-radius:6px}
.paper{background:#fff;max-width:210mm;min-height:297mm;margin:0 auto;padding:25mm 20mm 25mm 30mm;box-shadow:0 2px 12px rgba(0,0,0,.18)}
.foot{margin-top:30pt;border-top:1px solid #ccc;padding-top:6pt;text-align:center;font-size:8pt;color:#444}` : ''}
</style></head><body>
${opts.screen && opts.banner ? `<div class="banner">${esc(opts.banner)}</div>` : ''}
${opts.screen ? '<div class="paper">' : ''}${body}${opts.screen && L.footerLines.length ? `<div class="foot">${L.footerLines.map(esc).join('<br>')}</div>` : ''}${opts.screen ? '</div>' : ''}
</body></html>`;
}

/** Rodapé do PDF (texto institucional + "Página X de Y"), no formato aceito por printToPDF. */
export function footerTemplate(L: Layout): string {
  return `<div style="width:100%;font-size:8px;font-family:Arial,sans-serif;text-align:center;color:#333;padding:0 40px">${L.footerLines.map(esc).join('<br>')}${L.footerLines.length ? '<br>' : ''}Página <span class="pageNumber"></span> de <span class="totalPages"></span></div>`;
}
