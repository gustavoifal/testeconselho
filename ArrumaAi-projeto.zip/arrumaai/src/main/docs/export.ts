import * as fs from 'node:fs';
import * as path from 'node:path';
import { AppError, DocumentRecord } from '../../shared/types';
import { AssetStore } from '../services/assets';
import { writeFileAtomic } from '../db/database';
import { buildLayout, Layout } from './layout';
import { buildDocx } from './docx';
import { buildHtml, footerTemplate } from './html';
import { buildNotificacaoDocx, buildNotificacaoHtml, buildNotificacaoModel, notificacaoFooterHtml, notificacaoPdfMargins } from './notificacao';

export interface PdfOptions { margins?: { top: number; bottom: number; left: number; right: number } }
export type PdfRenderer = (html: string, footerHtml: string, opts?: PdfOptions) => Promise<Buffer>;
export type Format = 'docx' | 'pdf';
export interface ExportOptions { dir: string; baseName: string; formats: Format[]; overwrite: boolean }

const RESERVED = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i;
export function sanitizeFileName(name: string): string {
  // eslint-disable-next-line no-control-regex
  let n = String(name ?? '').normalize('NFC').replace(/\.(docx|pdf)$/i, '').replace(/[<>:"/\\|?*\u0000-\u001F]/g, '-').replace(/\s+/g, ' ').trim().replace(/[. ]+$/g, '');
  if (!n || RESERVED.test(n)) n = n ? `${n}_` : '';
  return n.slice(0, 120);
}
export function suggestFileName(rec: DocumentRecord): string {
  return sanitizeFileName(`${rec.templateName}-${rec.numberLabel ?? `${rec.issueDate}-${rec.id || 'previa'}`}`.replace(/\//g, '-')) || 'documento';
}

function friendly(e: any): AppError {
  const map: Record<string, string> = {
    EACCES: 'Sem permissão para gravar na pasta escolhida. Escolha outra pasta.',
    EPERM: 'Sem permissão para gravar na pasta escolhida. Escolha outra pasta.',
    ENOSPC: 'Não há espaço livre suficiente no disco.',
    ENOENT: 'A pasta de destino não existe mais.',
    EBUSY: 'O arquivo está aberto em outro programa. Feche o Word ou o leitor de PDF e tente novamente.',
    EROFS: 'A pasta escolhida é somente leitura.',
  };
  return new AppError('EXPORT_FAILED', map[e?.code] ?? 'Não foi possível salvar o arquivo.');
}

export function existingFiles(opts: Pick<ExportOptions, 'dir' | 'baseName' | 'formats'>): string[] {
  const base = sanitizeFileName(opts.baseName);
  return opts.formats.map((f) => path.join(opts.dir, `${base}.${f}`)).filter((p) => fs.existsSync(p));
}

export function renderLayout(rec: DocumentRecord, assets: AssetStore): Layout { return buildLayout(rec, assets); }
export function previewHtml(rec: DocumentRecord, assets: AssetStore): string {
  const guide = ' As linhas pontilhadas vermelhas mostram, de forma aproximada, onde cada folha termina.';
  if (rec.layoutKind === 'notificacao') return buildNotificacaoHtml(buildNotificacaoModel(rec, assets), { screen: true, banner: (rec.status === 'rascunho' ? 'PRÉVIA — o documento só é registrado quando você confirmar a emissão.' : 'Visualização do documento emitido.') + guide });
  return buildHtml(buildLayout(rec, assets), { screen: true, banner: (rec.status === 'rascunho' ? (rec.numbered ? 'PRÉVIA — o número definitivo só é reservado quando você confirmar a emissão.' : 'PRÉVIA — o documento só é registrado quando você confirmar a emissão.') : 'Visualização do documento emitido.') + guide });
}
/** Gera os arquivos na memória primeiro; só grava se tudo foi gerado (sem arquivos pela metade). */
export async function exportDocument(rec: DocumentRecord, assets: AssetStore, opts: ExportOptions, pdf: PdfRenderer): Promise<{ docxPath?: string; pdfPath?: string }> {
  if (rec.status === 'rascunho') throw new AppError('NOT_ISSUED', 'Emita o documento antes de exportar.');
  if (!opts.formats.length) throw new AppError('VALIDATION', 'Escolha ao menos um formato (Word ou PDF).');
  if (!path.isAbsolute(opts.dir)) throw new AppError('VALIDATION', 'Pasta de destino inválida.');
  let st: fs.Stats | undefined;
  try { st = fs.statSync(opts.dir); } catch { /* tratado abaixo */ }
  if (!st?.isDirectory()) throw new AppError('EXPORT_FAILED', 'A pasta de destino não existe.');
  const base = sanitizeFileName(opts.baseName);
  if (!base) throw new AppError('VALIDATION', 'Informe um nome de arquivo válido.');
  const exists = existingFiles({ ...opts, baseName: base });
  if (exists.length && !opts.overwrite) throw new AppError('FILE_EXISTS', `Já existe um arquivo com esse nome: ${exists.map((e) => path.basename(e)).join(', ')}.`);

  const notif = rec.layoutKind === 'notificacao' ? buildNotificacaoModel(rec, assets) : null;
  const L = buildLayout(rec, assets);
  let docx: Buffer | undefined; let pdfBuf: Buffer | undefined;
  try {
    if (opts.formats.includes('docx')) docx = notif ? await buildNotificacaoDocx(notif) : await buildDocx(L);
    if (opts.formats.includes('pdf')) pdfBuf = notif ? await pdf(buildNotificacaoHtml(notif), notificacaoFooterHtml(notif), { margins: notificacaoPdfMargins }) : await pdf(buildHtml(L), footerTemplate(L));
  } catch (e) {
    if (e instanceof AppError) throw e;
    throw new AppError('EXPORT_FAILED', 'Não foi possível gerar o documento. Tente novamente.');
  }
  const out: { docxPath?: string; pdfPath?: string } = {};
  try {
    if (docx) { out.docxPath = path.join(opts.dir, `${base}.docx`); writeFileAtomic(out.docxPath, docx); }
    if (pdfBuf) { out.pdfPath = path.join(opts.dir, `${base}.pdf`); writeFileAtomic(out.pdfPath, pdfBuf); }
  } catch (e) { throw friendly(e); }
  return out;
}
