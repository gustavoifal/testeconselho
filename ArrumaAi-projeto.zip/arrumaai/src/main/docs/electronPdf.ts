import { BrowserWindow, app } from 'electron';
import * as fs from 'node:fs';
import * as path from 'node:path';
import * as crypto from 'node:crypto';
import { PdfRenderer } from './export';

/** PDF gerado localmente pelo motor do próprio Electron (sem internet, sem serviços externos). */
export const electronPdf: PdfRenderer = async (html, footerHtml) => {
  const tmp = path.join(app.getPath('temp'), `arrumaai-${crypto.randomBytes(8).toString('hex')}.html`);
  fs.writeFileSync(tmp, html, 'utf8');
  const win = new BrowserWindow({ show: false, webPreferences: { sandbox: true, javascript: false, contextIsolation: true, nodeIntegration: false } });
  try {
    await win.loadFile(tmp);
    return Buffer.from(await win.webContents.printToPDF({
      pageSize: 'A4', printBackground: true, displayHeaderFooter: true, headerTemplate: '<span></span>', footerTemplate: footerHtml,
      margins: { top: 0.98, bottom: 1.05, left: 1.18, right: 0.79 },
    }));
  } finally { win.destroy(); fs.rmSync(tmp, { force: true }); }
};
