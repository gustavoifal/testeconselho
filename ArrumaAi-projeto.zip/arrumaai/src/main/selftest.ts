// Teste de integração com o Electron REAL: gera DOCX e PDF de vários cenários e grava um resumo em JSON.
import { app } from 'electron';
import * as fs from 'node:fs';
import * as path from 'node:path';
import * as zlib from 'node:zlib';
import { AppCore } from './context';
import { electronPdf } from './docs/electronPdf';
import { exportDocument } from './docs/export';
import { DocumentInput } from '../shared/types';

function png(w: number, h: number, rgb: [number, number, number]): Buffer {
  const crcT = Array.from({ length: 256 }, (_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c >>> 0; });
  const crc = (b: Buffer) => { let c = 0xffffffff; for (const x of b) c = crcT[(c ^ x) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
  const chunk = (t: string, d: Buffer) => { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const c = Buffer.alloc(4); c.writeUInt32BE(crc(td)); return Buffer.concat([l, td, c]); };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  const raw = Buffer.alloc((w * 3 + 1) * h);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const o = y * (w * 3 + 1) + 1 + x * 3; raw[o] = rgb[0]; raw[o + 1] = rgb[1]; raw[o + 2] = rgb[2]; }
  return Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}

app.on('window-all-closed', () => { /* a janela oculta do PDF fecha entre os casos */ });
app.whenReady().then(async () => {
  const out = process.env.SELFTEST_OUT ?? '/tmp/arrumaai-selftest';
  fs.rmSync(out, { recursive: true, force: true }); fs.mkdirSync(out, { recursive: true });
  const results: Record<string, unknown> = {};
  try {
    const core = await AppCore.create({ dbFile: path.join(out, 'db', 'a.db') });
    core.auth.setPassword('senha-admin-123');
    core.registry.setLogoBytes('demo', png(300, 120, [30, 90, 140]));
    const tpl = core.registry.listTemplates('demo')[0];
    const [a, b] = core.signers.listSelectable('demo', tpl.id);
    core.signers.setSignatureImageBytes('demo', a.id, png(180, 60, [20, 20, 20]));
    const base: DocumentInput = { serviceId: 'demo', templateId: tpl.id, recipient: 'Sr. Destinatário de Exemplo', recipientRole: 'Cargo de Exemplo', subject: 'Solicitação de informações — ação, coração e órgão',
      body: 'Prezados, solicitamos as informações necessárias à instrução do procedimento, com acentuação: ação, coração, órgão, informações, conciliação.', city: 'Cidade Exemplo/UF', issueDate: '2026-10-23', signers: [{ signerId: a.id, useImage: true }] };
    const longBody = Array.from({ length: 40 }, (_, i) => `Parágrafo ${i + 1}. ` + 'Texto extenso de teste para verificar quebras de página, margens e alinhamento justificado em português, com acentos como ç, ã, é, ô. '.repeat(4)).join('\n\n');
    const cases: [string, DocumentInput, (n: number) => void][] = [
      ['curto', base, () => {}],
      ['longo-multipaginas', { ...base, body: longBody }, () => {}],
      ['duas-assinaturas', { ...base, signers: [{ signerId: a.id, useImage: true }, { signerId: b.id }] }, () => core.registry.updateTemplate('demo', tpl.id, { signatureSlots: 2 })],
      ['palavra-gigante', { ...base, subject: 'A'.repeat(180), body: 'X'.repeat(400) + '\n' + 'https://exemplo.invalid/' + 'caminho/'.repeat(30) , signers: [{ signerId: a.id }, { signerId: b.id }] }, () => {}],
    ];
    for (const [name, input, prep] of cases) {
      prep(0);
      const rec = core.documents.issue(input);
      const paths = await exportDocument(rec, core.assets, { dir: out, baseName: name, formats: ['docx', 'pdf'], overwrite: false }, electronPdf);
      results[name] = { numero: rec.numberLabel, ...paths };
    }
    try { await exportDocument(core.documents.get('demo', 1), core.assets, { dir: out, baseName: 'curto', formats: ['pdf'], overwrite: false }, electronPdf); results.sobrescrita = 'FALHOU: deveria recusar'; }
    catch (e: any) { results.sobrescrita = `recusada (${e.code})`; }
    try { await exportDocument(core.documents.get('demo', 1), core.assets, { dir: '/nao/existe/mesmo', baseName: 'x', formats: ['pdf'], overwrite: false }, electronPdf); results.pastaInvalida = 'FALHOU'; }
    catch (e: any) { results.pastaInvalida = `recusada (${e.code})`; }
    results.ok = true;
  } catch (e: any) { results.ok = false; results.erro = String(e?.stack ?? e); }
  fs.writeFileSync(path.join(out, 'resultado.json'), JSON.stringify(results, null, 2));
  app.exit(results.ok ? 0 : 1);
});
