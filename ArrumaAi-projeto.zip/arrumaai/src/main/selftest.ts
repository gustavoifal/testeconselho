// Teste de integração com o Electron REAL: gera DOCX e PDF de vários cenários e grava um resumo em JSON.
import { app } from 'electron';
import * as fs from 'node:fs';
import * as path from 'node:path';
import * as zlib from 'node:zlib';
import { AppCore } from './context';
import { electronPdf } from './docs/electronPdf';
import { exportDocument } from './docs/export';
import { DocumentInput } from '../shared/types';
import { buildStatsCsv, buildStatsHtml } from './docs/statsReport';

function png(w: number, h: number, rgb: [number, number, number]): Buffer {
  const crcT = Array.from({ length: 256 }, (_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c >>> 0; });
  const crc = (b: Buffer) => { let c = 0xffffffff; for (const x of b) c = crcT[(c ^ x) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
  const chunk = (t: string, d: Buffer) => { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const c = Buffer.alloc(4); c.writeUInt32BE(crc(td)); return Buffer.concat([l, td, c]); };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  const raw = Buffer.alloc((w * 3 + 1) * h);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const o = y * (w * 3 + 1) + 1 + x * 3; raw[o] = rgb[0]; raw[o + 1] = rgb[1]; raw[o + 2] = rgb[2]; }
  return Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}

app.on('window-all-closed', () => { /* a janela oculta do PDF fecha entre os casos */ });
app.whenReady().then(async () => {
  const out = process.env.SELFTEST_OUT ?? '/tmp/arrumaai-selftest';
  fs.rmSync(out, { recursive: true, force: true }); fs.mkdirSync(out, { recursive: true });
  const results: Record<string, unknown> = {};
  try {
    const core = await AppCore.create({ dbFile: path.join(out, 'db', 'a.db') });
    core.auth.setPassword('senha-admin-123');
    core.registry.setLogoBytes('demo', png(300, 120, [30, 90, 140]));
    core.registry.updateInstitution('demo', { titleSizePx: 36, orgSizePx: 24, serviceSizePx: 20 });
    const tpl = core.registry.listTemplates('demo')[0];
    const [a, b] = core.signers.listSelectable('demo', tpl.id);
    core.signers.setSignatureImageBytes('demo', a.id, png(180, 60, [20, 20, 20]));
    const base: DocumentInput = { serviceId: 'demo', templateId: tpl.id, recipient: 'Sr. Destinatário de Exemplo', recipientRole: 'Cargo de Exemplo', subject: 'Solicitação de informações — ação, coração e órgão',
      body: 'Prezados, solicitamos as informações necessárias à instrução do procedimento, com acentuação: ação, coração, órgão, informações, conciliação.', city: 'Cidade Exemplo/UF', issueDate: '2026-10-23', signers: [{ signerId: a.id, useImage: true }], identification: ['Vítima Exemplo (fictícia)', 'Responsável Exemplo', 'Rua Exemplo, 123 — Centro'] };
    const longBody = Array.from({ length: 40 }, (_, i) => `Parágrafo ${i + 1}. ` + 'Texto extenso de teste para verificar quebras de página, margens e alinhamento justificado em português, com acentos como ç, ã, é, ô. '.repeat(4)).join('\n\n');
    const cases: [string, DocumentInput, (n: number) => void][] = [
      ['curto', base, () => {}],
      ['longo-multipaginas', { ...base, body: longBody }, () => {}],
      ['duas-assinaturas', { ...base, signers: [{ signerId: a.id, useImage: true }, { signerId: b.id }] }, () => core.registry.updateTemplate('demo', tpl.id, { signatureSlots: 2 })],
      ['declaracao', { ...base, templateId: 'demo:declaracao', body: 'Declaro, para os devidos fins, que o texto desta declaração é apenas um exemplo.', signers: [{ signerId: a.id }], skipIdentification: true, identification: [] }, () => {}],
      ['relatorio-social', { ...base, templateId: 'demo:relatorio-social', body: 'Descrição da situação (exemplo).', signers: [{ signerId: a.id }] }, () => {}],
      ['palavra-gigante', { ...base, subject: 'A'.repeat(180), body: 'X'.repeat(400) + '\n' + 'https://exemplo.invalid/' + 'caminho/'.repeat(30) , signers: [{ signerId: a.id }, { signerId: b.id }] }, () => {}],
    ];
    if (process.env.NOTIF_LOGO) {
      core.signers.create({ serviceId: 'demo', fullName: 'Conselheiro Quatro Exemplo', roleTitle: 'Conselheiro (exemplo)' });
      core.signers.create({ serviceId: 'demo', fullName: 'Conselheiro Cinco Exemplo', roleTitle: 'Conselheiro (exemplo)' });
      const ids = core.signers.listSelectable('demo', 'demo:notificacao').sort((x, y) => x.id - y.id).map((x) => x.id);
      cases.push(['notificacao', { ...base, templateId: 'demo:notificacao', recipient: '', recipientRole: '', subject: '', body: '', skipIdentification: true, identification: [], city: 'Cidade Exemplo/UF', issueDate: '2026-10-20',
        signers: [ids[0], ids[3]].map((signerId) => ({ signerId })), extra: { responsavelTipo: 'MÃE', responsavelNome: 'Maria Exemplo da Silva', menorTipo: 'FILHA', menorNome: 'Ana Exemplo dos Santos Silva', endereco: 'Rua Fictícia Exemplo, número 176, bairro Centro.', dataComparecimento: '2026-10-27', horario: '08:00' } },
        () => { core.registry.setLogoBytes('demo', fs.readFileSync(process.env.NOTIF_LOGO!)); core.registry.updateInstitution('demo', { headerText: 'CONSELHO TUTELAR DOS DIREITOS DA CRIANÇA E DO ADOLESCENTE DE CIDADE EXEMPLO-UF.\nCRIADO DE ACORDO COM A LEI FEDERAL N° 8.069/90 E PELA LEI MUNICIPAL N°0000/0000', address: 'Rua Exemplo, 100 – Bairro - CEP 00000-000', email: 'exemplo@exemplo.invalid', phone: '82-90000-0000.' }); }]);
    }
    for (const [name, input, prep] of cases) {
      prep(0);
      const rec = core.documents.issue(input);
      const paths = await exportDocument(rec, core.assets, { dir: out, baseName: name, formats: ['docx', 'pdf'], overwrite: false }, electronPdf);
      results[name] = { numero: rec.numberLabel, ...paths };
    }
    try { await exportDocument(core.documents.get('demo', 1), core.assets, { dir: out, baseName: 'curto', formats: ['pdf'], overwrite: false }, electronPdf); results.sobrescrita = 'FALHOU: deveria recusar'; }
    catch (e: any) { results.sobrescrita = `recusada (${e.code})`; }
    try { await exportDocument(core.documents.get('demo', 1), core.assets, { dir: '/nao/existe/mesmo', baseName: 'x', formats: ['pdf'], overwrite: false }, electronPdf); results.pastaInvalida = 'FALHOU'; }
    catch (e: any) { results.pastaInvalida = `recusada (${e.code})`; }
    const rep = core.documents.report('demo', '2026-01-01', '2026-12-31');
    fs.writeFileSync(path.join(out, 'estatisticas.pdf'), await electronPdf(buildStatsHtml(rep, core.registry.snapshot('demo')), '<div style="width:100%;font-size:8px;text-align:center">Página <span class="pageNumber"></span> de <span class="totalPages"></span></div>'));
    fs.writeFileSync(path.join(out, 'estatisticas.csv'), buildStatsCsv(rep, 'Órgão Teste'), 'utf8');
    results.estatisticas = 'pdf e csv gerados';
    results.ok = true;
  } catch (e: any) { results.ok = false; results.erro = String(e?.stack ?? e); }
  fs.writeFileSync(path.join(out, 'resultado.json'), JSON.stringify(results, null, 2));
  app.exit(results.ok ? 0 : 1);
});
