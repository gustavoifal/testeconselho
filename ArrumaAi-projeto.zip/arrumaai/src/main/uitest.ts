// Teste de interface com o Electron REAL: abre o app, navega, emite um ofício e tira capturas de tela.
import { app, BrowserWindow } from 'electron';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { pathToFileURL } from 'node:url';
import { AppCore } from './context';
import { registerIpc } from './ipc/handlers';

const out = process.env.UITEST_OUT ?? '/tmp/arrumaai-ui';
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
app.setPath('userData', path.join(out, 'perfil')); // perfil limpo a cada execução (o texto em andamento é guardado no perfil)
app.on('window-all-closed', () => { /* controlado pelo teste */ });
app.whenReady().then(async () => {
  fs.rmSync(out, { recursive: true, force: true }); fs.mkdirSync(out, { recursive: true });
  const log: string[] = []; let failed = false;
  const core = await AppCore.create({ dbFile: path.join(out, 'db', 'a.db') });
  const idx = path.join(__dirname, '..', 'renderer', 'index.html'); const url = pathToFileURL(idx).href;
  let win: BrowserWindow | null = null;
  registerIpc(core, () => win, { backupAuto: out, backupSafety: out }, (u) => u.startsWith(url));
  win = new BrowserWindow({ width: 1280, height: 820, show: true, webPreferences: { preload: path.join(__dirname, '..', 'preload', 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true } });
  win.webContents.on('console-message', (_e, level, msg) => { if (level >= 2) log.push(`console: ${msg}`); });
  await win.loadFile(idx);
  const js = <T>(code: string): Promise<T> => win!.webContents.executeJavaScript(code);
  const shot = async (n: string) => { await sleep(400); fs.writeFileSync(path.join(out, `${n}.png`), (await win!.webContents.capturePage()).toPNG()); };
  const helpers = `window.__h = {
    set(el,v){const p=el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:el.tagName==='SELECT'?HTMLSelectElement.prototype:HTMLInputElement.prototype;Object.getOwnPropertyDescriptor(p,'value').set.call(el,v);el.dispatchEvent(new Event(el.tagName==='SELECT'?'change':'input',{bubbles:true}));},
    lab(t){const l=[...document.querySelectorAll('label')].find(x=>x.textContent.trim().startsWith(t));return l&&document.getElementById(l.htmlFor);},
    btn(t){return [...document.querySelectorAll('button')].find(b=>b.textContent.trim().includes(t));},
    txt(){return document.body.innerText;}
  }; true`;
  await js(helpers);
  const step = async (name: string, fn: () => Promise<unknown>) => { try { await fn(); log.push(`OK   ${name}`); } catch (e: any) { failed = true; log.push(`FALHA ${name}: ${e?.message ?? e}`); } };
  const must = async (code: string, msg: string) => { for (let i = 0; i < 30; i++) { if (await js<boolean>(code)) return; await sleep(150); } throw new Error(msg); };

  await step('tela inicial', async () => { await must(`__h.txt().includes('Criar novo documento')`, 'sem botão'); await shot('01-inicio'); });
  await step('novo documento: tipo, destinatário/cargo com busca, identificação, 2 assinaturas', async () => {
    await js(`__h.btn('Criar novo documento').click()`); await must(`!!__h.lab('Destinatário')`, 'sem formulário');
    await js(`(()=>{const o=__h.lab('Escolha o tipo de documento'); window.__types=[...o.options].map(x=>x.text).join('|');})()`);
    const types = await js<string>('window.__types'); if (!types.includes('Relatório de Denúncia') || !types.includes('Relatório Social') || !types.includes('Ofício')) throw new Error('tipos: ' + types);
    // destinatário: digitar filtra a lista; clicar escolhe
    await js(`__h.set(__h.lab('Destinatário'),'CREAS')`); await must(`!!document.querySelector('.combo-list li')`, 'lista de órgãos não abriu');
    await js(`document.querySelector('.combo-list li').dispatchEvent(new MouseEvent('mousedown',{bubbles:true}))`);
    if (!(await js<string>(`__h.lab('Destinatário').value`)).startsWith('CREAS')) throw new Error('órgão não selecionado');
    await js(`__h.set(__h.lab('Cargo do destinatário'),'promotor')`); await must(`!!document.querySelector('.combo-list li')`, 'lista de cargos não abriu');
    await js(`document.querySelector('.combo-list li').dispatchEvent(new MouseEvent('mousedown',{bubbles:true}))`);
    await js(`__h.set(__h.lab('Assunto'),'Solicitação de informações — ação'); __h.set(__h.lab('Corpo do texto'),'Prezado senhor,\\n\\nSolicitamos informações, com acentuação: coração, órgão.')`);
    await js(`[...document.querySelectorAll('button')].filter(b=>b.textContent.includes('Não informado')).forEach(b=>b.click())`);
    await js(`(()=>{const s=__h.lab('Quem vai assinar?'); __h.set(s, s.options[1].value);})()`);
    await js(`__h.btn('Adicionar assinatura').click()`); await must(`!!__h.lab('2ª assinatura')`, 'segunda assinatura não apareceu');
    await js(`(()=>{const s=__h.lab('2ª assinatura'); __h.set(s, s.options[1].value);})()`);
    await must(`(()=>{const d=document.querySelector('iframe.preview').srcdoc; return d.includes('Solicitação de informações') && d.includes('Sr(a) Promotor(a) de Justiça') && d.includes('Identificação') && d.includes('Não informado') && d.includes('Maria Exemplo') && d.includes('João Exemplo');})()`, 'prévia incompleta'); await shot('02-novo-documento');
  });
  await step('emitir ofício', async () => {
    await js(`__h.btn('Emitir documento').click()`); await must(`__h.txt().includes('Emitir documento?')`, 'sem confirmação'); await shot('03-confirmar');
    await js(`[...document.querySelectorAll('.modal button')].find(b=>b.textContent.trim()==='Emitir').click()`);
    await must(`__h.txt().includes('Documento emitido')`, 'não emitiu'); await shot('04-emitido');
    if (!(await js<string>('__h.txt()')).includes('001/2026')) throw new Error('número esperado 001/2026');
  });
  await step('relatório de denúncia: sem número, título próprio', async () => {
    await js(`[...document.querySelectorAll('button')].find(b=>b.textContent.includes('Novo documento')&&b.className.includes('primary')).click()`);
    await must(`!!__h.lab('Escolha o tipo de documento')`, 'sem formulário');
    await js(`(()=>{const o=__h.lab('Escolha o tipo de documento'); __h.set(o,[...o.options].find(x=>x.text.includes('Relatório de Denúncia')).value);})()`);
    await must(`__h.txt().includes('Este tipo não tem número')`, 'aviso de sem número ausente');
    if (await js<boolean>(`!!__h.lab('Destinatário')`)) throw new Error('relatório não deveria ter destinatário');
    await js(`__h.set(__h.lab('Assunto'),'Denúncia recebida'); __h.set(__h.lab('Relato da denúncia'),'Relato de teste.'); [...document.querySelectorAll('button')].filter(b=>b.textContent.includes('Não informado')).forEach(b=>b.click()); (()=>{const s=__h.lab('Quem vai assinar?'); __h.set(s, s.options[1].value);})()`);
    await must(`document.querySelector('iframe.preview').srcdoc.includes('Relatório de Denúncia')`, 'título ausente na prévia'); await shot('04b-relatorio');
    await js(`__h.btn('Emitir documento').click()`); await must(`__h.txt().includes('Emitir documento?')`, 'sem confirmação');
    await js(`[...document.querySelectorAll('.modal button')].find(b=>b.textContent.trim()==='Emitir').click()`);
    await must(`__h.txt().includes('Documento emitido')`, 'não emitiu'); { const t = await js<string>('__h.txt()'); const i = t.indexOf('Relatório de Denúncia nº'); if (i >= 0) throw new Error('relatório não deveria ter número: ...' + t.slice(Math.max(0, i - 60), i + 40).replace(/\n/g, ' ')); await shot('04c-relatorio-emitido'); }
  });
  await step('histórico: ao selecionar, aparece a prévia (sem baixar)', async () => {
    await js(`[...document.querySelectorAll('.nav-btn')].find(b=>b.textContent.includes('Histórico')).click()`);
    await must(`document.querySelectorAll('tr.click').length>=2`, 'documentos não aparecem');
    await js(`[...document.querySelectorAll('tr.click')].find(r=>r.textContent.includes('001/2026')).click()`);
    await must(`(()=>{const f=document.querySelector('.modal iframe.preview'); return !!f && f.srcdoc.includes('Solicitação de informações') && f.srcdoc.includes('Identificação');})()`, 'prévia não apareceu no histórico'); await sleep(600); await shot('05-historico-previa');
    await js(`document.querySelector('.modal-h button').click()`);
  });
  await step('cadastro de responsável pede modo administrador', async () => {
    await js(`[...document.querySelectorAll('.nav-btn')].find(b=>b.textContent.includes('Responsáveis')).click()`);
    await must(`!!__h.btn('Novo responsável')`, 'sem página'); await js(`__h.btn('Novo responsável').click()`);
    await must(`!!__h.lab('Nome completo')`, 'sem modal');
    await js(`__h.set(__h.lab('Nome completo'),'Pessoa Nova Exemplo'); __h.set(__h.lab('Cargo ou função'),'Analista (exemplo)'); [...document.querySelectorAll('.modal button')].find(b=>b.textContent.trim()==='Salvar').click()`);
    await must(`__h.txt().includes('Criar senha de administrador')`, 'não pediu senha'); await shot('06-senha-admin');
    await js(`__h.set(__h.lab('Nova senha'),'senha-de-teste-1'); __h.set(__h.lab('Repita a senha'),'senha-de-teste-1'); [...document.querySelectorAll('.modal button')].find(b=>b.textContent.trim()==='Criar senha').click()`);
    await must(`__h.txt().includes('Pessoa Nova Exemplo')`, 'responsável não foi criado após desbloqueio'); await shot('07-responsaveis');
  });
  await step('configurações', async () => { await js(`[...document.querySelectorAll('.nav-btn')].find(b=>b.textContent.includes('Configurações')).click()`); await must(`__h.txt().includes('Nome do órgão')`, 'sem configurações'); await shot('08-configuracoes'); });
  await step('API recusa canal desconhecido', async () => { const r = await js<any>(`window.api.call('fs:read',{path:'/etc/passwd'})`); if (r.ok) throw new Error('canal indevido aceito'); });
  await step('sem acesso a Node na interface', async () => { if (await js<boolean>(`typeof require!=='undefined'||typeof process!=='undefined'`)) throw new Error('Node exposto'); });
  fs.writeFileSync(path.join(out, 'resultado.txt'), log.join('\n'));
  app.exit(failed ? 1 : 0);
});
