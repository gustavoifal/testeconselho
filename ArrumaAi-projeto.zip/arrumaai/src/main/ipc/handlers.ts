import { BrowserWindow, dialog, ipcMain, IpcMainInvokeEvent, shell } from 'electron';
import * as path from 'node:path';
import { AppCore } from '../context';
import { CHANNELS } from '../../shared/channels';
import { AppError, DocumentInput, SearchFilters } from '../../shared/types';
import { LOGO_MAX_BYTES, SIGNATURE_MAX_BYTES } from '../services/assets';
import { electronPdf } from '../docs/electronPdf';
import { exportDocument, Format, previewHtml, suggestFileName } from '../docs/export';
import { buildStatsCsv, buildStatsHtml } from '../docs/statsReport';
import { writeFileAtomic } from '../db/database';

const str = (v: unknown, name = 'valor'): string => { if (typeof v !== 'string') throw new AppError('VALIDATION', `Campo inválido: ${name}.`); return v; };
const num = (v: unknown, name = 'valor'): number => { if (typeof v !== 'number' || !Number.isFinite(v)) throw new AppError('VALIDATION', `Campo inválido: ${name}.`); return v; };
const bool = (v: unknown): boolean => v === true;

export function registerIpc(core: AppCore, getWin: () => BrowserWindow | null, appPaths: { backupAuto: string; backupSafety: string }, isTrustedUrl: (url: string) => boolean, hooks: { setDirty?: (dirty: boolean) => void } = {}) {
  const approvedDirs = new Set<string>();
  const last = core.getPref('lastExportDir'); if (last) approvedDirs.add(last);
  const handlers = new Map<string, (a: any, e: IpcMainInvokeEvent) => unknown>();
  const on = (ch: (typeof CHANNELS)[number], fn: (a: any, e: IpcMainInvokeEvent) => unknown) => handlers.set(ch, fn);
  const imageFilter = [{ name: 'Imagens PNG ou JPG', extensions: ['png', 'jpg', 'jpeg'] }];
  const win = () => getWin() ?? undefined;
  const sid = (a: any) => str(a.serviceId, 'serviço');

  on('app:bootstrap', () => ({ hasPassword: core.auth.hasPassword(), isAdmin: core.auth.isAdmin(), userName: core.getPref('userName') ?? '', lastExportDir: core.getPref('lastExportDir'), services: core.registry.listServices() }));
  on('pref:setUserName', (a) => { core.setPref('userName', str(a.name)); return true; });

  on('auth:status', () => ({ hasPassword: core.auth.hasPassword(), isAdmin: core.auth.isAdmin() }));
  on('auth:setPassword', (a) => { core.auth.setPassword(str(a.password, 'senha'), a.current === undefined ? undefined : str(a.current)); core.audit.log(null, 'admin.senha_definida', 'auth', null); return { isAdmin: core.auth.isAdmin() }; });
  on('auth:unlock', (a) => { core.auth.unlock(str(a.password, 'senha')); core.audit.log(null, 'admin.desbloqueado', 'auth', null); return { isAdmin: true }; });
  on('auth:lock', () => { core.auth.lock(); return { isAdmin: false }; });

  on('service:list', () => core.registry.listServices());
  on('service:create', (a) => core.registry.createService({ id: str(a.id), name: str(a.name), orgName: str(a.orgName), city: a.city === undefined ? undefined : str(a.city) }));

  on('inst:get', (a) => ({ institution: core.registry.getInstitution(sid(a)), hasLogo: !!core.registry.getInstitution(sid(a)).logoHash }));
  on('inst:update', (a) => core.registry.updateInstitution(sid(a), a.patch ?? {}));
  on('inst:pickLogo', async (a) => {
    core.auth.requireAdmin();
    const r = await dialog.showOpenDialog(win()!, { title: 'Escolher logomarca', properties: ['openFile'], filters: imageFilter });
    if (r.canceled || !r.filePaths[0]) return null;
    return core.registry.setLogo(sid(a), (s) => s.storeFromFile(r.filePaths[0], LOGO_MAX_BYTES));
  });
  on('inst:removeLogo', (a) => core.registry.setLogoBytes(sid(a), null));

  on('tpl:list', (a) => core.registry.listTemplates(sid(a)));
  on('tpl:update', (a) => core.registry.updateTemplate(sid(a), str(a.templateId), a.patch ?? {}));
  on('rule:get', (a) => core.registry.getRule(sid(a), str(a.category)));
  on('rule:update', (a) => core.registry.updateRule(sid(a), str(a.category), a.patch ?? {}));
  on('num:setNext', (a) => { core.numbering.setNext(sid(a), str(a.category), num(a.year), num(a.next)); return true; });
  on('num:sequence', (a) => core.numbering.sequence(sid(a), str(a.category), a.year === undefined ? undefined : num(a.year)));
  on('num:peek', (a) => core.numbering.peekNext(sid(a), str(a.category), str(a.issueDate)));

  on('signer:list', (a) => core.signers.list(sid(a), bool(a.includeHidden)));
  on('signer:selectable', (a) => core.signers.listSelectable(sid(a), str(a.templateId)));
  on('signer:create', (a) => core.signers.create({ serviceId: sid(a), fullName: str(a.fullName), roleTitle: str(a.roleTitle), templateIds: Array.isArray(a.templateIds) ? a.templateIds.map((x: unknown) => str(x)) : undefined }));
  on('signer:update', (a) => core.signers.update(sid(a), num(a.id), { fullName: a.fullName === undefined ? undefined : str(a.fullName), roleTitle: a.roleTitle === undefined ? undefined : str(a.roleTitle) }));
  on('signer:setActive', (a) => core.signers.setActive(sid(a), num(a.id), bool(a.active)));
  on('signer:setHidden', (a) => core.signers.setHidden(sid(a), num(a.id), bool(a.hidden)));
  on('signer:setTemplates', (a) => core.signers.setAuthorizedTemplates(sid(a), num(a.id), (Array.isArray(a.templateIds) ? a.templateIds : []).map((x: unknown) => str(x))));
  on('signer:pickImage', async (a) => {
    core.auth.requireAdmin();
    const r = await dialog.showOpenDialog(win()!, { title: 'Escolher imagem de assinatura autorizada', properties: ['openFile'], filters: imageFilter });
    if (r.canceled || !r.filePaths[0]) return null;
    return core.signers.setSignatureImage(sid(a), num(a.id), (s) => s.storeFromFile(r.filePaths[0], SIGNATURE_MAX_BYTES));
  });
  on('signer:removeImage', (a) => core.signers.setSignatureImageBytes(sid(a), num(a.id), null));

  const docInput = (a: any): DocumentInput => a.input as DocumentInput;
  on('doc:previewHtml', (a) => previewHtml(core.documents.preview(docInput(a)), core.assets));
  on('doc:saveDraft', (a) => core.documents.saveDraft(docInput(a), a.draftId === undefined ? undefined : num(a.draftId)));
  on('doc:deleteDraft', (a) => { core.documents.deleteDraft(sid(a), num(a.id)); return true; });
  on('doc:issue', (a) => core.documents.issue(docInput(a), a.draftId === undefined ? undefined : num(a.draftId)));
  on('doc:cancel', (a) => core.documents.cancel(sid(a), num(a.id), str(a.reason)));
  on('doc:get', (a) => core.documents.get(sid(a), num(a.id)));
  on('doc:search', (a) => core.documents.search(sid(a), (a.filters ?? {}) as SearchFilters));
  on('doc:stats', (a) => core.documents.stats(sid(a)));
  on('doc:recentIdentifications', (a) => core.documents.recentIdentifications(sid(a)));
  on('stats:report', (a) => core.documents.report(sid(a), str(a.from, 'data inicial'), str(a.to, 'data final')));
  on('stats:export', async (a) => {
    const rep = core.documents.report(sid(a), str(a.from, 'data inicial'), str(a.to, 'data final'));
    const inst = core.registry.snapshot(sid(a)); const fmt = a.format === 'csv' ? 'csv' : 'pdf';
    const r = await dialog.showSaveDialog(win()!, { title: 'Salvar relatório estatístico', defaultPath: `Relatorio-estatistico-${rep.from}-a-${rep.to}.${fmt}`, filters: fmt === 'csv' ? [{ name: 'Planilha (CSV)', extensions: ['csv'] }] : [{ name: 'PDF', extensions: ['pdf'] }] });
    if (r.canceled || !r.filePath) return null;
    try {
      writeFileAtomic(r.filePath, fmt === 'csv' ? Buffer.from(buildStatsCsv(rep, inst.orgName), 'utf8') : await electronPdf(buildStatsHtml(rep, inst), '<div style="width:100%;font-size:8px;text-align:center;font-family:Arial">Página <span class="pageNumber"></span> de <span class="totalPages"></span></div>'));
    } catch (e) { if (e instanceof AppError) throw e; throw new AppError('EXPORT_FAILED', 'Não foi possível salvar o arquivo. Verifique a pasta escolhida e se o arquivo não está aberto em outro programa.'); }
    core.audit.log(sid(a), 'relatorio.estatistico_exportado', 'report', fmt, { de: rep.from, ate: rep.to });
    return r.filePath;
  });
  on('doc:renderHtml', (a) => previewHtml(core.documents.get(sid(a), num(a.id)), core.assets));
  on('doc:suggestName', (a) => suggestFileName(core.documents.get(sid(a), num(a.id))));
  on('dialog:chooseExportDir', async () => {
    const r = await dialog.showOpenDialog(win()!, { title: 'Escolher a pasta de destino', properties: ['openDirectory', 'createDirectory'] });
    if (r.canceled || !r.filePaths[0]) return null;
    approvedDirs.add(r.filePaths[0]); core.setPref('lastExportDir', r.filePaths[0]);
    return r.filePaths[0];
  });
  on('doc:export', async (a) => {
    const dir = str(a.dir, 'pasta');
    if (!approvedDirs.has(dir)) throw new AppError('VALIDATION', 'Escolha a pasta de destino pelo botão "Escolher pasta".');
    const formats = (Array.isArray(a.formats) ? a.formats : []).filter((f: unknown): f is Format => f === 'docx' || f === 'pdf');
    const rec = core.documents.get(sid(a), num(a.id));
    const paths = await exportDocument(rec, core.assets, { dir, baseName: str(a.baseName, 'nome'), formats, overwrite: bool(a.overwrite) }, electronPdf);
    return core.documents.setExportPaths(sid(a), rec.id, paths);
  });
  on('doc:showFile', (a) => {
    const rec = core.documents.get(sid(a), num(a.id));
    const p = a.kind === 'pdf' ? rec.pdfPath : rec.docxPath;
    if (!p) throw new AppError('NOT_FOUND', 'Este documento ainda não foi exportado nesse formato.');
    shell.showItemInFolder(path.resolve(p));
    return true;
  });

  on('backup:create', async (a) => {
    core.auth.requireAdmin();
    const r = await dialog.showOpenDialog(win()!, { title: 'Escolher a pasta do backup', properties: ['openDirectory', 'createDirectory'] });
    if (r.canceled || !r.filePaths[0]) return null;
    return core.backup.create(r.filePaths[0], a.password ? str(a.password) : undefined);
  });
  on('backup:restore', async (a) => {
    core.auth.requireAdmin();
    const r = await dialog.showOpenDialog(win()!, { title: 'Escolher o arquivo de backup', properties: ['openFile'], filters: [{ name: 'Backup do ArrumaAí', extensions: ['arrumaai-bkp'] }] });
    if (r.canceled || !r.filePaths[0]) return null;
    core.backup.restore(r.filePaths[0], appPaths.backupSafety, a.password ? str(a.password) : undefined);
    return true;
  });
  const kind = (a: any) => { const k = str(a.kind, 'tipo'); if (k !== 'orgao' && k !== 'cargo') throw new AppError('VALIDATION', 'Tipo de lista inválido.'); return k; };
  on('opt:list', (a) => core.registry.listOptions(sid(a), kind(a)));
  on('opt:add', (a) => core.registry.addOption(sid(a), kind(a), str(a.label, 'texto')));
  on('opt:remove', (a) => { core.registry.removeOption(sid(a), num(a.id)); return true; });
  on('opt:restoreDefaults', (a) => core.registry.restoreDefaultOptions(sid(a), kind(a)));
  on('app:setDirty', (a) => { hooks.setDirty?.(bool(a.dirty)); return true; });
  on('audit:list', (a) => { core.auth.requireAdmin(); return core.audit.list(a.serviceId ? sid(a) : null, 200); });

  for (const ch of CHANNELS) {
    const fn = handlers.get(ch);
    if (!fn) throw new Error(`Canal sem implementação: ${ch}`);
    ipcMain.handle(ch, async (e, args) => {
      try {
        if (!e.senderFrame || !isTrustedUrl(e.senderFrame.url)) throw new AppError('FORBIDDEN', 'Origem não autorizada.');
        return { ok: true, data: await fn(args && typeof args === 'object' ? args : {}, e) };
      } catch (err) {
        if (err instanceof AppError) return { ok: false, error: { code: err.code, message: err.message, fields: err.fields } };
        console.error('Erro interno:', err);
        return { ok: false, error: { code: 'INTERNAL', message: 'Ocorreu um erro inesperado. Tente novamente.' } };
      }
    });
  }
}
