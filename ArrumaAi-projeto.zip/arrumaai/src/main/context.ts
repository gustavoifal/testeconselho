import { Db, DbOptions } from './db/database';
import { migrate } from './db/migrations';
import { Auth } from './services/auth';
import { Audit } from './services/audit';
import { AssetStore } from './services/assets';
import { Registry } from './services/registry';
import { SignerService } from './services/signers';
import { NumberingService } from './services/numbering';
import { DocumentService } from './services/documents';
import { BackupService } from './services/backup';
import { seedDemo } from './services/seed';
import { clean } from './services/util';

export interface CoreOptions extends DbOptions { dbFile: string | null; now?: () => Date; seedDemo?: boolean }

/** Reúne todos os serviços de negócio (sem depender de Electron, para poder ser testado). */
export class AppCore {
  private constructor(
    readonly db: Db, readonly auth: Auth, readonly audit: Audit, readonly assets: AssetStore, readonly registry: Registry,
    readonly signers: SignerService, readonly numbering: NumberingService, readonly documents: DocumentService, readonly backup: BackupService,
  ) {}

  static async create(opts: CoreOptions): Promise<AppCore> {
    const now = opts.now ?? (() => new Date());
    const db = await Db.open(opts.dbFile, { writeFile: opts.writeFile });
    migrate(db);
    const auth = new Auth(db, now);
    const audit = new Audit(db, auth, now);
    const assets = new AssetStore(db, now);
    const deps = { db, auth, audit, assets, now };
    const registry = new Registry(deps);
    const signers = new SignerService(deps);
    const numbering = new NumberingService(deps, registry);
    const documents = new DocumentService(deps, registry, numbering, signers);
    const backup = new BackupService(db, auth, audit, now);
    const core = new AppCore(db, auth, audit, assets, registry, signers, numbering, documents, backup);
    if (opts.seedDemo !== false) {
      seedDemo(db, registry, (sid, name, role) => {
        const ts = now().toISOString();
        const { lastId } = db.run('INSERT INTO signers(service_id, full_name, role_title, created_at, updated_at) VALUES (?,?,?,?,?)', [sid, name, role, ts, ts]);
        db.run('INSERT INTO template_signers(template_id, signer_id) SELECT id, ? FROM templates WHERE service_id = ?', [lastId, sid]);
      });
    }
    return core;
  }

  getPref(key: string): string | null { return this.db.get<{ value: string }>('SELECT value FROM app_prefs WHERE key = ?', [key])?.value ?? null; }
  setPref(key: 'userName' | 'lastExportDir', value: string): void {
    this.db.run('INSERT INTO app_prefs(key, value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value = excluded.value', [key, clean(value, 500)]);
  }
}
