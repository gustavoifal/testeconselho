import { ReactNode, useEffect, useId, useRef, useState } from 'react';
import type { ServiceInfo } from '../shared/types';
import { ApiError } from './api';

export interface Ctx {
  service: ServiceInfo; services: ServiceInfo[]; isAdmin: boolean; userName: string;
  run: <T>(fn: () => Promise<T>, okMsg?: string, onFields?: (e: ApiError) => void) => Promise<T | undefined>;
  toast: (msg: string, kind?: 'ok' | 'erro') => void;
  confirm: (title: string, text: string, okLabel?: string) => Promise<boolean>;
  refreshBoot: () => Promise<void>; selectService: (id: string) => void;
  go: (page: Page, arg?: any) => void; lockAdmin: () => Promise<void>; askUnlock: () => Promise<boolean>;
}
export type Page = 'inicio' | 'novo' | 'historico' | 'responsaveis' | 'configuracoes';

export function Logo({ size = 28 }: { size?: number }) {
  return (<svg width={size} height={size} viewBox="0 0 32 32" aria-hidden="true"><rect x="5" y="2" width="20" height="26" rx="3" fill="#fff" /><path d="M10 10h10M10 15h10M10 20h6" stroke="#1d6fb8" strokeWidth="2" strokeLinecap="round" /><circle cx="24" cy="23" r="7" fill="#2fa36b" /><path d="m20.8 23 2.2 2.2 4-4.2" stroke="#fff" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg>);
}

export function Field({ label, error, hint, children }: { label: string; error?: string; hint?: string; children: (id: string, invalid: boolean) => ReactNode }) {
  const id = useId();
  return (<div className="field"><label htmlFor={id}>{label}</label>{children(id, !!error)}{hint && !error && <div className="hint">{hint}</div>}{error && <div className="err" role="alert">{error}</div>}</div>);
}

export function Modal({ title, onClose, children, wide }: { title: string; onClose: () => void; children: ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null;
    ref.current?.querySelector<HTMLElement>('input,textarea,select,button')?.focus();
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', onKey);
    return () => { document.removeEventListener('keydown', onKey); prev?.focus(); };
  }, []);
  return (<div className="overlay" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
    <div className={`modal${wide ? ' wide' : ''}`} role="dialog" aria-modal="true" aria-label={title} ref={ref}>
      <div className="modal-h"><h2>{title}</h2><button className="btn ghost" onClick={onClose} aria-label="Fechar">✕</button></div>{children}</div></div>);
}

export function Badge({ status }: { status: string }) {
  const label = status === 'emitido' ? 'Emitido' : status === 'cancelado' ? 'Cancelado' : 'Em edição';
  return <span className={`badge ${status}`}>{label}</span>;
}

export function Loading({ text = 'Carregando…' }: { text?: string }) { return <div className="loading" role="status"><span className="spin" />{text}</div>; }
export function Empty({ title, text, action }: { title: string; text?: string; action?: ReactNode }) { return <div className="empty"><h3>{title}</h3>{text && <p>{text}</p>}{action}</div>; }

export function useFieldErrors() {
  const [errs, setErrs] = useState<Record<string, string>>({});
  return {
    errs, clear: () => setErrs({}),
    capture: (e: unknown) => {
      if (e instanceof ApiError && e.fields?.length) { const m: Record<string, string> = {}; for (const f of e.fields) m[f.field] ??= f.message; setErrs(m); return true; }
      return false;
    },
  };
}

export const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
export const fmtDate = (iso: string | null) => (iso ? iso.slice(0, 10).split('-').reverse().join('/') : '—');
export const fmtDateTime = (iso: string | null) => (iso ? new Date(iso).toLocaleString('pt-BR') : '—');
