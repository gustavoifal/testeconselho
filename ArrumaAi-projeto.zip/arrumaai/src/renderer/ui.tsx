import { ReactNode, useEffect, useId, useRef, useState } from 'react';
import type { ServiceInfo } from '../shared/types';
import { ApiError } from './api';

export interface Ctx {
  service: ServiceInfo; services: ServiceInfo[]; isAdmin: boolean; userName: string;
  run: <T>(fn: () => Promise<T>, okMsg?: string, onFields?: (e: ApiError) => void) => Promise<T | undefined>;
  toast: (msg: string, kind?: 'ok' | 'erro') => void;
  confirm: (title: string, text: string, okLabel?: string) => Promise<boolean>;
  refreshBoot: () => Promise<void>; selectService: (id: string) => void;
  go: (page: Page, arg?: any) => void; lockAdmin: () => Promise<void>; askUnlock: () => Promise<boolean>;
}
export type Page = 'inicio' | 'novo' | 'historico' | 'estatisticas' | 'responsaveis' | 'configuracoes';

export function Logo({ size = 28 }: { size?: number }) {
  return (<svg width={size} height={size} viewBox="0 0 32 32" aria-hidden="true"><rect x="5" y="2" width="20" height="26" rx="3" fill="#fff" /><path d="M10 10h10M10 15h10M10 20h6" stroke="#1d6fb8" strokeWidth="2" strokeLinecap="round" /><circle cx="24" cy="23" r="7" fill="#2fa36b" /><path d="m20.8 23 2.2 2.2 4-4.2" stroke="#fff" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg>);
}

export function Field({ label, error, hint, children }: { label: string; error?: string; hint?: string; children: (id: string, invalid: boolean) => ReactNode }) {
  const id = useId();
  return (<div className="field"><label htmlFor={id}>{label}</label>{children(id, !!error)}{hint && !error && <div className="hint">{hint}</div>}{error && <div className="err" role="alert">{error}</div>}</div>);
}

export function Modal({ title, onClose, children, wide }: { title: string; onClose: () => void; children: ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null;
    ref.current?.querySelector<HTMLElement>('input,textarea,select,button')?.focus();
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', onKey);
    return () => { document.removeEventListener('keydown', onKey); prev?.focus(); };
  }, []);
  return (<div className="overlay" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
    <div className={`modal${wide ? ' wide' : ''}`} role="dialog" aria-modal="true" aria-label={title} ref={ref}>
      <div className="modal-h"><h2>{title}</h2><button className="btn ghost" onClick={onClose} aria-label="Fechar">✕</button></div>{children}</div></div>);
}

export function Badge({ status }: { status: string }) {
  const label = status === 'emitido' ? 'Emitido' : status === 'cancelado' ? 'Cancelado' : 'Em edição';
  return <span className={`badge ${status}`}>{label}</span>;
}

export function Loading({ text = 'Carregando…' }: { text?: string }) { return <div className="loading" role="status"><span className="spin" />{text}</div>; }
export function Empty({ title, text, action }: { title: string; text?: string; action?: ReactNode }) { return <div className="empty"><h3>{title}</h3>{text && <p>{text}</p>}{action}</div>; }

export function useFieldErrors() {
  const [errs, setErrs] = useState<Record<string, string>>({});
  return {
    errs, clear: () => setErrs({}),
    capture: (e: unknown) => {
      if (e instanceof ApiError && e.fields?.length) { const m: Record<string, string> = {}; for (const f of e.fields) m[f.field] ??= f.message; setErrs(m); return true; }
      return false;
    },
  };
}

export const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
export const fmtDate = (iso: string | null) => (iso ? iso.slice(0, 10).split('-').reverse().join('/') : '—');
export const fmtDateTime = (iso: string | null) => (iso ? new Date(iso).toLocaleString('pt-BR') : '—');

const norm = (s: string) => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

/** Campo com lista de opções: dá para digitar (a lista filtra enquanto digita) ou escolher; texto livre continua permitido. */
export function Combo({ id, value, onChange, options, placeholder, invalid, maxLength = 200 }: {
  id: string; value: string; onChange: (v: string) => void; options: string[]; placeholder?: string; invalid?: boolean; maxLength?: number;
}) {
  const [open, setOpen] = useState(false); const [all, setAll] = useState(false); const [hi, setHi] = useState(-1);
  const q = norm(value.trim());
  const shown = (all || !q ? options : options.filter((o) => norm(o).includes(q))).slice(0, 80);
  const pick = (v: string) => { onChange(v); setOpen(false); setAll(false); setHi(-1); };
  const listId = `${id}-list`;
  return (<div className="combo">
    <input id={id} type="text" role="combobox" aria-expanded={open} aria-controls={listId} aria-autocomplete="list" aria-invalid={invalid} autoComplete="off"
      value={value} maxLength={maxLength} placeholder={placeholder}
      onChange={(e) => { onChange(e.target.value); setOpen(true); setAll(false); setHi(-1); }}
      onFocus={() => setOpen(true)} onBlur={() => { setOpen(false); setAll(false); }}
      onKeyDown={(e) => {
        if (e.key === 'ArrowDown') { e.preventDefault(); setOpen(true); setHi((h) => Math.min(h + 1, shown.length - 1)); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); setHi((h) => Math.max(h - 1, 0)); }
        else if (e.key === 'Enter' && open && hi >= 0 && shown[hi]) { e.preventDefault(); pick(shown[hi]); }
        else if (e.key === 'Escape' && open) { e.stopPropagation(); setOpen(false); }
      }} />
    <button type="button" className="combo-btn" tabIndex={-1} aria-label="Mostrar todas as opções" onMouseDown={(e) => { e.preventDefault(); setOpen((o) => !o); setAll(true); }}>▾</button>
    {open && shown.length > 0 && (<ul className="combo-list" id={listId} role="listbox">{shown.map((o, i) => (
      <li key={o} role="option" aria-selected={i === hi} className={i === hi ? 'hi' : ''} onMouseDown={(e) => { e.preventDefault(); pick(o); }}>{o}</li>))}</ul>)}
  </div>);
}
