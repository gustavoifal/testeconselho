import { useCallback, useEffect, useRef, useState } from 'react';
import type { ServiceInfo } from '../shared/types';
import { ApiError, call } from './api';
import { Ctx, Field, Loading, Logo, Modal, Page } from './ui';
import { Home } from './pages/Home';
import { NewDoc } from './pages/NewDoc';
import { History } from './pages/History';
import { Signers } from './pages/Signers';
import { Settings } from './pages/Settings';
import { Stats } from './pages/Stats';

interface Boot { hasPassword: boolean; isAdmin: boolean; userName: string; services: ServiceInfo[] }
const NAV: { id: Page; label: string; icon: string }[] = [
  { id: 'inicio', label: 'Início', icon: '⌂' }, { id: 'novo', label: 'Novo documento', icon: '＋' }, { id: 'historico', label: 'Histórico', icon: '☰' }, { id: 'estatisticas', label: 'Estatísticas', icon: '▥' },
  { id: 'responsaveis', label: 'Responsáveis e Assinaturas', icon: '✎' }, { id: 'configuracoes', label: 'Configurações', icon: '⚙' },
];

function UnlockModal({ hasPassword, onDone }: { hasPassword: boolean; onDone: (ok: boolean) => void }) {
  const [pw, setPw] = useState(''); const [pw2, setPw2] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const submit = async () => {
    setErr('');
    if (!hasPassword && pw !== pw2) { setErr('As senhas não coincidem.'); return; }
    setBusy(true);
    try { await call(hasPassword ? 'auth:unlock' : 'auth:setPassword', { password: pw }); onDone(true); }
    catch (e) { setErr(e instanceof ApiError ? e.message : 'Erro inesperado.'); setBusy(false); }
  };
  return (<Modal title={hasPassword ? 'Modo administrador' : 'Criar senha de administrador'} onClose={() => onDone(false)}>
    <div className="notice info">{hasPassword ? 'Esta ação altera configurações e exige a senha de administrador.' : 'Antes de configurar o aplicativo, crie uma senha de administrador (mínimo de 8 caracteres). Guarde-a bem: ela não pode ser recuperada.'}</div>
    <form onSubmit={(e) => { e.preventDefault(); void submit(); }}>
      <Field label={hasPassword ? 'Senha de administrador' : 'Nova senha'} error={err}>{(id, bad) => <input id={id} type="password" value={pw} aria-invalid={bad} onChange={(e) => setPw(e.target.value)} autoComplete="off" />}</Field>
      {!hasPassword && <Field label="Repita a senha">{(id) => <input id={id} type="password" value={pw2} onChange={(e) => setPw2(e.target.value)} autoComplete="off" />}</Field>}
      <div className="row end"><button type="button" className="btn" onClick={() => onDone(false)}>Cancelar</button><button className="btn primary" disabled={busy || !pw}>{hasPassword ? 'Desbloquear' : 'Criar senha'}</button></div>
    </form></Modal>);
}

export function App() {
  const [boot, setBoot] = useState<Boot | null>(null);
  const [bootErr, setBootErr] = useState('');
  const [serviceId, setServiceId] = useState<string>(() => localStorage.getItem('serviceId') ?? '');
  const [page, setPage] = useState<Page>('inicio'); const [pageArg, setPageArg] = useState<any>();
  const [toasts, setToasts] = useState<{ id: number; msg: string; kind: string }[]>([]);
  const [dlg, setDlg] = useState<{ title: string; text: string; okLabel: string; resolve: (v: boolean) => void } | null>(null);
  const [unlock, setUnlock] = useState<{ resolve: (v: boolean) => void } | null>(null);
  const tid = useRef(0);

  const refreshBoot = useCallback(async () => {
    try { const b = await call<Boot>('app:bootstrap'); setBoot(b); setServiceId((cur) => (b.services.some((s) => s.id === cur) ? cur : b.services[0]?.id ?? '')); }
    catch (e) { setBootErr(e instanceof ApiError ? e.message : 'Não foi possível iniciar o aplicativo.'); }
  }, []);
  useEffect(() => { void refreshBoot(); }, [refreshBoot]);
  useEffect(() => { if (serviceId) localStorage.setItem('serviceId', serviceId); }, [serviceId]);

  const toast = useCallback((msg: string, kind: 'ok' | 'erro' = 'ok') => {
    const id = ++tid.current; setToasts((t) => [...t, { id, msg, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), kind === 'erro' ? 7000 : 3500);
  }, []);
  const askUnlock = useCallback(() => new Promise<boolean>((resolve) => setUnlock({ resolve: (ok) => { setUnlock(null); if (ok) void refreshBoot(); resolve(ok); } })), [refreshBoot]);
  const confirm = useCallback((title: string, text: string, okLabel = 'Confirmar') => new Promise<boolean>((resolve) => setDlg({ title, text, okLabel, resolve: (v) => { setDlg(null); resolve(v); } })), []);
  const run: Ctx['run'] = useCallback(async (fn, okMsg, onFields) => {
    for (let attempt = 0; attempt < 2; attempt++) {
      try { const r = await fn(); if (okMsg) toast(okMsg); return r; }
      catch (e) {
        if (e instanceof ApiError && e.code === 'ADMIN_REQUIRED' && attempt === 0) { if (await askUnlock()) continue; return undefined; }
        if (e instanceof ApiError) { if (e.fields?.length && onFields) onFields(e); toast(e.message, 'erro'); } else toast('Ocorreu um erro inesperado.', 'erro');
        return undefined;
      }
    }
    return undefined;
  }, [askUnlock, toast]);

  if (bootErr) return <div className="main"><div className="card"><h1>Não foi possível iniciar</h1><p>{bootErr}</p></div></div>;
  if (!boot) return <Loading text="Iniciando o ArrumaAí…" />;
  const service = boot.services.find((s) => s.id === serviceId) ?? boot.services[0];
  if (!service) return <div className="main"><div className="card"><h1>Nenhum serviço cadastrado</h1></div></div>;

  const ctx: Ctx = {
    service, services: boot.services, isAdmin: boot.isAdmin, userName: boot.userName, run, toast, confirm, refreshBoot, selectService: setServiceId, askUnlock,
    go: (p, arg) => { setPage(p); setPageArg(arg); },
    lockAdmin: async () => { await call('auth:lock'); await refreshBoot(); toast('Modo administrador bloqueado.'); },
  };
  const k = `${service.id}`;
  return (<div className="app">
    <aside className="side">
      <div className="brand"><Logo size={30} /> ArrumaAí</div>
      <nav aria-label="Navegação principal">{NAV.map((n) => (<button key={n.id} className="nav-btn" aria-current={page === n.id ? 'page' : undefined} onClick={() => ctx.go(n.id)}><span aria-hidden="true">{n.icon}</span>{n.label}</button>))}</nav>
      <div className="grow" />
      <div className="who">Serviço atual<br /><b style={{ color: '#fff' }}>{service.name}</b></div>
      {boot.isAdmin ? <div className="admin-pill">🔓 Administrador <button className="btn ghost" style={{ color: '#fff', padding: '2px 8px', minHeight: 0 }} onClick={() => void ctx.lockAdmin()}>Bloquear</button></div>
        : <button className="nav-btn" onClick={() => void askUnlock()}>🔒 Modo administrador</button>}
    </aside>
    <main className="main" id="conteudo">
      {page === 'inicio' && <Home key={k} ctx={ctx} />}
      {page === 'novo' && <NewDoc key={k + JSON.stringify(pageArg ?? {})} ctx={ctx} arg={pageArg} />}
      {page === 'historico' && <History key={k} ctx={ctx} />}
      {page === 'estatisticas' && <Stats key={k} ctx={ctx} />}
      {page === 'responsaveis' && <Signers key={k} ctx={ctx} />}
      {page === 'configuracoes' && <Settings key={k} ctx={ctx} />}
    </main>
    <div className="toasts" aria-live="polite">{toasts.map((t) => <div key={t.id} className={`toast ${t.kind}`}>{t.msg}</div>)}</div>
    {dlg && <Modal title={dlg.title} onClose={() => dlg.resolve(false)}><p>{dlg.text}</p><div className="row end"><button className="btn" onClick={() => dlg.resolve(false)}>Voltar</button><button className="btn primary" onClick={() => dlg.resolve(true)}>{dlg.okLabel}</button></div></Modal>}
    {unlock && <UnlockModal hasPassword={boot.hasPassword} onDone={unlock.resolve} />}
  </div>);
}
