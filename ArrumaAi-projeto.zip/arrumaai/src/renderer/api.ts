import type { Reply } from '../shared/channels';
import type { FieldError } from '../shared/types';

declare global { interface Window { api: { call: (channel: string, payload?: unknown) => Promise<Reply> } } }

export class ApiError extends Error {
  constructor(public code: string, message: string, public fields?: FieldError[]) { super(message); }
}

export async function call<T = any>(channel: string, payload?: unknown): Promise<T> {
  const r = await window.api.call(channel, payload);
  if (!r.ok) throw new ApiError(r.error.code, r.error.message, r.error.fields);
  return r.data as T;
}
