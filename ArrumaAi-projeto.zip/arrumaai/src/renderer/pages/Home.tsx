import { useEffect, useState } from 'react';
import type { Institution, Stats } from '../../shared/types';
import { call } from '../api';
import { Ctx, fmtDateTime, Loading, today } from '../ui';

export function Home({ ctx }: { ctx: Ctx }) {
  const [stats, setStats] = useState<Stats | null>(null);
  const [inst, setInst] = useState<Institution | null>(null);
  const [next, setNext] = useState('');
  const [name, setName] = useState('');
  const sid = ctx.service.id;
  useEffect(() => {
    void ctx.run(async () => {
      setStats(await call<Stats>('doc:stats', { serviceId: sid }));
      setInst((await call<{ institution: Institution }>('inst:get', { serviceId: sid })).institution);
      setNext((await call<{ label: string }>('num:peek', { serviceId: sid, category: 'oficio', issueDate: today() })).label);
    });
  }, [sid]);
  const greeting = ctx.userName ? `Olá, ${ctx.userName}!` : 'Bem-vindo ao ArrumaAí';
  return (<div className="page">
    <div className="top"><div><h1>{greeting}</h1><div className="sub">Gere ofícios padronizados em poucos passos: escolha o serviço, preencha e exporte para Word ou PDF.</div></div>
      <button className="btn primary" onClick={() => ctx.go('novo')}>＋ Criar novo documento</button></div>
    {!ctx.userName && <div className="card row"><label htmlFor="uname">Como devemos chamar você? (opcional)</label>
      <input id="uname" type="text" style={{ maxWidth: 240 }} value={name} onChange={(e) => setName(e.target.value)} maxLength={80} />
      <button className="btn" disabled={!name.trim()} onClick={() => void ctx.run(async () => { await call('pref:setUserName', { name }); await ctx.refreshBoot(); })}>Salvar</button></div>}
    <h2 style={{ marginBottom: 10 }}>Serviço</h2>
    <div className="grid g3" style={{ marginBottom: 18 }}>{ctx.services.map((s) => (
      <button key={s.id} className="svc" aria-pressed={s.id === sid} onClick={() => ctx.selectService(s.id)}>
        <span className="ic" aria-hidden="true">{s.name.charAt(0).toUpperCase()}</span>
        <span><b>{s.name}</b>{s.isDemo && <span className="tag">exemplo</span>}<br /><span className="sub">{s.orgName}</span></span></button>))}</div>
    {!stats || !inst ? <Loading /> : (<>
      <div className="grid g4" style={{ marginBottom: 16 }}>
        <div className="card stat">{stats.emitido}<small>Documentos emitidos</small></div>
        <div className="card stat">{stats.cancelado}<small>Cancelados</small></div>
        <div className="card stat">{stats.rascunho}<small>Em edição</small></div>
        <div className="card stat" style={{ fontSize: 22 }}>{next}<small>Próximo ofício (previsto)</small></div>
      </div>
      <div className="grid g2">
        <div className="card"><h3>Sobre este serviço</h3>
          <dl className="kv"><dt>Órgão</dt><dd>{inst.orgName}</dd><dt>Endereço</dt><dd>{inst.address || '—'}</dd><dt>Telefone</dt><dd>{inst.phone || '—'}</dd><dt>E-mail</dt><dd>{inst.email || '—'}</dd><dt>Último documento</dt><dd>{fmtDateTime(stats.lastIssued)}</dd></dl>
          {ctx.service.isDemo && <div className="notice" style={{ marginTop: 12 }}>Este é o serviço de <b>demonstração</b>, com dados fictícios. Em <b>Configurações</b> você ajusta os dados do seu órgão.</div>}</div>
        <div className="card"><h3>Atalhos</h3><div className="grid">
          <button className="btn" onClick={() => ctx.go('historico')}>☰ Abrir histórico de documentos</button>
          <button className="btn" onClick={() => ctx.go('responsaveis')}>✎ Responsáveis e assinaturas</button>
          <button className="btn" onClick={() => ctx.go('configuracoes')}>⚙ Configurações do órgão e backup</button></div></div>
      </div></>)}
  </div>);
}
