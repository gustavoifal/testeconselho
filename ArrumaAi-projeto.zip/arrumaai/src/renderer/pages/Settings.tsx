import { useEffect, useState } from 'react';
import type { Institution, NumberingRule, TemplateInfo } from '../../shared/types';
import { call } from '../api';
import { Ctx, Field, fmtDateTime, Loading, useFieldErrors } from '../ui';

const TABS = ['Instituição', 'Modelos e numeração', 'Destinatários e cargos', 'Serviços', 'Backup', 'Segurança'] as const;
const FIELDS: [string, string][] = [['recipient', 'Destinatário'], ['recipientRole', 'Cargo do destinatário'], ['subject', 'Assunto'], ['body', 'Corpo do texto'], ['city', 'Cidade']];

export function Settings({ ctx }: { ctx: Ctx }) {
  const [tab, setTab] = useState<(typeof TABS)[number]>('Instituição');
  return (<div className="page"><div className="top"><div><h1>Configurações</h1><div className="sub">{ctx.service.name} • alterações exigem o modo administrador e são registradas.</div></div></div>
    <div className="tabs" role="tablist">{TABS.map((t) => <button key={t} role="tab" className="tab" aria-selected={tab === t} onClick={() => setTab(t)}>{t}</button>)}</div>
    {tab === 'Instituição' && <InstTab ctx={ctx} />}{tab === 'Modelos e numeração' && <ModelTab ctx={ctx} />}{tab === 'Destinatários e cargos' && <ListsTab ctx={ctx} />}{tab === 'Serviços' && <ServicesTab ctx={ctx} />}
    {tab === 'Backup' && <BackupTab ctx={ctx} />}{tab === 'Segurança' && <SecurityTab ctx={ctx} />}</div>);
}

function InstTab({ ctx }: { ctx: Ctx }) {
  const sid = ctx.service.id; const [i, setI] = useState<Institution | null>(null); const fe = useFieldErrors();
  const load = () => ctx.run(async () => setI((await call<{ institution: Institution }>('inst:get', { serviceId: sid })).institution));
  useEffect(() => { void load(); }, []);
  if (!i) return <Loading />;
  const t = (k: keyof Institution, label: string, hint?: string, multi?: boolean) => (<Field label={label} error={fe.errs[k]} hint={hint}>{(id, bad) => multi
    ? <textarea id={id} style={{ minHeight: 64 }} aria-invalid={bad} value={String(i[k] ?? '')} onChange={(e) => setI({ ...i, [k]: e.target.value })} />
    : <input id={id} type="text" aria-invalid={bad} value={String(i[k] ?? '')} onChange={(e) => setI({ ...i, [k]: e.target.value })} />}</Field>);
  const save = async () => { fe.clear(); const { orgName, serviceName, city, address, phone, email, headerText, footerText, extraInfo, fontFamily, fontSizePt } = i;
    const r = await ctx.run(() => call<Institution>('inst:update', { serviceId: sid, patch: { orgName, serviceName, city, address, phone, email, headerText, footerText, extraInfo, fontFamily, fontSizePt } }), 'Configurações salvas.', fe.capture); if (r) { setI(r); void ctx.refreshBoot(); } };
  return (<div className="card"><div className="notice info">Estes dados são aplicados automaticamente a todos os novos documentos deste serviço.</div>
    <div className="grid g2"><div>{t('orgName', 'Nome do órgão')}{t('serviceName', 'Nome do serviço')}{t('city', 'Cidade padrão', 'Aparece antes da data. Ex.: Cidade/UF')}{t('address', 'Endereço')}{t('phone', 'Telefone')}{t('email', 'E-mail institucional')}</div>
      <div>{t('headerText', 'Texto do cabeçalho (opcional)', 'Uma linha por linha do cabeçalho.', true)}{t('footerText', 'Texto do rodapé (opcional)', undefined, true)}{t('extraInfo', 'Informações complementares (rodapé)', undefined, true)}
        <div className="grid g2"><Field label="Fonte">{(id) => <select id={id} value={i.fontFamily} onChange={(e) => setI({ ...i, fontFamily: e.target.value })}>{['Times New Roman', 'Arial', 'Calibri', 'Cambria', 'Georgia', 'Verdana'].map((f) => <option key={f}>{f}</option>)}</select>}</Field>
          <Field label="Tamanho (pt)" error={fe.errs.fontSizePt}>{(id) => <input id={id} type="number" min={10} max={14} value={i.fontSizePt} onChange={(e) => setI({ ...i, fontSizePt: Number(e.target.value) })} />}</Field></div>
        <div className="field"><label>Logomarca</label><div className="hint">PNG ou JPG, até 2 MB.</div><div className="row">
          <button className="btn" onClick={() => void ctx.run(() => call('inst:pickLogo', { serviceId: sid }), 'Logomarca atualizada.').then(load)}>Escolher logomarca…</button>
          {i.logoHash && <button className="btn danger" onClick={() => void ctx.run(() => call('inst:removeLogo', { serviceId: sid }), 'Logomarca removida.').then(load)}>Remover</button>}<span className="sub">{i.logoHash ? 'Logomarca definida.' : 'Sem logomarca.'}</span></div></div></div></div>
    <div className="row end"><button className="btn primary" onClick={() => void save()}>Salvar configurações</button></div></div>);
}

function ModelTab({ ctx }: { ctx: Ctx }) {
  const sid = ctx.service.id; const [all, setAll] = useState<TemplateInfo[]>([]); const [tid, setTid] = useState(''); const [t, setT] = useState<TemplateInfo | null>(null);
  const [r, setR] = useState<NumberingRule | null>(null); const [next, setNext] = useState(''); const [identText, setIdentText] = useState(''); const fe = useFieldErrors();
  const pick = async (ts: TemplateInfo[], id: string) => {
    const x = ts.find((y) => y.id === id) ?? ts[0]; if (!x) return;
    setTid(x.id); setT(x); setIdentText(x.identificationFields.join('\n')); setR(x.numbered ? await call<NumberingRule>('rule:get', { serviceId: sid, category: x.category }) : null);
  };
  const load = (id = tid) => ctx.run(async () => { const ts = await call<TemplateInfo[]>('tpl:list', { serviceId: sid }); setAll(ts); await pick(ts, id); });
  useEffect(() => { void load(''); }, []);
  if (!t) return <Loading />;
  const fields = FIELDS.filter(([k]) => t.hasRecipient || (k !== 'recipient' && k !== 'recipientRole'));
  return (<div className="grid g2">
    <div className="card"><Field label="Modelo de documento">{(id) => <select id={id} value={tid} onChange={(e) => void pick(all, e.target.value)}>{all.map((x) => <option key={x.id} value={x.id}>{x.name}{x.numbered ? ' (numerado)' : ' (sem número)'}</option>)}</select>}</Field>
      <div className="field"><label>Campos obrigatórios (assunto e corpo são sempre obrigatórios)</label>{fields.map(([k, l]) => <label key={k} className="check"><input type="checkbox" disabled={k === 'subject' || k === 'body'} checked={t.requiredFields.includes(k)} onChange={(e) => setT({ ...t, requiredFields: e.target.checked ? [...t.requiredFields, k] : t.requiredFields.filter((x) => x !== k) })} /> {l}</label>)}</div>
      <Field label="Texto de abertura fixo (aparece em todo documento deste modelo)" error={fe.errs.openingText} hint="Quem emite o documento não consegue alterar este texto; só o administrador, aqui. O texto digitado continua logo depois dele.">{(id, bad) => <textarea id={id} style={{ minHeight: 110 }} aria-invalid={bad} value={t.openingText} onChange={(e) => setT({ ...t, openingText: e.target.value })} maxLength={2000} />}</Field>
      <Field label="Fechamento (deixe vazio para não ter)">{(id) => <input id={id} type="text" value={t.closingText} onChange={(e) => setT({ ...t, closingText: e.target.value })} maxLength={120} />}</Field>
      <label className="check"><input type="checkbox" checked={t.hasIdentification} onChange={(e) => setT({ ...t, hasIdentification: e.target.checked })} /> Incluir bloco "Identificação" (logo após o assunto)</label>
      {t.hasIdentification && <Field label="Campos da identificação (um por linha; todos são obrigatórios na emissão)" error={fe.errs.identificationFields}>{(id, bad) => <textarea id={id} style={{ minHeight: 90 }} aria-invalid={bad} value={identText} onChange={(e) => setIdentText(e.target.value)} />}</Field>}
      <div className="row end"><button className="btn primary" onClick={() => void ctx.run(() => call('tpl:update', { serviceId: sid, templateId: t.id, patch: { requiredFields: t.requiredFields, closingText: t.closingText, openingText: t.openingText, hasIdentification: t.hasIdentification, identificationFields: identText.split('\n') } }), 'Modelo salvo.', fe.capture).then(() => load(t.id))}>Salvar modelo</button></div></div>
    <div className="card"><h3>Numeração — {t.name}</h3>
      {!r ? <div className="notice info">Este modelo <b>não tem número</b>: o título "{t.name}" aparece no documento, sem numeração.</div> : <>
        <Field label="Formato do número" error={fe.errs.labelFormat} hint="Use {N} para o número e {YYYY} para o ano. Ex.: {N}/{YYYY} → 001/2026">{(id, bad) => <input id={id} type="text" aria-invalid={bad} value={r.labelFormat} onChange={(e) => setR({ ...r, labelFormat: e.target.value })} />}</Field>
        <Field label="Dígitos (preenchimento com zeros)">{(id) => <input id={id} type="number" min={1} max={8} value={r.padding} onChange={(e) => setR({ ...r, padding: Number(e.target.value) })} />}</Field>
        <label className="check"><input type="checkbox" checked={r.resetYearly} onChange={(e) => setR({ ...r, resetYearly: e.target.checked })} /> Reiniciar a numeração a cada ano</label>
        <div className="row end"><button className="btn primary" onClick={() => void ctx.run(() => call('rule:update', { serviceId: sid, category: r.category, patch: { labelFormat: r.labelFormat, padding: r.padding, resetYearly: r.resetYearly } }), 'Numeração salva.', fe.capture).then(() => load(t.id))}>Salvar numeração</button></div>
        <hr style={{ border: 0, borderTop: '1px solid var(--line)', margin: '14px 0' }} />
        <Field label="Definir o próximo número do ano atual" hint="Para órgãos que já usaram números antes. Só é possível avançar, nunca voltar.">{(id) => <input id={id} type="number" min={1} value={next} onChange={(e) => setNext(e.target.value)} />}</Field>
        <button className="btn" disabled={!next} onClick={() => void ctx.run(() => call('num:setNext', { serviceId: sid, category: r.category, year: new Date().getFullYear(), next: Number(next) }), 'Próximo número definido.').then(() => setNext(''))}>Definir próximo número</button></>}</div></div>);
}

function ListsTab({ ctx }: { ctx: Ctx }) {
  return (<div><div className="notice info">Estas listas alimentam os campos "Destinatário" e "Cargo" em Novo documento (o usuário também pode digitar outro texto). Remover um item da lista não altera documentos já emitidos. A lista inicial é genérica: ajuste com os nomes reais do seu município.</div>
    <div className="grid g2"><OptionList ctx={ctx} kind="orgao" title="Destinatários (órgãos)" /><OptionList ctx={ctx} kind="cargo" title="Cargos" /></div></div>);
}

function OptionList({ ctx, kind, title }: { ctx: Ctx; kind: 'orgao' | 'cargo'; title: string }) {
  const sid = ctx.service.id; const [list, setList] = useState<{ id: number; label: string }[] | null>(null); const [txt, setTxt] = useState(''); const [q, setQ] = useState('');
  const load = () => ctx.run(async () => setList(await call<{ id: number; label: string }[]>('opt:list', { serviceId: sid, kind })));
  useEffect(() => { void load(); }, []);
  const shown = (list ?? []).filter((o) => o.label.toLowerCase().includes(q.toLowerCase()));
  return (<div className="card"><h3>{title}</h3>
    <div className="row" style={{ marginBottom: 8 }}><input type="text" aria-label={`Adicionar em ${title}`} placeholder="Novo item…" value={txt} maxLength={200} onChange={(e) => setTxt(e.target.value)} style={{ flex: 1 }}
      onKeyDown={(e) => { if (e.key === 'Enter' && txt.trim()) void ctx.run(() => call<{ id: number; label: string }[]>('opt:add', { serviceId: sid, kind, label: txt }), 'Item adicionado.').then((r) => { if (r) { setList(r); setTxt(''); } }); }} />
      <button className="btn primary" disabled={!txt.trim()} onClick={() => void ctx.run(() => call<{ id: number; label: string }[]>('opt:add', { serviceId: sid, kind, label: txt }), 'Item adicionado.').then((r) => { if (r) { setList(r); setTxt(''); } })}>Adicionar</button></div>
    <input type="text" aria-label="Filtrar lista" placeholder="Filtrar…" value={q} onChange={(e) => setQ(e.target.value)} style={{ marginBottom: 8 }} />
    {!list ? <Loading /> : <div className="opt-list">{shown.map((o) => <div key={o.id}><span>{o.label}</span><button className="btn ghost danger" aria-label={`Remover ${o.label}`} onClick={() => void ctx.run(() => call('opt:remove', { serviceId: sid, id: o.id }), 'Item removido.').then(load)}>Remover</button></div>)}{shown.length === 0 && <div className="sub">Nenhum item.</div>}</div>}
    <div className="row end" style={{ marginTop: 8 }}><button className="btn" onClick={() => void ctx.run(() => call<{ id: number; label: string }[]>('opt:restoreDefaults', { serviceId: sid, kind }), 'Itens padrão restaurados.').then((r) => r && setList(r))}>Restaurar itens padrão</button></div></div>);
}

function ServicesTab({ ctx }: { ctx: Ctx }) {
  const [f, setF] = useState({ id: '', name: '', orgName: '', city: '' }); const fe = useFieldErrors();
  return (<div className="card" style={{ maxWidth: 560 }}><h3>Adicionar serviço</h3><p className="sub">Cada serviço tem instituição, responsáveis, modelos e numeração próprios, sem misturar dados.</p>
    <Field label="Identificador (letras minúsculas, números e hífen)" error={fe.errs.id}>{(id, b) => <input id={id} type="text" aria-invalid={b} value={f.id} onChange={(e) => setF({ ...f, id: e.target.value })} />}</Field>
    <Field label="Nome do serviço" error={fe.errs.name}>{(id, b) => <input id={id} type="text" aria-invalid={b} value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />}</Field>
    <Field label="Nome do órgão" error={fe.errs.orgName}>{(id, b) => <input id={id} type="text" aria-invalid={b} value={f.orgName} onChange={(e) => setF({ ...f, orgName: e.target.value })} />}</Field>
    <Field label="Cidade">{(id) => <input id={id} type="text" value={f.city} onChange={(e) => setF({ ...f, city: e.target.value })} />}</Field>
    <div className="row end"><button className="btn primary" onClick={() => { fe.clear(); void ctx.run(() => call('service:create', f), 'Serviço criado.', fe.capture).then((r) => { if (r) { setF({ id: '', name: '', orgName: '', city: '' }); void ctx.refreshBoot(); } }); }}>Criar serviço</button></div></div>);
}

function BackupTab({ ctx }: { ctx: Ctx }) {
  const [pw, setPw] = useState(''); const [rpw, setRpw] = useState('');
  return (<div className="grid g2">
    <div className="card"><h3>Criar backup</h3><p className="sub">Salva todos os dados (documentos, cadastros, imagens e auditoria) em um único arquivo. Com senha, o arquivo é criptografado.</p>
      <Field label="Senha do backup (opcional, mínimo de 8 caracteres)">{(id) => <input id={id} type="password" value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="off" />}</Field>
      <button className="btn primary" onClick={() => void ctx.run(async () => { const p = await call<string | null>('backup:create', { password: pw }); if (p) ctx.toast(`Backup salvo: ${p}`); })}>Criar backup…</button>
      <div className="notice" style={{ marginTop: 12 }}>Guarde backups fora deste computador (pen drive protegido ou pasta institucional). Um backup sem senha contém dados pessoais em texto legível por quem tiver o arquivo.</div></div>
    <div className="card"><h3>Restaurar backup</h3><p className="sub">Substitui os dados atuais pelos do arquivo escolhido. Uma cópia de segurança dos dados atuais é guardada antes.</p>
      <Field label="Senha do backup (se houver)">{(id) => <input id={id} type="password" value={rpw} onChange={(e) => setRpw(e.target.value)} autoComplete="off" />}</Field>
      <button className="btn danger" onClick={async () => { if (!(await ctx.confirm('Restaurar backup?', 'Os dados atuais serão substituídos pelos do backup. Uma cópia de segurança será criada antes.', 'Restaurar'))) return;
        const ok = await ctx.run(() => call<boolean | null>('backup:restore', { password: rpw })); if (ok) { ctx.toast('Backup restaurado.'); await ctx.refreshBoot(); } }}>Restaurar backup…</button>
      <p className="hint" style={{ marginTop: 12 }}>Além disso, o aplicativo guarda automaticamente uma cópia local por dia (últimas 10), na pasta de dados do aplicativo.</p></div></div>);
}

function SecurityTab({ ctx }: { ctx: Ctx }) {
  const [cur, setCur] = useState(''); const [n1, setN1] = useState(''); const [rows, setRows] = useState<any[] | null>(null);
  return (<div className="grid g2">
    <div className="card"><h3>Senha de administrador</h3>
      <Field label="Senha atual">{(id) => <input id={id} type="password" value={cur} onChange={(e) => setCur(e.target.value)} autoComplete="off" />}</Field>
      <Field label="Nova senha (mínimo de 8 caracteres)">{(id) => <input id={id} type="password" value={n1} onChange={(e) => setN1(e.target.value)} autoComplete="off" />}</Field>
      <button className="btn primary" disabled={!cur || n1.length < 8} onClick={() => void ctx.run(() => call('auth:setPassword', { password: n1, current: cur }), 'Senha alterada.').then(() => { setCur(''); setN1(''); })}>Alterar senha</button>
      <div className="notice" style={{ marginTop: 12 }}>O modo administrador bloqueia sozinho após 15 minutos sem uso. A senha não pode ser recuperada; se for perdida, será preciso restaurar o aplicativo com ajuda técnica.</div></div>
    <div className="card"><h3>Registro de alterações</h3><button className="btn" onClick={() => void ctx.run(async () => setRows(await call<any[]>('audit:list', { serviceId: ctx.service.id })))}>Ver últimas alterações</button>
      {rows && (rows.length === 0 ? <p className="sub" style={{ marginTop: 10 }}>Nada registrado.</p> : <div style={{ maxHeight: 320, overflow: 'auto', marginTop: 10 }}><table><thead><tr><th>Quando</th><th>Quem</th><th>Ação</th></tr></thead><tbody>{rows.map((r) => <tr key={r.id}><td>{fmtDateTime(r.ts)}</td><td>{r.actor}</td><td>{r.action}</td></tr>)}</tbody></table></div>)}</div></div>);
}
