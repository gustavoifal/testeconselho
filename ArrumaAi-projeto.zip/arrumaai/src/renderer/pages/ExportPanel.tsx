import { useEffect, useState } from 'react';
import type { DocumentRecord } from '../../shared/types';
import { ApiError, call } from '../api';
import { Ctx } from '../ui';

export function ExportPanel({ rec, ctx, onUpdated }: { rec: DocumentRecord; ctx: Ctx; onUpdated: (r: DocumentRecord) => void }) {
  const [dir, setDir] = useState(''); const [name, setName] = useState(''); const [docx, setDocx] = useState(true); const [pdf, setPdf] = useState(true); const [busy, setBusy] = useState(false);
  useEffect(() => {
    void ctx.run(async () => {
      setName(await call<string>('doc:suggestName', { serviceId: rec.serviceId, id: rec.id }));
      setDir((await call<{ lastExportDir: string | null }>('app:bootstrap')).lastExportDir ?? '');
    });
  }, [rec.id]);
  const exportNow = async (overwrite: boolean): Promise<void> => {
    const formats = [docx && 'docx', pdf && 'pdf'].filter(Boolean);
    setBusy(true);
    try {
      const updated = await call<DocumentRecord>('doc:export', { serviceId: rec.serviceId, id: rec.id, dir, baseName: name, formats, overwrite });
      onUpdated(updated); ctx.toast('Documento exportado com sucesso.');
    } catch (e) {
      if (e instanceof ApiError && e.code === 'FILE_EXISTS') {
        setBusy(false);
        if (await ctx.confirm('Substituir arquivo?', `${e.message} Deseja substituí-lo?`, 'Substituir')) return exportNow(true);
        return;
      }
      ctx.toast(e instanceof ApiError ? e.message : 'Não foi possível exportar.', 'erro');
    } finally { setBusy(false); }
  };
  const choose = () => void ctx.run(async () => { const d = await call<string | null>('dialog:chooseExportDir'); if (d) setDir(d); });
  const show = (kind: 'docx' | 'pdf') => void ctx.run(() => call('doc:showFile', { serviceId: rec.serviceId, id: rec.id, kind }));
  return (<div className="card">
    <h3>Exportar documento</h3>
    <div className="grid" style={{ gridTemplateColumns: '1fr' }}>
      <div className="field"><label htmlFor="exdir">Pasta de destino</label><div className="row"><input id="exdir" type="text" readOnly value={dir} placeholder="Nenhuma pasta escolhida" style={{ flex: 1 }} /><button className="btn" onClick={choose}>Escolher pasta…</button></div></div>
      <div className="field"><label htmlFor="exname">Nome do arquivo (sem extensão)</label><input id="exname" type="text" value={name} onChange={(e) => setName(e.target.value)} maxLength={120} /></div>
    </div>
    <div className="row" style={{ marginBottom: 10 }}>
      <label className="check"><input type="checkbox" checked={docx} onChange={(e) => setDocx(e.target.checked)} /> Word (.docx) editável</label>
      <label className="check"><input type="checkbox" checked={pdf} onChange={(e) => setPdf(e.target.checked)} /> PDF</label>
      <span className="sp" /><button className="btn primary" disabled={busy || !dir || !name.trim() || (!docx && !pdf)} onClick={() => void exportNow(false)}>{busy ? 'Exportando…' : 'Exportar'}</button></div>
    {(rec.docxPath || rec.pdfPath) && <div className="row">{rec.docxPath && <button className="btn" onClick={() => show('docx')}>Mostrar o Word no Explorador</button>}{rec.pdfPath && <button className="btn" onClick={() => show('pdf')}>Mostrar o PDF no Explorador</button>}</div>}
  </div>);
}
