import { useEffect, useState } from 'react';
import type { DocStatus, DocumentRecord, SearchFilters, SequenceRow, TemplateInfo } from '../../shared/types';
import { call } from '../api';
import { Badge, Ctx, Empty, Field, fmtDate, fmtDateTime, Loading, Modal } from '../ui';
import { ExportPanel } from './ExportPanel';

export function History({ ctx }: { ctx: Ctx }) {
  const sid = ctx.service.id;
  const [flt, setFlt] = useState<SearchFilters>({}); const [data, setData] = useState<{ rows: DocumentRecord[]; total: number } | null>(null);
  const [sel, setSel] = useState<DocumentRecord | null>(null); const [html, setHtml] = useState(''); const [reason, setReason] = useState(''); const [cancelling, setCancelling] = useState(false);
  const [seq, setSeq] = useState<SequenceRow[] | null>(null); const [page, setPage] = useState(0); const [tpls, setTpls] = useState<TemplateInfo[]>([]); const [loadingPrev, setLoadingPrev] = useState(false);
  const load = async (f = flt, p = page) => { setData(await ctx.run(() => call<{ rows: DocumentRecord[]; total: number }>('doc:search', { serviceId: sid, filters: { ...f, limit: 25, offset: p * 25 } })) ?? null); };
  useEffect(() => { void load(); }, [page]);
  useEffect(() => { void ctx.run(async () => setTpls(await call<TemplateInfo[]>('tpl:list', { serviceId: sid }))); }, []);
  const open = async (d: DocumentRecord) => { setSel(d); setHtml(''); setCancelling(false); setReason(''); setLoadingPrev(true); const h = await ctx.run(() => call<string>('doc:renderHtml', { serviceId: sid, id: d.id })); setHtml(h ?? ''); setLoadingPrev(false); };
  const set = (p: SearchFilters) => setFlt({ ...flt, ...p });
  const doCancel = async () => {
    if (!sel) return;
    const r = await ctx.run(() => call<DocumentRecord>('doc:cancel', { serviceId: sid, id: sel.id, reason }), 'Documento cancelado. O número não será reaproveitado.');
    if (r) { setSel(r); setCancelling(false); void load(); }
  };
  return (<div className="page">
    <div className="top"><div><h1>Histórico</h1><div className="sub">{ctx.service.name} • documentos emitidos, cancelados e em edição. Nada é apagado.</div></div>
      <button className="btn" onClick={() => void ctx.run(async () => setSeq(await call<SequenceRow[]>('num:sequence', { serviceId: sid, category: 'oficio' })))}>Consultar sequência de numeração</button></div>
    <form className="card" onSubmit={(e) => { e.preventDefault(); setPage(0); void load(flt, 0); }}>
      <div className="grid g4">
        <Field label="Número">{(id) => <input id={id} type="text" value={flt.number ?? ''} onChange={(e) => set({ number: e.target.value })} placeholder="ex.: 001/2026" />}</Field>
        <Field label="Destinatário">{(id) => <input id={id} type="text" value={flt.recipient ?? ''} onChange={(e) => set({ recipient: e.target.value })} />}</Field>
        <Field label="Assunto">{(id) => <input id={id} type="text" value={flt.subject ?? ''} onChange={(e) => set({ subject: e.target.value })} />}</Field>
        <Field label="Tipo de documento">{(id) => <select id={id} value={flt.templateId ?? ''} onChange={(e) => set({ templateId: e.target.value || undefined })}><option value="">Todos</option>{tpls.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select>}</Field>
        <Field label="Situação">{(id) => <select id={id} value={flt.status ?? ''} onChange={(e) => set({ status: (e.target.value || undefined) as DocStatus | undefined })}><option value="">Todas</option><option value="emitido">Emitidos</option><option value="cancelado">Cancelados</option><option value="rascunho">Em edição</option></select>}</Field>
        <Field label="De">{(id) => <input id={id} type="date" value={flt.from ?? ''} onChange={(e) => set({ from: e.target.value || undefined })} />}</Field>
        <Field label="Até">{(id) => <input id={id} type="date" value={flt.to ?? ''} onChange={(e) => set({ to: e.target.value || undefined })} />}</Field>
        <div className="row" style={{ alignItems: 'end', paddingBottom: 12 }}><button className="btn primary">Pesquisar</button><button type="button" className="btn" onClick={() => { setFlt({}); setPage(0); void load({}, 0); }}>Limpar</button></div>
      </div></form>
    {!data ? <Loading /> : data.rows.length === 0 ? <div className="card"><Empty title="Nenhum documento encontrado" text="Ajuste os filtros ou crie um novo documento." action={<button className="btn primary" onClick={() => ctx.go('novo')}>＋ Novo documento</button>} /></div> : (
      <div className="card" style={{ padding: 0, overflowX: 'auto' }}><table>
        <thead><tr><th>Número</th><th>Tipo</th><th>Data</th><th>Destinatário</th><th>Assunto</th><th>Assinaram</th><th>Situação</th></tr></thead>
        <tbody>{data.rows.map((d) => (<tr key={d.id} className="click" tabIndex={0} onClick={() => void open(d)} onKeyDown={(e) => { if (e.key === 'Enter') void open(d); }}>
          <td><b>{d.numberLabel ?? (d.numbered ? '—' : 'sem número')}</b></td><td>{d.templateName}</td><td>{fmtDate(d.issueDate)}</td><td>{d.recipient || '—'}</td><td>{d.subject || '—'}</td><td>{d.signers.map((s) => s.name).join(', ') || '—'}</td><td><Badge status={d.status} /></td></tr>))}</tbody></table>
        <div className="row" style={{ padding: 10 }}><span className="sub">{data.total} registro(s)</span><span className="sp" /><button className="btn" disabled={page === 0} onClick={() => setPage(page - 1)}>‹ Anterior</button><button className="btn" disabled={(page + 1) * 25 >= data.total} onClick={() => setPage(page + 1)}>Próxima ›</button></div></div>)}
    {seq && <Modal title="Sequência de numeração (Ofício)" onClose={() => setSeq(null)}>{seq.length === 0 ? <p>Nenhum número usado ainda.</p> : <table><thead><tr><th>Número</th><th>Situação</th><th>Data</th></tr></thead><tbody>{seq.map((r) => <tr key={r.documentId}><td>{r.numberLabel}</td><td><Badge status={r.status} /></td><td>{fmtDate(r.issueDate)}</td></tr>)}</tbody></table>}<p className="hint" style={{ marginTop: 8 }}>Números de documentos cancelados permanecem na sequência e não são reaproveitados.</p></Modal>}
    {sel && (<Modal wide title={`${sel.templateName} ${sel.numberLabel ? 'nº ' + sel.numberLabel : sel.status === 'rascunho' ? '(em edição)' : ''}`} onClose={() => setSel(null)}>
      <div className="hist-grid">
        <div>{loadingPrev && <Loading text="Carregando visualização…" />}
          <iframe className="preview" style={{ height: '72vh', minHeight: 420 }} title="Visualização do documento" sandbox="allow-same-origin" srcDoc={html || '<p style="font:14px sans-serif;color:#667;padding:20px">Carregando…</p>'} /></div>
        <div>
          <div className="row" style={{ marginBottom: 10 }}><Badge status={sel.status} /><span className="sub">Criado em {fmtDateTime(sel.createdAt)}{sel.issuedAt ? ` • emitido em ${fmtDateTime(sel.issuedAt)}` : ''}</span></div>
          <dl className="kv" style={{ marginBottom: 12 }}><dt>Destinatário</dt><dd>{sel.recipient || '—'}</dd><dt>Assunto</dt><dd>{sel.subject || '—'}</dd><dt>Assinaram</dt><dd>{sel.signers.map((s) => s.name).join(', ') || '—'}</dd></dl>
          <div className="row" style={{ marginBottom: 10 }}>
            {sel.status === 'rascunho' && <><button className="btn primary" onClick={() => ctx.go('novo', { draftId: sel.id })}>Continuar editando</button>
              <button className="btn danger" onClick={async () => { if (await ctx.confirm('Excluir rascunho?', 'O rascunho será removido. Documentos emitidos nunca são excluídos.', 'Excluir')) { await ctx.run(() => call('doc:deleteDraft', { serviceId: sid, id: sel.id }), 'Rascunho excluído.'); setSel(null); void load(); } }}>Excluir rascunho</button></>}
            {sel.status !== 'rascunho' && <button className="btn" onClick={() => ctx.go('novo', { baseId: sel.id })}>Usar como base (duplicar)</button>}
            {sel.status === 'emitido' && !cancelling && <button className="btn danger" onClick={() => setCancelling(true)}>Cancelar documento…</button>}</div>
          {sel.status === 'cancelado' && <div className="notice">Cancelado em {fmtDateTime(sel.cancelledAt)}. Motivo: {sel.cancelReason}</div>}
          {cancelling && <div className="card"><Field label="Motivo do cancelamento (obrigatório)">{(id) => <input id={id} type="text" value={reason} onChange={(e) => setReason(e.target.value)} maxLength={500} />}</Field><div className="row end"><button className="btn" onClick={() => setCancelling(false)}>Voltar</button><button className="btn danger" disabled={reason.trim().length < 5} onClick={() => void doCancel()}>Confirmar cancelamento</button></div></div>}
          {sel.status !== 'rascunho' && <ExportPanel rec={sel} ctx={ctx} onUpdated={(r) => { setSel(r); void load(); }} />}
        </div>
      </div>
    </Modal>)}
  </div>);
}
