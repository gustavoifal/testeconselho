import { useEffect, useState } from 'react';
import type { StatsReport } from '../../shared/types';
import { call } from '../api';
import { Ctx, Field, Loading, today } from '../ui';

const MESES = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
const ml = (m: string) => `${MESES[Number(m.slice(5, 7)) - 1]}/${m.slice(0, 4)}`;
const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

export function Stats({ ctx }: { ctx: Ctx }) {
  const sid = ctx.service.id; const y = new Date().getFullYear();
  const [from, setFrom] = useState(`${y}-01-01`); const [to, setTo] = useState(today()); const [r, setR] = useState<StatsReport | null>(null); const [busy, setBusy] = useState(false);
  const load = async (f = from, t = to) => { const x = await ctx.run(() => call<StatsReport>('stats:report', { serviceId: sid, from: f, to: t })); if (x) setR(x); };
  useEffect(() => { void load(); }, []);
  const preset = (f: string, t: string) => { setFrom(f); setTo(t); void load(f, t); };
  const now = new Date();
  const max = Math.max(1, ...(r?.months.map((m) => m.emitido) ?? [1]));
  const exp = async (format: 'pdf' | 'csv') => { setBusy(true); try { const p = await ctx.run(() => call<string | null>('stats:export', { serviceId: sid, from, to, format })); if (p) ctx.toast(`Relatório salvo: ${p}`); } finally { setBusy(false); } };
  return (<div className="page">
    <div className="top"><div><h1>Estatísticas</h1><div className="sub">{ctx.service.name} • totais por período, tipo de documento e mês, para relatórios e apresentações.</div></div>
      <div className="row"><button className="btn" disabled={busy || !r} onClick={() => void exp('csv')}>Exportar planilha (CSV)</button><button className="btn primary" disabled={busy || !r} onClick={() => void exp('pdf')}>{busy ? 'Gerando…' : 'Exportar PDF'}</button></div></div>
    <form className="card" onSubmit={(e) => { e.preventDefault(); void load(); }}>
      <div className="row" style={{ alignItems: 'end' }}>
        <Field label="De">{(id) => <input id={id} type="date" value={from} onChange={(e) => setFrom(e.target.value)} />}</Field>
        <Field label="Até">{(id) => <input id={id} type="date" value={to} onChange={(e) => setTo(e.target.value)} />}</Field>
        <div className="row" style={{ paddingBottom: 12 }}><button className="btn primary">Atualizar</button>
          <button type="button" className="btn" onClick={() => preset(`${y}-01-01`, today())}>Este ano</button>
          <button type="button" className="btn" onClick={() => preset(iso(new Date(y, now.getMonth(), 1)), iso(new Date(y, now.getMonth() + 1, 0)))}>Este mês</button>
          <button type="button" className="btn" onClick={() => preset(`${y - 1}-01-01`, `${y - 1}-12-31`)}>Ano passado</button></div></div></form>
    {!r ? <Loading /> : (<>
      <div className="grid g3" style={{ marginBottom: 16 }}>
        <div className="card stat">{r.totals.emitido}<small>Documentos emitidos</small></div>
        <div className="card stat">{r.totals.cancelado}<small>Cancelados</small></div>
        <div className="card stat">{r.totals.total}<small>Total registrado no período</small></div></div>
      <div className="grid g2">
        <div className="card"><h3>Por tipo de documento</h3><table><thead><tr><th>Tipo</th><th>Emitidos</th><th>Cancelados</th></tr></thead><tbody>
          {r.byType.map((t) => <tr key={t.name}><td>{t.name}</td><td>{t.emitido}</td><td>{t.cancelado}</td></tr>)}</tbody></table></div>
        <div className="card"><h3>Emitidos por mês</h3>{r.months.map((m) => (<div key={m.month} className="mbar"><span>{ml(m.month)}</span><span className="mbar-track"><span className="mbar-fill" style={{ width: `${(m.emitido / max) * 100}%` }} /></span><b>{m.emitido}</b></div>))}</div></div>
      <div className="card" style={{ padding: 0, overflowX: 'auto' }}><table><thead><tr><th>Mês</th>{r.typeNames.map((n) => <th key={n}>{n}</th>)}<th>Total emitidos</th><th>Cancelados</th></tr></thead><tbody>
        {r.months.map((m) => <tr key={m.month}><td>{ml(m.month)}</td>{r.typeNames.map((n) => <td key={n}>{m.counts[n] ?? 0}</td>)}<td><b>{m.emitido}</b></td><td>{m.cancelado}</td></tr>)}</tbody></table></div>
      <div className="grid g2">
        <div className="card"><h3>Destinatários mais frequentes</h3>{r.byRecipient.length === 0 ? <div className="sub">Sem registros.</div> : <table><tbody>{r.byRecipient.map((x) => <tr key={x.name}><td>{x.name}</td><td style={{ width: 60 }}><b>{x.count}</b></td></tr>)}</tbody></table>}</div>
        <div className="card"><h3>Quem mais assinou</h3>{r.bySigner.length === 0 ? <div className="sub">Sem registros.</div> : <table><tbody>{r.bySigner.map((x) => <tr key={x.name}><td>{x.name}</td><td style={{ width: 60 }}><b>{x.count}</b></td></tr>)}</tbody></table>}</div></div>
      <div className="hint">Cancelados são contados à parte e não entram nos totais por tipo, mês, destinatário e responsável. Rascunhos não são contados. A data usada é a data do documento.</div></>)}
  </div>);
}
