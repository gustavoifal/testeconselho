import { useEffect, useState } from 'react';
import type { Signer, TemplateInfo } from '../../shared/types';
import { call } from '../api';
import { Ctx, Empty, Field, Loading, Modal, useFieldErrors } from '../ui';

export function Signers({ ctx }: { ctx: Ctx }) {
  const sid = ctx.service.id;
  const [list, setList] = useState<Signer[] | null>(null); const [tpls, setTpls] = useState<TemplateInfo[]>([]); const [showHidden, setShowHidden] = useState(false);
  const [edit, setEdit] = useState<Partial<Signer> & { templateIds: string[] } | null>(null); const fe = useFieldErrors();
  const load = async () => {
    await ctx.run(async () => { setTpls(await call<TemplateInfo[]>('tpl:list', { serviceId: sid })); setList(await call<Signer[]>('signer:list', { serviceId: sid, includeHidden: showHidden })); });
  };
  useEffect(() => { void load(); }, [showHidden]);
  const act = (fn: () => Promise<unknown>, msg: string) => void ctx.run(fn, msg).then(load);
  const save = async () => {
    if (!edit) return; fe.clear();
    const ok = await ctx.run(async () => {
      let id = edit.id;
      if (id) { await call('signer:update', { serviceId: sid, id, fullName: edit.fullName, roleTitle: edit.roleTitle }); await call('signer:setTemplates', { serviceId: sid, id, templateIds: edit.templateIds }); }
      else await call('signer:create', { serviceId: sid, fullName: edit.fullName ?? '', roleTitle: edit.roleTitle ?? '', templateIds: edit.templateIds });
      return true;
    }, 'Responsável salvo.', fe.capture);
    if (ok) { setEdit(null); void load(); }
  };
  return (<div className="page">
    <div className="top"><div><h1>Responsáveis e Assinaturas</h1><div className="sub">{ctx.service.name} • quem pode assinar. A quantidade de assinaturas de cada documento é escolhida na hora, em Novo documento. Alterações valem só para os próximos documentos; os já emitidos mantêm os dados originais.</div></div>
      <button className="btn primary" onClick={() => setEdit({ fullName: '', roleTitle: '', templateIds: tpls.map((t) => t.id) })}>＋ Novo responsável</button></div>
    {!ctx.isAdmin && <div className="notice info">Para cadastrar ou alterar responsáveis é preciso o <b>modo administrador</b>. O sistema pedirá a senha quando necessário.</div>}
    <div className="row" style={{ marginBottom: 8 }}><label className="check"><input type="checkbox" checked={showHidden} onChange={(e) => setShowHidden(e.target.checked)} /> Mostrar responsáveis removidos da seleção</label></div>
    {!list ? <Loading /> : list.length === 0 ? <div className="card"><Empty title="Nenhum responsável cadastrado" text="Cadastre quem poderá assinar os documentos deste serviço." /></div> : (
      <div className="card" style={{ padding: 0, overflowX: 'auto' }}><table><thead><tr><th>Nome</th><th>Cargo / função</th><th>Situação</th><th>Assina</th><th>Imagem</th><th>Ações</th></tr></thead><tbody>
        {list.map((s) => (<tr key={s.id} style={s.hidden ? { opacity: 0.6 } : undefined}><td><b>{s.fullName}</b></td><td>{s.roleTitle}</td>
          <td>{s.hidden ? 'Removido da seleção' : s.active ? 'Ativo' : 'Inativo'}</td>
          <td>{s.templateIds.length ? tpls.filter((t) => s.templateIds.includes(t.id)).map((t) => t.name).join(', ') : '—'}</td>
          <td>{s.hasSignatureImage ? 'Sim' : '—'}</td>
          <td><div className="row">
            <button className="btn" onClick={() => setEdit({ ...s })}>Editar</button>
            <button className="btn" onClick={() => act(() => call('signer:setActive', { serviceId: sid, id: s.id, active: !s.active }), s.active ? 'Responsável desativado.' : 'Responsável ativado.')}>{s.active ? 'Desativar' : 'Ativar'}</button>
            <button className="btn" onClick={() => act(() => call('signer:setHidden', { serviceId: sid, id: s.id, hidden: !s.hidden }), s.hidden ? 'Responsável restaurado.' : 'Removido da seleção (histórico preservado).')}>{s.hidden ? 'Restaurar' : 'Remover da seleção'}</button>
          </div></td></tr>))}</tbody></table></div>)}
    {edit && (<Modal title={edit.id ? 'Editar responsável' : 'Novo responsável'} onClose={() => setEdit(null)}>
      <form onSubmit={(e) => { e.preventDefault(); void save(); }}>
        <Field label="Nome completo" error={fe.errs.fullName}>{(id, bad) => <input id={id} type="text" aria-invalid={bad} value={edit.fullName ?? ''} onChange={(e) => setEdit({ ...edit, fullName: e.target.value })} maxLength={120} />}</Field>
        <Field label="Cargo ou função" error={fe.errs.roleTitle}>{(id, bad) => <input id={id} type="text" aria-invalid={bad} value={edit.roleTitle ?? ''} onChange={(e) => setEdit({ ...edit, roleTitle: e.target.value })} maxLength={120} />}</Field>
        <div className="field"><label>Pode assinar os modelos:</label>{tpls.map((t) => <label key={t.id} className="check"><input type="checkbox" checked={edit.templateIds.includes(t.id)} onChange={(e) => setEdit({ ...edit, templateIds: e.target.checked ? [...edit.templateIds, t.id] : edit.templateIds.filter((x) => x !== t.id) })} /> {t.name}</label>)}</div>
        {edit.id && <div className="field"><label>Imagem de assinatura autorizada (opcional)</label>
          <div className="notice">A imagem de uma assinatura manuscrita <b>não é assinatura eletrônica ou digital com validade jurídica</b>. Use somente com autorização do responsável.</div>
          <div className="row"><button type="button" className="btn" onClick={() => act(() => call('signer:pickImage', { serviceId: sid, id: edit.id }), 'Imagem de assinatura atualizada.')}>Escolher imagem…</button>
            {edit.hasSignatureImage && <button type="button" className="btn danger" onClick={() => act(() => call('signer:removeImage', { serviceId: sid, id: edit.id }), 'Imagem removida.')}>Remover imagem</button>}</div>
          <div className="hint">PNG ou JPG, até 1 MB. Após escolher/remover, feche e reabra para ver o estado.</div></div>}
        <div className="row end"><button type="button" className="btn" onClick={() => setEdit(null)}>Cancelar</button><button className="btn primary">Salvar</button></div>
      </form></Modal>)}
  </div>);
}
