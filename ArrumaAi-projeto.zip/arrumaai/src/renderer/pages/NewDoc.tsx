import { useEffect, useMemo, useRef, useState } from 'react';
import type { DocumentInput, DocumentRecord, Institution, RecipientOption, Signer, TemplateInfo } from '../../shared/types';
import { ApiError, call } from '../api';
import { Combo, Ctx, Field, Loading, today, useFieldErrors } from '../ui';
import { ExportPanel } from './ExportPanel';

const NI = 'Não informado';
const TREATMENTS = ['Sr(a)', 'Ilmo(a) Sr(a)', 'Exmo(a) Sr(a)', ''];
const MAX_SIG = 20;
interface Pick { signerId: number | ''; useImage: boolean }
interface Form { templateId: string; city: string; issueDate: string; recipient: string; treatment: string; role: string; subject: string; body: string; ident: string[]; picks: Pick[] }

const parseRole = (r: string) => { const t = [...TREATMENTS].filter(Boolean).sort((a, b) => b.length - a.length).find((x) => r.startsWith(`${x} `)); return t ? { treatment: t, role: r.slice(t.length + 1) } : { treatment: '', role: r }; };
const composeRole = (f: Form) => (f.role.trim() ? (f.treatment ? `${f.treatment} ${f.role.trim()}` : f.role.trim()) : '');
const storeKey = (sid: string) => `emAndamento:${sid}`;

export function NewDoc({ ctx, arg }: { ctx: Ctx; arg?: { draftId?: number; n?: number } }) {
  const sid = ctx.service.id;
  const [tpls, setTpls] = useState<TemplateInfo[]>([]); const [signers, setSigners] = useState<Signer[]>([]);
  const [orgaos, setOrgaos] = useState<string[]>([]); const [cargos, setCargos] = useState<string[]>([]);
  const [f, setF] = useState<Form | null>(null); const [draftId, setDraftId] = useState<number | undefined>(arg?.draftId);
  const [issued, setIssued] = useState<DocumentRecord | null>(null); const [html, setHtml] = useState(''); const [busy, setBusy] = useState(false);
  const [nextLabel, setNextLabel] = useState(''); const [recovered, setRecovered] = useState(false);
  const fe = useFieldErrors(); const saved = useRef('');
  const tpl = tpls.find((t) => t.id === f?.templateId);

  const loadSigners = async (templateId: string) => setSigners(await call<Signer[]>('signer:selectable', { serviceId: sid, templateId }));
  const emptyForm = (t: TemplateInfo, city: string): Form => ({ templateId: t.id, city, issueDate: today(), recipient: '', treatment: 'Sr(a)', role: '', subject: '', body: '', ident: t.identificationFields.map(() => ''), picks: [{ signerId: '', useImage: false }] });

  useEffect(() => {
    void ctx.run(async () => {
      const ts = await call<TemplateInfo[]>('tpl:list', { serviceId: sid }); setTpls(ts);
      setOrgaos((await call<RecipientOption[]>('opt:list', { serviceId: sid, kind: 'orgao' })).map((o) => o.label));
      setCargos((await call<RecipientOption[]>('opt:list', { serviceId: sid, kind: 'cargo' })).map((o) => o.label));
      const city = (await call<{ institution: Institution }>('inst:get', { serviceId: sid })).institution.city;
      let form: Form | null = null;
      if (arg?.draftId) {
        const d = await call<DocumentRecord>('doc:get', { serviceId: sid, id: arg.draftId }); const t = ts.find((x) => x.id === d.templateId) ?? ts[0];
        const pr = parseRole(d.recipientRole);
        form = { templateId: t.id, city: d.city, issueDate: d.issueDate, recipient: d.recipient, treatment: pr.treatment, role: pr.role, subject: d.subject, body: d.body, ident: t.identificationFields.map((l, i) => d.identification[i]?.label === l ? d.identification[i].value : ''), picks: d.signers.length ? d.signers.map((s) => ({ signerId: s.signerId, useImage: !!s.imageHash })) : [{ signerId: '', useImage: false }] };
      } else if (!arg?.n) {
        try { const raw = localStorage.getItem(storeKey(sid)); const r = raw ? (JSON.parse(raw) as Form) : null; if (r && ts.some((t) => t.id === r.templateId)) { form = r; setRecovered(true); } } catch { /* ignora */ }
      } else localStorage.removeItem(storeKey(sid));
      if (!form) form = emptyForm(ts[0], city);
      await loadSigners(form.templateId);
      saved.current = arg?.draftId ? JSON.stringify(form) : '';
      setF(form);
    });
  }, []);

  // Rede de segurança: guarda o que está sendo digitado e avisa o app (para confirmar antes de fechar).
  const hasContent = !!f && !!(f.recipient || f.role || f.subject || f.body || f.ident.some(Boolean) || f.picks.some((p) => p.signerId !== ''));
  const dirty = !!f && !issued && hasContent && JSON.stringify(f) !== saved.current;
  useEffect(() => { void call('app:setDirty', { dirty }).catch(() => undefined); return () => { void call('app:setDirty', { dirty: false }).catch(() => undefined); }; }, [dirty]);
  useEffect(() => {
    if (!f || issued) return;
    const t = setTimeout(() => { if (dirty) localStorage.setItem(storeKey(sid), JSON.stringify(f)); }, 400);
    return () => clearTimeout(t);
  }, [f, dirty, issued]);

  useEffect(() => {
    if (!tpl) return;
    void (async () => { try { setNextLabel(tpl.numbered ? (await call<{ label: string }>('num:peek', { serviceId: sid, category: tpl.category, issueDate: f!.issueDate })).label : ''); } catch { setNextLabel(''); } })();
  }, [tpl?.id, f?.issueDate]);

  const input = useMemo<DocumentInput | null>(() => (f && tpl ? {
    serviceId: sid, templateId: tpl.id, recipient: tpl.hasRecipient ? f.recipient : '', recipientRole: tpl.hasRecipient ? composeRole(f) : '', subject: f.subject, body: f.body, city: f.city, issueDate: f.issueDate,
    signers: f.picks.filter((p) => p.signerId !== '').map((p) => ({ signerId: Number(p.signerId), useImage: p.useImage })), identification: tpl.hasIdentification ? f.ident : [],
  } : null), [f, tpl, sid]);

  const seq = useRef(0);
  useEffect(() => {
    if (!input || issued) return;
    const n = ++seq.current;
    const t = setTimeout(async () => { try { const h = await call<string>('doc:previewHtml', { input }); if (n === seq.current) setHtml(h); } catch { /* prévia ignora dados incompletos */ } }, 500);
    return () => clearTimeout(t);
  }, [input, issued]);

  if (!f || !tpl || !input) return <Loading />;
  if (issued) {
    return (<div className="page"><div className="top"><div><h1>Documento emitido ✔</h1><div className="sub">{issued.templateName}{issued.numberLabel ? <> nº <b>{issued.numberLabel}</b></> : ''} registrado no histórico.</div></div>
      <div className="row"><button className="btn" onClick={() => ctx.go('historico')}>Ver histórico</button><button className="btn primary" onClick={() => ctx.go('novo', { n: Date.now() })}>＋ Novo documento</button></div></div>
      <ExportPanel rec={issued} ctx={ctx} onUpdated={setIssued} /></div>);
  }
  const set = (p: Partial<Form>) => setF((prev) => (prev ? { ...prev, ...p } : prev));
  const upd = (fn: (p: Form) => Partial<Form>) => setF((prev) => (prev ? { ...prev, ...fn(prev) } : prev));
  const changeType = async (id: string) => {
    const t = tpls.find((x) => x.id === id)!; await loadSigners(id);
    const prev = tpls.find((x) => x.id === f.templateId)!;
    set({ templateId: id, ident: t.identificationFields.map((l) => { const i = prev.identificationFields.indexOf(l); return i >= 0 ? f.ident[i] ?? '' : ''; }), picks: [{ signerId: '', useImage: false }] });
  };
  const chosen = new Set(f.picks.map((p) => p.signerId).filter((x) => x !== ''));
  const noSigners = signers.length === 0;
  const clearStore = () => { localStorage.removeItem(storeKey(sid)); };

  const save = async () => { fe.clear(); const d = await ctx.run(() => call<DocumentRecord>('doc:saveDraft', { input, draftId }), 'Rascunho salvo.', fe.capture); if (d) { setDraftId(d.id); saved.current = JSON.stringify(f); clearStore(); } };
  const issue = async () => {
    fe.clear(); setBusy(true);
    try {
      const msg = tpl.numbered ? `O ${tpl.name} nº ${nextLabel || '?'} será numerado e registrado agora.` : `O documento "${tpl.name}" será registrado agora.`;
      if (!(await ctx.confirm('Emitir documento?', `${msg} Depois de emitido, o conteúdo não pode ser alterado${tpl.numbered ? ' e o número não é reaproveitado' : ''}.`, 'Emitir'))) return;
      const rec = await ctx.run(() => call<DocumentRecord>('doc:issue', { input, draftId }), undefined, (e: ApiError) => fe.capture(e));
      if (rec) { clearStore(); setIssued(rec); ctx.toast(`${rec.templateName}${rec.numberLabel ? ' nº ' + rec.numberLabel : ''} emitido.`); }
    } finally { setBusy(false); }
  };

  return (<div className="page">
    <div className="top"><div><h1>Novo documento</h1><div className="sub">{ctx.service.name} • preencha os campos e confira a prévia ao lado.</div></div>
      <div className="row"><button className="btn" onClick={() => void save()}>Salvar rascunho</button><button className="btn primary" disabled={busy || noSigners} onClick={() => void issue()}>Emitir documento</button></div></div>
    {recovered && <div className="notice info row">Recuperamos o que você estava digitando.<span className="sp" /><button className="btn" onClick={async () => { const t = tpls[0]; clearStore(); setRecovered(false); setF(emptyForm(t, f.city)); await loadSigners(t.id); saved.current = ''; }}>Descartar e começar do zero</button></div>}
    {noSigners && <div className="notice">Nenhum responsável disponível para este modelo. Cadastre em <b>Responsáveis e Assinaturas</b> (modo administrador).</div>}
    <div className="split">
      <div className="card">
        <Field label="Escolha o tipo de documento" hint={tpl.numbered ? `Este tipo é numerado${nextLabel ? ` — próximo número previsto: ${nextLabel}` : ''}. O número só é reservado quando você emitir.` : `Este tipo não tem número. O título do documento será "${tpl.name}".`}>
          {(id) => <select id={id} value={f.templateId} onChange={(e) => void changeType(e.target.value)}>{tpls.map((t) => <option key={t.id} value={t.id}>{t.name}{t.numbered ? ' (numerado)' : ''}</option>)}</select>}</Field>
        <div className="grid g2">
          <Field label="Cidade" error={fe.errs.city}>{(id, bad) => <input id={id} type="text" value={f.city} aria-invalid={bad} onChange={(e) => set({ city: e.target.value })} maxLength={80} />}</Field>
          <Field label="Data de emissão" error={fe.errs.issueDate}>{(id, bad) => <input id={id} type="date" value={f.issueDate} aria-invalid={bad} onChange={(e) => set({ issueDate: e.target.value })} />}</Field>
        </div>
        {tpl.hasRecipient && <>
          <Field label="Destinatário (órgão)" error={fe.errs.recipient} hint="Digite para filtrar a lista ou escreva outro nome livremente.">{(id, bad) => <Combo id={id} value={f.recipient} invalid={bad} options={orgaos} onChange={(v) => set({ recipient: v })} />}</Field>
          <div className="grid" style={{ gridTemplateColumns: '150px 1fr', gap: 10 }}>
            <Field label="Tratamento">{(id) => <select id={id} value={f.treatment} onChange={(e) => set({ treatment: e.target.value })}>{TREATMENTS.map((t) => <option key={t} value={t}>{t || '(nenhum)'}</option>)}</select>}</Field>
            <Field label="Cargo do destinatário" error={fe.errs.recipientRole}>{(id, bad) => <Combo id={id} value={f.role} invalid={bad} options={cargos} onChange={(v) => set({ role: v })} />}</Field>
          </div></>}
        <Field label="Assunto" error={fe.errs.subject}>{(id, bad) => <input id={id} type="text" value={f.subject} aria-invalid={bad} onChange={(e) => set({ subject: e.target.value })} maxLength={300} />}</Field>
        {tpl.hasIdentification && (<fieldset style={{ border: '1px solid var(--line)', borderRadius: 8, padding: '10px 12px', margin: '0 0 12px' }}><legend style={{ fontWeight: 700, padding: '0 6px' }}>Identificação <span className="req" title="obrigatório">*</span></legend>
          <div className="hint" style={{ marginBottom: 8 }}>Todos os itens são obrigatórios. Se o dado não existir, clique em "Não informado".</div>
          {tpl.identificationFields.map((label, i) => (<Field key={label + i} label={`${label} *`} error={fe.errs[`identification.${i}`]}>{(id, bad) =>
            <div className="ident-row"><input id={id} type="text" aria-invalid={bad} value={f.ident[i] ?? ''} maxLength={300} onChange={(e) => { const v = e.target.value; upd((p) => { const ident = [...p.ident]; ident[i] = v; return { ident }; }); }} />
              <button type="button" className="btn ni" aria-pressed={f.ident[i] === NI} onClick={() => upd((p) => { const ident = [...p.ident]; ident[i] = p.ident[i] === NI ? '' : NI; return { ident }; })}>{f.ident[i] === NI ? '✔ ' : ''}Não informado</button></div>}</Field>))}</fieldset>)}
        {tpl.openingText && <div className="field"><label>Texto de abertura (fixo — não pode ser alterado aqui)</label><div className="fixed-text" aria-readonly="true">{tpl.openingText}</div></div>}
        <Field label={tpl.bodyLabel} error={fe.errs.body} hint={tpl.openingText ? 'Continue a frase do texto de abertura acima. Use Enter para criar novos parágrafos.' : 'Use Enter para criar novos parágrafos.'}>{(id, bad) => <textarea id={id} value={f.body} aria-invalid={bad} onChange={(e) => set({ body: e.target.value })} />}</Field>
        {f.picks.map((p, i) => {
          const sig = signers.find((s) => s.id === p.signerId);
          return (<div key={i}><Field label={f.picks.length === 1 ? 'Quem vai assinar?' : `${i + 1}ª assinatura — quem vai assinar?`} error={i === 0 ? fe.errs.signers : undefined}>{(id, bad) =>
            <div className="sig-row"><select id={id} aria-invalid={bad} value={p.signerId} onChange={(e) => { const picks = [...f.picks]; picks[i] = { signerId: e.target.value === '' ? '' : Number(e.target.value), useImage: false }; set({ picks }); }}>
              <option value="">Selecione…</option>{signers.filter((s) => s.id === p.signerId || !chosen.has(s.id)).map((s) => <option key={s.id} value={s.id}>{s.fullName} — {s.roleTitle}</option>)}</select>
              {f.picks.length > 1 && <button type="button" className="btn danger" onClick={() => set({ picks: f.picks.filter((_, k) => k !== i) })}>Remover</button>}</div>}</Field>
            {sig?.hasSignatureImage && <label className="check"><input type="checkbox" checked={p.useImage} onChange={(e) => { const picks = [...f.picks]; picks[i] = { ...p, useImage: e.target.checked }; set({ picks }); }} /> Inserir imagem da assinatura (apenas imagem, não é assinatura digital)</label>}</div>);
        })}
        <button type="button" className="btn" disabled={f.picks.length >= MAX_SIG || f.picks.length >= signers.length} onClick={() => set({ picks: [...f.picks, { signerId: '', useImage: false }] })}>＋ Adicionar assinatura</button>
        {f.picks.length >= signers.length && signers.length > 0 && <span className="hint" style={{ marginLeft: 10 }}>Todos os responsáveis disponíveis já foram adicionados.</span>}
      </div>
      <div><iframe className="preview" title="Prévia do documento" sandbox="allow-same-origin" srcDoc={html || '<p style="font:14px sans-serif;color:#667;padding:20px">A prévia aparece aqui.</p>'} /></div>
    </div></div>);
}
