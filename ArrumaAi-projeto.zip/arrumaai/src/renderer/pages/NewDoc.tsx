import { useEffect, useMemo, useRef, useState } from 'react';
import type { DocumentInput, DocumentRecord, Institution, Signer, TemplateInfo } from '../../shared/types';
import { ApiError, call } from '../api';
import { Ctx, Field, Loading, today, useFieldErrors } from '../ui';
import { ExportPanel } from './ExportPanel';

interface Form { city: string; issueDate: string; recipient: string; recipientRole: string; subject: string; body: string; picks: { signerId: number | ''; useImage: boolean }[] }

export function NewDoc({ ctx, arg }: { ctx: Ctx; arg?: { draftId?: number } }) {
  const sid = ctx.service.id;
  const [tpls, setTpls] = useState<TemplateInfo[]>([]); const [tplId, setTplId] = useState('');
  const [signers, setSigners] = useState<Signer[]>([]);
  const [f, setF] = useState<Form | null>(null);
  const [draftId, setDraftId] = useState<number | undefined>(arg?.draftId);
  const [issued, setIssued] = useState<DocumentRecord | null>(null);
  const [html, setHtml] = useState(''); const [busy, setBusy] = useState(false);
  const fe = useFieldErrors();
  const tpl = tpls.find((t) => t.id === tplId);

  useEffect(() => {
    void ctx.run(async () => {
      const ts = await call<TemplateInfo[]>('tpl:list', { serviceId: sid }); setTpls(ts);
      let tid = ts[0]?.id ?? ''; let form: Form | null = null;
      if (arg?.draftId) {
        const d = await call<DocumentRecord>('doc:get', { serviceId: sid, id: arg.draftId }); tid = d.templateId;
        form = { city: d.city, issueDate: d.issueDate, recipient: d.recipient, recipientRole: d.recipientRole, subject: d.subject, body: d.body, picks: d.signers.map((s) => ({ signerId: s.signerId, useImage: !!s.imageHash })) };
      }
      setTplId(tid);
      const slots = ts.find((t) => t.id === tid)?.signatureSlots ?? 1;
      if (!form) {
        const inst = (await call<{ institution: Institution }>('inst:get', { serviceId: sid })).institution;
        form = { city: inst.city, issueDate: today(), recipient: '', recipientRole: '', subject: '', body: '', picks: Array.from({ length: slots }, () => ({ signerId: '' as const, useImage: false })) };
      }
      while (form.picks.length < slots) form.picks.push({ signerId: '', useImage: false });
      setSigners(await call<Signer[]>('signer:selectable', { serviceId: sid, templateId: tid }));
      setF(form);
    });
  }, []);

  const input = useMemo<DocumentInput | null>(() => (f && tpl ? {
    serviceId: sid, templateId: tpl.id, recipient: f.recipient, recipientRole: f.recipientRole, subject: f.subject, body: f.body, city: f.city, issueDate: f.issueDate,
    signers: f.picks.filter((p) => p.signerId !== '').map((p) => ({ signerId: Number(p.signerId), useImage: p.useImage })),
  } : null), [f, tpl, sid]);

  const seq = useRef(0);
  useEffect(() => {
    if (!input || issued) return;
    const n = ++seq.current;
    const t = setTimeout(async () => { try { const h = await call<string>('doc:previewHtml', { input }); if (n === seq.current) setHtml(h); } catch { /* prévia ignora dados incompletos */ } }, 500);
    return () => clearTimeout(t);
  }, [input, issued]);

  if (!f || !tpl || !input) return <Loading />;
  if (issued) {
    return (<div className="page"><div className="top"><div><h1>Documento emitido ✔</h1><div className="sub">{issued.templateName} nº <b>{issued.numberLabel}</b> registrado no histórico.</div></div>
      <div className="row"><button className="btn" onClick={() => ctx.go('historico')}>Ver histórico</button><button className="btn primary" onClick={() => ctx.go('novo', { n: Date.now() })}>＋ Novo documento</button></div></div>
      <ExportPanel rec={issued} ctx={ctx} onUpdated={setIssued} /></div>);
  }
  const set = (p: Partial<Form>) => setF({ ...f, ...p });
  const noSigners = signers.length === 0;
  const missingSigner = f.picks.some((p) => p.signerId === '');

  const save = async () => { fe.clear(); const d = await ctx.run(() => call<DocumentRecord>('doc:saveDraft', { input, draftId }), 'Rascunho salvo.', fe.capture); if (d) setDraftId(d.id); };
  const issue = async () => {
    fe.clear(); setBusy(true);
    try {
      const nx = await call<{ label: string }>('num:peek', { serviceId: sid, category: tpl.category, issueDate: f.issueDate }).catch(() => ({ label: '?' }));
      if (!(await ctx.confirm('Emitir documento?', `O ${tpl.name} nº ${nx.label} será numerado e registrado agora. Depois de emitido, o conteúdo não pode ser alterado e o número não é reaproveitado.`, 'Emitir'))) return;
      const rec = await ctx.run(() => call<DocumentRecord>('doc:issue', { input, draftId }), undefined, (e: ApiError) => fe.capture(e));
      if (rec) { setIssued(rec); ctx.toast(`${rec.templateName} nº ${rec.numberLabel} emitido.`); }
    } finally { setBusy(false); }
  };

  return (<div className="page">
    <div className="top"><div><h1>Novo documento</h1><div className="sub">{ctx.service.name} • preencha os campos e confira a prévia ao lado. O número só é reservado quando você emitir.</div></div>
      <div className="row"><button className="btn" onClick={() => void save()}>Salvar rascunho</button><button className="btn primary" disabled={busy || noSigners} onClick={() => void issue()}>Emitir documento</button></div></div>
    {noSigners && <div className="notice">Nenhum responsável disponível para este modelo. Cadastre em <b>Responsáveis e Assinaturas</b> (modo administrador).</div>}
    <div className="split">
      <div className="card">
        {tpls.length > 1 && <Field label="Tipo de documento">{(id) => <select id={id} value={tplId} onChange={(e) => setTplId(e.target.value)}>{tpls.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select>}</Field>}
        <div className="grid g2">
          <Field label="Cidade" error={fe.errs.city}>{(id, bad) => <input id={id} type="text" value={f.city} aria-invalid={bad} onChange={(e) => set({ city: e.target.value })} maxLength={80} />}</Field>
          <Field label="Data de emissão" error={fe.errs.issueDate}>{(id, bad) => <input id={id} type="date" value={f.issueDate} aria-invalid={bad} onChange={(e) => set({ issueDate: e.target.value })} />}</Field>
        </div>
        <Field label="Destinatário" error={fe.errs.recipient}>{(id, bad) => <input id={id} type="text" value={f.recipient} aria-invalid={bad} onChange={(e) => set({ recipient: e.target.value })} maxLength={200} />}</Field>
        <Field label="Cargo do destinatário" error={fe.errs.recipientRole}>{(id, bad) => <input id={id} type="text" value={f.recipientRole} aria-invalid={bad} onChange={(e) => set({ recipientRole: e.target.value })} maxLength={200} />}</Field>
        <Field label="Assunto" error={fe.errs.subject}>{(id, bad) => <input id={id} type="text" value={f.subject} aria-invalid={bad} onChange={(e) => set({ subject: e.target.value })} maxLength={300} />}</Field>
        <Field label="Corpo do texto" error={fe.errs.body} hint="Escreva o conteúdo do documento. Use Enter para criar novos parágrafos.">{(id, bad) => <textarea id={id} value={f.body} aria-invalid={bad} onChange={(e) => set({ body: e.target.value })} />}</Field>
        {f.picks.map((p, i) => {
          const sig = signers.find((s) => s.id === p.signerId);
          return (<div key={i}><Field label={tpl.signatureSlots > 1 ? `Quem vai assinar? (${i + 1}ª assinatura)` : 'Quem vai assinar?'} error={i === 0 ? fe.errs.signers : undefined}>{(id, bad) =>
            <select id={id} aria-invalid={bad} value={p.signerId} onChange={(e) => { const picks = [...f.picks]; picks[i] = { signerId: e.target.value === '' ? '' : Number(e.target.value), useImage: false }; set({ picks }); }}>
              <option value="">Selecione…</option>{signers.map((s) => <option key={s.id} value={s.id}>{s.fullName} — {s.roleTitle}</option>)}</select>}</Field>
            {sig?.hasSignatureImage && <label className="check"><input type="checkbox" checked={p.useImage} onChange={(e) => { const picks = [...f.picks]; picks[i] = { ...p, useImage: e.target.checked }; set({ picks }); }} /> Inserir imagem da assinatura (apenas imagem, não é assinatura digital)</label>}</div>);
        })}
        {missingSigner && !noSigners && <div className="hint">Selecione todos os responsáveis exigidos por este modelo para poder emitir.</div>}
      </div>
      <div><iframe className="preview" title="Prévia do documento" sandbox="" srcDoc={html || '<p style="font:14px sans-serif;color:#667;padding:20px">A prévia aparece aqui.</p>'} /></div>
    </div></div>);
}
