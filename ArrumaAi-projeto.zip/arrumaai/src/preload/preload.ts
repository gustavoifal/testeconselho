import { contextBridge, ipcRenderer } from 'electron';
import { CHANNELS } from '../shared/channels';

const allowed = new Set<string>(CHANNELS);

// A interface só enxerga esta função; canais fora da lista são recusados aqui e de novo no processo principal.
contextBridge.exposeInMainWorld('api', {
  call: (channel: string, payload?: unknown) => {
    if (!allowed.has(channel)) return Promise.resolve({ ok: false, error: { code: 'FORBIDDEN', message: 'Operação não permitida.' } });
    return ipcRenderer.invoke(channel, payload ?? {});
  },
});
